package modelo;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record ItemVendido(Long pedidoId, LocalDateTime dataPagamento,
                          String clienteNome, String clienteUf,
                          Long vendedorId, String vendedorNome,
                          Long produtoId, String produtoNome,
                          Long categoriaId, String categoriaNome,
                          int quantidade, BigDecimal precoUnitario,
                          BigDecimal descontoVolume, BigDecimal valorLiquido,
                          BigDecimal comissao, MetodoPagamento metodo, StatusPedido status) {}
