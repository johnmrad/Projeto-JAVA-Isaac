package util;

import jakarta.persistence.*;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;

public class Jpa {
    public static final String URL = System.getenv().getOrDefault("DB_URL", "jdbc:postgresql://localhost:5432/ecommerce");
    public static final String USUARIO = System.getenv().getOrDefault("DB_USUARIO", "postgres");
    public static final String SENHA = System.getenv().getOrDefault("DB_SENHA", "");

    private static final class Fabrica {
        static final EntityManagerFactory INSTANCIA = Persistence.createEntityManagerFactory(
            "ecommerce",
            Map.of("jakarta.persistence.jdbc.url", URL,
                   "jakarta.persistence.jdbc.user", USUARIO,
                   "jakarta.persistence.jdbc.password", SENHA));
    }

    public static <T> T consultar(Function<EntityManager, T> acao) {
        try (EntityManager em = Fabrica.INSTANCIA.createEntityManager()) {
            return acao.apply(em);
        }
    }

    public static <T> T transacao(Function<EntityManager, T> acao) {
        try (EntityManager em = Fabrica.INSTANCIA.createEntityManager()) {
            EntityTransaction tx = em.getTransaction();
            tx.begin();
            try {
                T resultado = acao.apply(em);
                tx.commit();
                return resultado;
            } catch (RuntimeException e) {
                if (tx.isActive()) {
                    tx.rollback();
                }
                throw e;
            }
        }
    }

    public static void executar(Consumer<EntityManager> acao) {
        transacao(em -> {
            acao.accept(em);
            return null;
        });
    }
}
