package servico;

import ecommerce.Configuracao;
import modelo.MetodoPagamento;
import modelo.Pagamento;
import modelo.Pedido;
import modelo.StatusPedido;
import repositorio.PedidoRepositorio;
import util.Jpa;
import util.RegraNegocioException;
import util.Relogio;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ExpiracaoServico {
    public static final String AVISO_CANCELADO = "Pedido vencido: o prazo para pagar acabou. "
            + "O pedido foi cancelado e o estoque, o cupom e os pontos foram devolvidos.";

    private final PagamentoServico pagamentos = new PagamentoServico();
    private final PedidoRepositorio pedidos = new PedidoRepositorio();

    public static boolean vencido(Pedido pedido, LocalDateTime agora) {
        if (pedido.getStatus() != StatusPedido.AGUARDANDO_PAGAMENTO) {
            return false;
        }
        Pagamento pagamento = pedido.getPagamento();
        if (pagamento != null && pagamento.getMetodo() == MetodoPagamento.BOLETO
                && pagamento.getVencimento() != null) {
            return agora.toLocalDate().isAfter(pagamento.getVencimento());
        }
        if (pedido.getDataFinalizacao() == null) {
            return false;
        }
        return agora.isAfter(pedido.getDataFinalizacao().plusHours(Configuracao.HORAS_PARA_EXPIRAR_PEDIDO));
    }

    public Pedido pagar(Usuario ator, Long pedidoId, MetodoPagamento metodo, int parcelas) {
        cancelarSeVencidoAoTentar(ator, pedidoId, false);
        return pagamentos.pagar(ator, pedidoId, metodo, parcelas);
    }

    public Pedido compensarBoleto(Usuario ator, Long pedidoId) {
        Permissao.exigirLoja(ator);
        cancelarSeVencidoAoTentar(ator, pedidoId, true);
        return pagamentos.compensarBoleto(ator, pedidoId);
    }

    public boolean cancelarSeVencido(Long pedidoId) {
        return Jpa.transacao(em -> {
            Pedido pedido = PedidoLock.travar(em, pedidoId);
            return cancelarNaTransacao(em, pedido);
        });
    }

    public List<Long> cancelarVencidos(Usuario ator) {
        Permissao.exigirLoja(ator);
        List<Long> cancelados = new ArrayList<>();
        for (Long id : pedidos.idsPorStatus(StatusPedido.AGUARDANDO_PAGAMENTO)) {
            if (cancelarSeVencido(id)) {
                cancelados.add(id);
            }
        }
        return cancelados;
    }

    private void cancelarSeVencidoAoTentar(Usuario ator, Long pedidoId, boolean confirmacaoDaLoja) {
        boolean cancelou = Jpa.transacao(em -> {
            Pedido pedido = PedidoLock.travar(em, pedidoId);
            if (!confirmacaoDaLoja) {
                Permissao.exigirProprioOuLoja(ator, pedido.getCliente().getId());
            }
            return cancelarNaTransacao(em, pedido);
        });
        if (cancelou) {
            throw new RegraNegocioException(AVISO_CANCELADO);
        }
    }

    private boolean cancelarNaTransacao(jakarta.persistence.EntityManager em, Pedido pedido) {
        if (!vencido(pedido, Relogio.agora())) {
            return false;
        }
        CancelamentoServico.aplicar(em, pedido);
        return true;
    }
}
