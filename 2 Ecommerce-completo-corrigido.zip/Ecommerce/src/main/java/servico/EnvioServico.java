package servico;

import modelo.Pedido;
import modelo.StatusPedido;
import util.Jpa;

public class EnvioServico {

    public Pedido separar(Usuario ator, Long pedidoId) {
        return avancar(ator, pedidoId, StatusPedido.SEPARADO);
    }

    public Pedido enviar(Usuario ator, Long pedidoId) {
        return avancar(ator, pedidoId, StatusPedido.ENVIADO);
    }

    public Pedido entregar(Usuario ator, Long pedidoId) {
        return avancar(ator, pedidoId, StatusPedido.ENTREGUE);
    }

    public static String gerarCodigoRastreio(Long pedidoId) {
        return String.format("EC%09dBR", pedidoId);
    }

    private Pedido avancar(Usuario ator, Long pedidoId, StatusPedido novo) {
        return Jpa.transacao(em -> {
            Pedido pedido = PedidoLock.travar(em, pedidoId);
            Permissao.exigirLojaOuVendedor(ator);
            Permissao.exigirVerPedido(ator, pedido);
            FluxoPedido.mudar(pedido, novo);
            if (novo == StatusPedido.ENVIADO) {
                pedido.setCodigoRastreio(gerarCodigoRastreio(pedido.getId()));
            }
            return pedido;
        });
    }
}
