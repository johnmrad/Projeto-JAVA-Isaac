package servico;

import jakarta.persistence.EntityManager;
import jakarta.persistence.LockModeType;
import modelo.Cliente;
import modelo.Pedido;
import util.RegraNegocioException;

final class PedidoLock {
    private PedidoLock() {}

    static Pedido travar(EntityManager em, Long pedidoId) {
        Long clienteId = em.createQuery("select p.cliente.id from Pedido p where p.id = :id", Long.class)
                .setParameter("id", pedidoId)
                .getResultStream().findFirst()
                .orElseThrow(() -> new RegraNegocioException("Pedido não encontrado."));
        em.find(Cliente.class, clienteId, LockModeType.PESSIMISTIC_WRITE);
        return em.find(Pedido.class, pedidoId);
    }
}
