package ecommerce;

import java.util.ArrayList;

public class CadastroCupons {

    private ArrayList<CupomCalculo> cupons = new ArrayList<>();

    public void cadastrar(CupomCalculo novo) {
        if (buscar(novo.getCodigo()) != null) {
            throw new IllegalArgumentException("Ja existe um cupom com o codigo " + novo.getCodigo() + ".");
        }
        cupons.add(novo);
    }

    public CupomCalculo buscar(String codigo) {
        for (CupomCalculo c : cupons) {
            if (c.getCodigo().equalsIgnoreCase(codigo.trim())) {
                return c;
            }
        }
        return null;
    }

    public ArrayList<CupomCalculo> listar() {
        return cupons;
    }
}
