package ecommerce;

public class ItemPedidoCalculo {

    private String nomeProduto;
    private double precoUnitario;
    private int quantidade;
    private double comissaoVendedor;

    private double valorLiquido;
    private double comissao;

    public ItemPedidoCalculo(String nomeProduto, double precoUnitario, int quantidade, double comissaoVendedor) {
        if (precoUnitario <= 0) {
            throw new IllegalArgumentException("O preco de " + nomeProduto + " deve ser maior que zero.");
        }
        if (quantidade <= 0) {
            throw new IllegalArgumentException("A quantidade de " + nomeProduto + " deve ser maior que zero.");
        }
        if (comissaoVendedor < 0) {
            throw new IllegalArgumentException("A comissao do vendedor nao pode ser negativa.");
        }
        this.nomeProduto = nomeProduto;
        this.precoUnitario = precoUnitario;
        this.quantidade = quantidade;
        this.comissaoVendedor = comissaoVendedor;
    }

    public double getSubtotalBruto() {
        return Dinheiro.arredondar(precoUnitario * quantidade);
    }

    public double getPercentualVolume() {
        if (quantidade >= Configuracao.VOLUME_QTD_FAIXA2) {
            return Configuracao.VOLUME_DESCONTO_FAIXA2;
        } else if (quantidade >= Configuracao.VOLUME_QTD_FAIXA1) {
            return Configuracao.VOLUME_DESCONTO_FAIXA1;
        }
        return 0;
    }

    public double getDescontoVolume() {
        return Dinheiro.porcentagem(getSubtotalBruto(), getPercentualVolume());
    }

    public double getSubtotal() {
        return Dinheiro.arredondar(getSubtotalBruto() - getDescontoVolume());
    }

    public void calcularComissao(double fator) {
        this.comissao = Dinheiro.arredondar(getSubtotal() * fator * comissaoVendedor / 100);
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public double getPrecoUnitario() {
        return precoUnitario;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double getComissaoVendedor() {
        return comissaoVendedor;
    }

    public double getValorLiquido() {
        return valorLiquido;
    }

    public void setValorLiquido(double valorLiquido) {
        this.valorLiquido = valorLiquido;
    }

    public double getComissao() {
        return comissao;
    }
}
