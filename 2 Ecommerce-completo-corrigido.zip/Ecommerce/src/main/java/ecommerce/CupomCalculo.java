package ecommerce;

import java.time.LocalDate;

public class CupomCalculo {

    private String codigo;
    private double percentualDesconto;
    private double valorMinimo;
    private LocalDate validade;
    private int usosMaximos;
    private int usosFeitos;
    private boolean somentePrimeiraCompra;
    private boolean ativo;

    public CupomCalculo(String codigo, double percentualDesconto, double valorMinimo,
                 LocalDate validade, int usosMaximos, boolean somentePrimeiraCompra) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("Informe o codigo do cupom.");
        }
        if (percentualDesconto <= 0 || percentualDesconto > Configuracao.CUPOM_DESCONTO_MAXIMO) {
            throw new IllegalArgumentException("O desconto do cupom deve ser maior que 0% e no maximo "
                    + Configuracao.CUPOM_DESCONTO_MAXIMO + "%.");
        }
        if (valorMinimo < 0) {
            throw new IllegalArgumentException("O valor minimo do cupom nao pode ser negativo.");
        }
        if (validade == null) {
            throw new IllegalArgumentException("Informe a validade do cupom.");
        }
        if (usosMaximos < 1) {
            throw new IllegalArgumentException("O cupom precisa ter pelo menos 1 uso.");
        }
        this.codigo = codigo.trim().toUpperCase();
        this.percentualDesconto = percentualDesconto;
        this.valorMinimo = valorMinimo;
        this.validade = validade;
        this.usosMaximos = usosMaximos;
        this.usosFeitos = 0;
        this.somentePrimeiraCompra = somentePrimeiraCompra;
        this.ativo = true;
    }

    public void validar(double base, int comprasPagas, LocalDate hoje) {
        if (!ativo) {
            throw new IllegalArgumentException("O cupom " + codigo + " esta inativo.");
        }
        if (hoje.isAfter(validade)) {
            throw new IllegalArgumentException("O cupom " + codigo + " esta vencido.");
        }
        if (usosFeitos >= usosMaximos) {
            throw new IllegalArgumentException("O cupom " + codigo + " nao tem mais usos.");
        }
        if (base < valorMinimo) {
            throw new IllegalArgumentException("O cupom " + codigo + " exige pedido de no minimo "
                    + Dinheiro.formatar(valorMinimo) + ".");
        }
        if (somentePrimeiraCompra && comprasPagas > 0) {
            throw new IllegalArgumentException("O cupom " + codigo + " vale so na primeira compra.");
        }
    }

    public boolean podeSerUsado(double base, int comprasPagas, LocalDate hoje) {
        try {
            validar(base, comprasPagas, hoje);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    public void consumirUso() {
        if (usosFeitos >= usosMaximos) {
            throw new IllegalArgumentException("O cupom " + codigo + " nao tem mais usos.");
        }
        usosFeitos++;
    }

    public void devolverUso() {
        if (usosFeitos > 0) {
            usosFeitos--;
        }
    }

    public void ativar() {
        ativo = true;
    }

    public void desativar() {
        ativo = false;
    }

    public String getCodigo() {
        return codigo;
    }

    public double getPercentualDesconto() {
        return percentualDesconto;
    }

    public double getValorMinimo() {
        return valorMinimo;
    }

    public LocalDate getValidade() {
        return validade;
    }

    public int getUsosMaximos() {
        return usosMaximos;
    }

    public int getUsosFeitos() {
        return usosFeitos;
    }

    public boolean isSomentePrimeiraCompra() {
        return somentePrimeiraCompra;
    }

    public boolean isAtivo() {
        return ativo;
    }

    @Override
    public String toString() {
        return codigo + " - " + percentualDesconto + "% | minimo " + Dinheiro.formatar(valorMinimo)
                + " | valido ate " + validade + " | usos " + usosFeitos + "/" + usosMaximos
                + (somentePrimeiraCompra ? " | so 1a compra" : "")
                + (ativo ? "" : " | INATIVO");
    }
}
