package ecommerce;

import java.time.LocalDate;
import java.util.Scanner;

public class MenuCalculo {

    private static Scanner teclado = new Scanner(System.in);
    private static CadastroCupons cadastroCupons = new CadastroCupons();
    private static CalculoPedido calculo = new CalculoPedido("PA");

    private static double totalGastoCliente = 0;
    private static int comprasPagasCliente = 0;
    private static int saldoPontos = 0;

    public static void main(String[] args) {
        cadastroCupons.cadastrar(new CupomCalculo("BEMVINDO", 10, 100, LocalDate.now().plusMonths(1), 100, true));
        cadastroCupons.cadastrar(new CupomCalculo("PROMO15", 15, 300, LocalDate.now().plusDays(7), 50, false));

        int opcao = -1;
        while (opcao != 0) {
            System.out.println();
            System.out.println("===== CALCULO DO PEDIDO (Pessoa B) =====");
            System.out.println("1 - Adicionar item");
            System.out.println("2 - Limpar carrinho");
            System.out.println("3 - Dados do cliente");
            System.out.println("4 - Aplicar cupom");
            System.out.println("5 - Cadastrar cupom");
            System.out.println("6 - Listar cupons");
            System.out.println("7 - Ver resumo do pedido");
            System.out.println("8 - Simular pagamento");
            System.out.println("9 - Carregar exemplo da secao 14");
            System.out.println("0 - Sair");

            try {
                opcao = lerInteiro("Escolha: ");
                switch (opcao) {
                    case 1:
                        adicionarItem();
                        break;
                    case 2:
                        calculo.limparItens();
                        System.out.println("Carrinho vazio.");
                        break;
                    case 3:
                        dadosDoCliente();
                        break;
                    case 4:
                        aplicarCupom();
                        break;
                    case 5:
                        cadastrarCupom();
                        break;
                    case 6:
                        for (CupomCalculo c : cadastroCupons.listar()) {
                            System.out.println("  " + c);
                        }
                        break;
                    case 7:
                        calculo.setPagamento(null, 1);
                        calculo.calcular();
                        System.out.print(calculo.gerarResumo());
                        break;
                    case 8:
                        simularPagamento();
                        break;
                    case 9:
                        carregarExemplo();
                        break;
                    case 0:
                        System.out.println("Ate mais!");
                        break;
                    default:
                        System.out.println("Opcao invalida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Digite um numero valido.");
            } catch (IllegalArgumentException e) {
                System.out.println("NAO PERMITIDO: " + e.getMessage());
            }
        }
    }

    private static void adicionarItem() {
        String nome = lerTexto("Nome do produto: ");
        double preco = lerDecimal("Preco unitario: ");
        int quantidade = lerInteiro("Quantidade: ");
        double comissao = lerDecimal("Comissao do vendedor (%): ");
        calculo.adicionarItem(new ItemPedidoCalculo(nome, preco, quantidade, comissao));
        System.out.println("Item adicionado.");
    }

    private static void dadosDoCliente() {
        calculo.setUf(lerTexto("UF de entrega: "));
        totalGastoCliente = lerDecimal("Total ja gasto pelo cliente: ");
        comprasPagasCliente = lerInteiro("Quantidade de compras pagas: ");
        saldoPontos = lerInteiro("Saldo de pontos: ");
        int pontosParaUsar = lerInteiro("Quantos pontos quer usar neste pedido: ");

        String nivel = Fidelidade.calcularNivel(totalGastoCliente);
        calculo.setNivelFidelidade(nivel);
        calculo.setPontos(pontosParaUsar, saldoPontos);
        calculo.setCupom(calculo.getCupom(), comprasPagasCliente);
        System.out.println("Nivel do cliente: " + nivel + " (" + Fidelidade.percentualDesconto(nivel) + "% de desconto)");
    }

    private static void aplicarCupom() {
        CupomCalculo cupom = cadastroCupons.buscar(lerTexto("Codigo do cupom: "));
        if (cupom == null) {
            System.out.println("Cupom nao encontrado.");
            return;
        }
        calculo.calcular();
        cupom.validar(calculo.getBase(), comprasPagasCliente, LocalDate.now());
        calculo.setCupom(cupom, comprasPagasCliente);
        System.out.println("Cupom " + cupom.getCodigo() + " aplicado.");
    }

    private static void cadastrarCupom() {
        String codigo = lerTexto("Codigo: ");
        double percentual = lerDecimal("Desconto (%): ");
        double minimo = lerDecimal("Valor minimo do pedido: ");
        int dias = lerInteiro("Vale por quantos dias: ");
        int usos = lerInteiro("Quantidade de usos: ");
        boolean primeira = lerTexto("So na primeira compra? (s/n): ").equalsIgnoreCase("s");
        CupomCalculo novo = new CupomCalculo(codigo, percentual, minimo, LocalDate.now().plusDays(dias), usos, primeira);
        cadastroCupons.cadastrar(novo);
        System.out.println("Cupom cadastrado: " + novo);
    }

    private static void simularPagamento() {
        System.out.println("1 - PIX   2 - Cartao   3 - Boleto");
        int escolha = lerInteiro("Forma de pagamento: ");
        if (escolha == 1) {
            calculo.setPagamento(PagamentoCalculo.PIX, 1);
        } else if (escolha == 2) {
            calculo.setPagamento(null, 1);
            calculo.calcular();
            int parcelas = lerInteiro("Parcelas (1 a " + calculo.getMaximoParcelas() + "): ");
            calculo.setPagamento(PagamentoCalculo.CARTAO, parcelas);
        } else {
            calculo.setPagamento(PagamentoCalculo.BOLETO, 1);
        }
        calculo.calcular();
        System.out.print(calculo.gerarResumo());
    }

    private static void carregarExemplo() {
        calculo = new CalculoPedido("PA");
        calculo.adicionarItem(new ItemPedidoCalculo("Fone Bluetooth", 100.00, 2, 10));
        calculo.adicionarItem(new ItemPedidoCalculo("Carregador", 110.00, 1, 10));
        totalGastoCliente = 0;
        comprasPagasCliente = 0;
        saldoPontos = 0;
        System.out.println("Exemplo carregado (base R$ 310,00, vendedor com 10%).");
        System.out.println("Use a opcao 8 com PIX: deve dar R$ 294,50, 29 pontos e comissao de R$ 31,00.");
    }

    private static String lerTexto(String pergunta) {
        System.out.print(pergunta);
        return teclado.nextLine().trim();
    }

    private static int lerInteiro(String pergunta) {
        return Integer.parseInt(lerTexto(pergunta));
    }

    private static double lerDecimal(String pergunta) {
        return Double.parseDouble(lerTexto(pergunta).replace(",", "."));
    }
}
