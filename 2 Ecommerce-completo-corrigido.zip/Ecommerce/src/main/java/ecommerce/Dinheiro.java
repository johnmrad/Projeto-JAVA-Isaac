package ecommerce;

public class Dinheiro {

    public static double arredondar(double valor) {
        if (valor < 0) {
            return -arredondar(-valor);
        }
        return Math.round(valor * 100 + 0.0000001) / 100.0;
    }

    public static double porcentagem(double valor, double percentual) {
        return arredondar(valor * percentual / 100);
    }

    public static String formatar(double valor) {
        if (valor < 0) {
            return "-" + formatar(-valor);
        }
        return "R$ " + String.format("%.2f", valor).replace('.', ',');
    }
}
