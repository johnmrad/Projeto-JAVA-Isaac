package ecommerce;

public class Fidelidade {

    public static final String BRONZE = "BRONZE";
    public static final String PRATA = "PRATA";
    public static final String OURO = "OURO";

    public static String calcularNivel(double totalGasto) {
        if (totalGasto >= Configuracao.NIVEL_OURO_A_PARTIR_DE) {
            return OURO;
        } else if (totalGasto >= Configuracao.NIVEL_PRATA_A_PARTIR_DE) {
            return PRATA;
        }
        return BRONZE;
    }

    public static double percentualDesconto(String nivel) {
        if (OURO.equals(nivel)) {
            return Configuracao.DESCONTO_OURO;
        } else if (PRATA.equals(nivel)) {
            return Configuracao.DESCONTO_PRATA;
        }
        return Configuracao.DESCONTO_BRONZE;
    }

    public static int calcularPontosGanhos(double valorCobrado) {
        if (valorCobrado <= 0) {
            return 0;
        }
        return (int) (valorCobrado / Configuracao.REAIS_POR_PONTO_GANHO + 0.0000001);
    }

    public static int retirarPontos(int saldoAtual, int pontosParaRetirar) {
        int novoSaldo = saldoAtual - pontosParaRetirar;
        if (novoSaldo < 0) {
            return 0;
        }
        return novoSaldo;
    }
}
