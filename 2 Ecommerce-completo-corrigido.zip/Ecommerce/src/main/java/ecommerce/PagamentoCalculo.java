package ecommerce;

import java.time.LocalDate;

public class PagamentoCalculo {

    public static final String PIX = "PIX";
    public static final String CARTAO = "CARTAO";
    public static final String BOLETO = "BOLETO";

    public static double descontoPix(double valorProdutos) {
        return Dinheiro.porcentagem(valorProdutos, Configuracao.DESCONTO_PIX);
    }

    public static int maximoParcelas(double total) {
        int pelaParcelaMinima = (int) (total / Configuracao.CARTAO_PARCELA_MINIMA + 0.0000001);
        int maximo = Math.min(Configuracao.CARTAO_MAX_PARCELAS, pelaParcelaMinima);
        if (maximo < 1) {
            maximo = 1;
        }
        return maximo;
    }

    public static double valorNoCartao(double total, int parcelas) {
        int maximo = maximoParcelas(total);
        if (parcelas < 1 || parcelas > maximo) {
            throw new IllegalArgumentException("Parcelas invalidas. Para este pedido escolha de 1 a " + maximo + "x.");
        }
        if (parcelas <= Configuracao.CARTAO_PARCELAS_SEM_JUROS) {
            return Dinheiro.arredondar(total);
        }
        double taxa = 1 + Configuracao.CARTAO_JUROS / 100;
        return Dinheiro.arredondar(total * Math.pow(taxa, parcelas));
    }

    public static double valorParcela(double valorCobrado, int parcelas) {
        return Dinheiro.arredondar(valorCobrado / parcelas);
    }

    public static LocalDate vencimentoBoleto(LocalDate hoje) {
        return hoje.plusDays(Configuracao.BOLETO_DIAS_VENCIMENTO);
    }
}
