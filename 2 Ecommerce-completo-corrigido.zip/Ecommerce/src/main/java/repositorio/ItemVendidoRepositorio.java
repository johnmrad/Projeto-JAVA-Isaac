package repositorio;

import modelo.ItemVendido;
import modelo.StatusPedido;
import util.Jpa;
import java.util.Arrays;
import java.util.List;

public class ItemVendidoRepositorio {

    private static final List<StatusPedido> STATUS_VENDA = Arrays.stream(StatusPedido.values())
            .filter(StatusPedido::contaComoVenda).toList();

    public List<ItemVendido> itensDoMes(int ano, int mes, Long vendedorId) {
        String filtroVendedor = vendedorId == null ? "" : " and v.id = :ven";
        return Jpa.consultar(em -> {
            var q = em.createQuery(
                "select new modelo.ItemVendido(p.id, p.dataPagamento, c.nome, c.uf, v.id, v.nome, "
                + "pr.id, pr.nome, cat.id, cat.nome, i.quantidade, i.precoUnitario, "
                + "i.descontoVolume, i.valorLiquido, i.comissao, pg.metodo, p.status) "
                + "from Pedido p join p.cliente c join p.itens i join i.produto pr "
                + "join pr.vendedor v join pr.categoria cat left join p.pagamento pg "
                + "where p.status in :st and extract(year from p.dataPagamento) = :ano "
                + "and extract(month from p.dataPagamento) = :mes" + filtroVendedor
                + " order by p.dataPagamento, p.id, i.id", ItemVendido.class)
                .setParameter("st", STATUS_VENDA)
                .setParameter("ano", ano)
                .setParameter("mes", mes);
            if (vendedorId != null) {
                q.setParameter("ven", vendedorId);
            }
            return q.getResultList();
        });
    }
}
