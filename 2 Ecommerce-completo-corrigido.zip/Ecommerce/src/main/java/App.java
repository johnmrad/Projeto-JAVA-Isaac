import menu.Console;
import menu.MenuPrincipal;
import util.Jpa;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class App {
    public static void main(String[] args) {
        Console console = new Console(System.in, System.out);

        String problema = problemaDeConexao();
        if (problema != null) {
            console.linha("Não consegui conectar ao banco de dados PostgreSQL.");
            console.linha("Tentei: " + Jpa.URL + " com o usuário \"" + Jpa.USUARIO + "\" e "
                    + (Jpa.SENHA.isEmpty() ? "SEM senha (DB_SENHA não definida)" : "a senha de DB_SENHA") + ".");
            console.linha("Motivo: " + problema);
            console.linha("Usuário, senha e endereço podem ser trocados com DB_USUARIO, DB_SENHA e DB_URL.");
            System.exit(1);
        }

        try {
            Jpa.consultar(em -> 1);
        } catch (Throwable e) {
            console.linha("Conectei ao PostgreSQL, mas o Hibernate não conseguiu iniciar (criar/atualizar as tabelas).");
            console.linha("Motivo: " + motivo(e));
            System.exit(1);
        }

        try {
            new MenuPrincipal(console).executar();
        } catch (Console.FimDaEntrada e) {
            console.linha();
            console.linha("Entrada encerrada. Até logo!");
        }
        System.exit(0);
    }

    private static String problemaDeConexao() {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            return "o driver do PostgreSQL não está no classpath. Rode pelo Maven "
                    + "(mvn compile exec:java -Dexec.mainClass=App) ou pelo Run do VS Code com o pom.xml carregado.";
        }
        try (Connection conexao = DriverManager.getConnection(Jpa.URL, Jpa.USUARIO, Jpa.SENHA)) {
            return null;
        } catch (SQLException e) {
            return explicar(e);
        }
    }

    private static String explicar(SQLException e) {
        String dica = switch (e.getSQLState() == null ? "" : e.getSQLState()) {
            case "28P01" -> "senha errada para o usuário \"" + Jpa.USUARIO + "\". Defina DB_SENHA com a senha do seu PostgreSQL.";
            case "08004" -> "o PostgreSQL recusou a conexão (geralmente pediu senha e nenhuma foi informada). Defina DB_SENHA.";
            case "28000" -> "o PostgreSQL recusou o usuário \"" + Jpa.USUARIO + "\". Confira DB_USUARIO.";
            case "3D000" -> "o banco não existe. Crie com: CREATE DATABASE ecommerce;";
            case "08001" -> "não achei o PostgreSQL nesse endereço. Ele está ligado? A porta é a 5432?";
            default -> null;
        };
        return dica == null ? e.getMessage() : dica + "\n        (" + e.getMessage() + ")";
    }

    private static String motivo(Throwable e) {
        Throwable causa = e;
        for (Throwable t = e; t != null; t = t.getCause()) {
            if (t instanceof SQLException sql) {
                return explicar(sql);
            }
            causa = t;
        }
        return causa.getMessage() != null ? causa.getMessage() : causa.toString();
    }
}
