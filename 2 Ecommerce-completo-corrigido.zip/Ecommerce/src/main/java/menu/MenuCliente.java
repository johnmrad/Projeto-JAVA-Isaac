package menu;

import ecommerce.Fidelidade;
import ecommerce.PagamentoCalculo;
import modelo.Cliente;
import modelo.MetodoPagamento;
import modelo.Pedido;
import modelo.Produto;
import modelo.StatusPedido;
import servico.CalculadoraDoPedido;
import servico.CancelamentoServico;
import servico.CarrinhoServico;
import servico.ClienteServico;
import servico.ExpiracaoServico;
import servico.ExportacaoServico;
import servico.PedidoConsulta;
import servico.ProdutoServico;
import servico.Usuario;
import util.Relogio;
import java.nio.file.Path;
import java.util.List;

public class MenuCliente {
    private final Console c;
    private final Usuario eu;
    private final ClienteServico clientes = new ClienteServico();
    private final ProdutoServico produtos = new ProdutoServico();
    private final CarrinhoServico carrinho = new CarrinhoServico();
    private final ExpiracaoServico expiracao = new ExpiracaoServico();
    private final CancelamentoServico cancelamento = new CancelamentoServico();
    private final PedidoConsulta pedidos = new PedidoConsulta();
    private final ExportacaoServico exportacao = new ExportacaoServico();

    public MenuCliente(Console console, Usuario cliente) {
        this.c = console;
        this.eu = cliente;
    }

    public void executar() {
        String nome = clientes.buscar(eu, eu.id()).getNome();
        while (true) {
            c.linha();
            c.linha("===== CLIENTE: " + nome + " ===== (" + Tela.dataHora(Relogio.agora()) + ")");
            c.linha("1 - Ver catálogo");
            c.linha("2 - Colocar produto no carrinho");
            c.linha("3 - Ver carrinho");
            c.linha("4 - Aplicar cupom");
            c.linha("5 - Usar pontos");
            c.linha("6 - Finalizar pedido");
            c.linha("7 - Pagar pedido");
            c.linha("8 - Meus pedidos");
            c.linha("9 - Cancelar pedido");
            c.linha("10 - Nota fiscal (XML)");
            c.linha("11 - Meus dados e pontos");
            c.linha("12 - Desativar minha conta");
            c.linha("0 - Sair");
            switch (c.inteiro("Escolha:")) {
                case 1 -> c.seguro(this::catalogo);
                case 2 -> c.seguro(this::colocarNoCarrinho);
                case 3 -> c.seguro(() -> Tela.pedido(c, carrinho.abrir(eu)));
                case 4 -> c.seguro(this::aplicarCupom);
                case 5 -> c.seguro(this::usarPontos);
                case 6 -> c.seguro(this::finalizar);
                case 7 -> c.seguro(this::pagar);
                case 8 -> c.seguro(this::meusPedidos);
                case 9 -> c.seguro(this::cancelar);
                case 10 -> c.seguro(this::notaFiscal);
                case 11 -> c.seguro(this::meusDados);
                case 12 -> {
                    if (desativarConta()) {
                        return;
                    }
                }
                case 0 -> {
                    return;
                }
                default -> c.linha("  Opção inválida.");
            }
        }
    }

    private void catalogo() {
        List<Produto> lista = produtos.catalogo();
        if (lista.isEmpty()) {
            c.linha("  Nenhum produto disponível no momento.");
        }
        lista.forEach(p -> c.linha("  " + Tela.produto(p)));
    }

    private void colocarNoCarrinho() {
        Long produtoId = c.id("Número do produto:");
        int quantidade = c.inteiro("Quantidade (0 remove do carrinho):");
        Pedido atual = carrinho.definirQuantidade(eu, produtoId, quantidade);
        c.linha("  Carrinho atualizado:");
        Tela.pedido(c, atual);
    }

    private void aplicarCupom() {
        Pedido atual = carrinho.aplicarCupom(eu, c.texto("Código do cupom:"));
        c.linha("  Cupom aplicado!");
        Tela.pedido(c, atual);
    }

    private void usarPontos() {
        Cliente dono = clientes.buscar(eu, eu.id());
        c.linha("  Seu saldo: " + dono.getPontos() + " pontos (cada ponto vale R$ 0,10; máximo de 30% do pedido).");
        Pedido atual = carrinho.usarPontos(eu, c.inteiro("Quantos pontos quer usar?"));
        c.linha("  Pontos que serão usados: " + atual.getPontosUsados());
        Tela.pedido(c, atual);
    }

    private void finalizar() {
        Pedido atual = carrinho.abrir(eu);
        Tela.pedido(c, atual);
        if (atual.getItens().isEmpty()) {
            c.linha("  O carrinho está vazio.");
            return;
        }
        if (!c.confirmar("Finalizar o pedido? (o estoque é reservado e você tem 24h para pagar)")) {
            return;
        }
        Pedido pedido = carrinho.finalizar(eu);
        c.linha("  [OK] Pedido #" + pedido.getId() + " finalizado. Agora é só pagar (opção 7).");
        Tela.pedido(c, pedido);
    }

    private void pagar() {
        List<Pedido> pendentes = pedidos.listar(eu).stream()
                .filter(p -> p.getStatus() == StatusPedido.AGUARDANDO_PAGAMENTO).toList();
        if (pendentes.isEmpty()) {
            c.linha("  Você não tem pedido aguardando pagamento. Finalize o carrinho primeiro.");
            return;
        }
        Pedido pedido;
        if (pendentes.size() == 1) {
            pedido = pendentes.get(0);
        } else {
            pendentes.forEach(p -> c.linha("  " + Tela.linhaPedido(p)));
            pedido = pedidos.buscar(eu, c.id("Número do pedido a pagar:"));
        }
        Tela.pedido(c, pedido);

        int maximoParcelas = PagamentoCalculo.maximoParcelas(pedido.getTotal().doubleValue());
        c.linha("  Formas de pagamento:");
        c.linha("   1 - PIX ........ " + Tela.dinheiro(CalculadoraDoPedido.valorCobrado(pedido, MetodoPagamento.PIX, 1))
                + " (5% de desconto nos produtos)");
        c.linha("   2 - Cartão ..... em até " + maximoParcelas + "x (sem juros até 3x)");
        c.linha("   3 - Boleto ..... " + Tela.dinheiro(pedido.getTotal()) + " (vence em 3 dias)");
        MetodoPagamento metodo;
        int parcelas = 1;
        switch (c.inteiro("Forma de pagamento:")) {
            case 1 -> metodo = MetodoPagamento.PIX;
            case 3 -> metodo = MetodoPagamento.BOLETO;
            case 2 -> {
                metodo = MetodoPagamento.CARTAO;
                for (int n = 1; n <= maximoParcelas; n++) {
                    var cobrado = CalculadoraDoPedido.valorCobrado(pedido, metodo, n);
                    c.linha("   " + n + "x de " + Tela.dinheiro(java.math.BigDecimal.valueOf(
                            PagamentoCalculo.valorParcela(cobrado.doubleValue(), n))) + " (total " + Tela.dinheiro(cobrado) + ")");
                }
                parcelas = c.inteiro("Número de parcelas:");
            }
            default -> {
                c.linha("  Opção inválida.");
                return;
            }
        }
        var cobrado = CalculadoraDoPedido.valorCobrado(pedido, metodo, parcelas);
        if (!c.confirmar("Confirmar pagamento de " + Tela.dinheiro(cobrado) + " no " + metodo + "?")) {
            return;
        }
        Pedido pago = expiracao.pagar(eu, pedido.getId(), metodo, parcelas);
        if (pago.getStatus() == StatusPedido.PAGO) {
            c.linha("  [OK] Pagamento aprovado!");
        } else {
            c.linha("  [OK] Boleto gerado. O pedido fica aguardando até a loja compensar o boleto.");
        }
        Tela.pedido(c, pago);
    }

    private void meusPedidos() {
        List<Pedido> lista = pedidos.listar(eu);
        if (lista.isEmpty()) {
            c.linha("  Você ainda não tem pedidos.");
            return;
        }
        lista.forEach(p -> c.linha("  " + Tela.linhaPedido(p)));
        Long id = c.idOpcional("Ver detalhes de qual pedido? (Enter para voltar)");
        if (id != null) {
            Tela.pedido(c, pedidos.buscar(eu, id));
        }
    }

    private void cancelar() {
        List<Pedido> lista = pedidos.listar(eu);
        lista.forEach(p -> c.linha("  " + Tela.linhaPedido(p)));
        Long id = c.idOpcional("Número do pedido a cancelar (Enter para voltar):");
        if (id == null) {
            return;
        }
        if (!c.confirmar("Cancelar o pedido #" + id + "?")) {
            return;
        }
        Pedido cancelado = cancelamento.cancelar(eu, id);
        c.linha("  [OK] Pedido #" + cancelado.getId() + " cancelado. Estoque, cupom e pontos foram devolvidos.");
    }

    private void notaFiscal() {
        Long id = c.id("Número do pedido:");
        Path arquivo = exportacao.salvarXmlNotaFiscal(eu, id, Path.of("exportacoes"));
        c.linha("  [OK] Nota fiscal (simulada) salva em " + arquivo.toAbsolutePath());
        if (c.confirmar("Mostrar o XML na tela?")) {
            c.linha(exportacao.xmlNotaFiscal(eu, id));
        }
    }

    private void meusDados() {
        Cliente cli = clientes.buscar(eu, eu.id());
        String nivel = Fidelidade.calcularNivel(cli.getTotalGasto().doubleValue());
        c.linha("  " + cli.getNome() + " - " + cli.getEmail() + " - CPF " + cli.getCpf());
        c.linha("  " + cli.getEndereco() + ", " + cli.getCidade() + "/" + cli.getUf());
        c.linha("  Nível: " + nivel + " (" + Fidelidade.percentualDesconto(nivel) + "% de desconto) - total gasto "
                + Tela.dinheiro(cli.getTotalGasto()) + " em " + cli.getComprasPagas() + " compra(s) paga(s)");
        c.linha("  Pontos: " + cli.getPontos());
    }

    private boolean desativarConta() {
        try {
            if (!c.confirmar("Desativar sua conta? Você não poderá mais entrar.")) {
                return false;
            }
            clientes.desativar(eu, eu.id());
            c.linha("  [OK] Conta desativada.");
            return true;
        } catch (util.RegraNegocioException e) {
            c.linha("  [ERRO] " + e.getMessage());
            return false;
        }
    }
}
