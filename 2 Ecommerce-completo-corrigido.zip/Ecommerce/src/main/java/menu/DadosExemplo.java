package menu;

import jakarta.persistence.Query;
import util.Jpa;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

final class DadosExemplo {
    private static final List<Path> LUGARES = List.of(
            Path.of("sql", "dados_exemplo.sql"), Path.of("Ecommerce", "sql", "dados_exemplo.sql"),
            Path.of("..", "sql", "dados_exemplo.sql"));

    private DadosExemplo() {}

    static int carregar() throws IOException {
        Path arquivo = LUGARES.stream().filter(Files::exists).findFirst().orElse(null);
        if (arquivo == null) {
            return -1;
        }
        String sql = Files.readString(arquivo, StandardCharsets.UTF_8).replaceAll("(?m)^\\s*--.*$", "");
        List<String> comandos = Arrays.stream(sql.split(";")).map(String::trim).filter(s -> !s.isEmpty()).toList();
        Jpa.executar(em -> {
            for (String comando : comandos) {
                Query q = em.createNativeQuery(comando);
                if (comando.regionMatches(true, 0, "select", 0, 6)) {
                    q.getResultList();
                } else {
                    q.executeUpdate();
                }
            }
        });
        return comandos.size();
    }
}
