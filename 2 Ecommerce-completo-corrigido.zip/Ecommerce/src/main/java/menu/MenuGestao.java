package menu;

import modelo.Cliente;
import modelo.Cupom;
import modelo.MetodoPagamento;
import modelo.Pedido;
import modelo.Produto;
import modelo.StatusPedido;
import repositorio.CategoriaRepositorio;
import repositorio.ClienteRepositorio;
import repositorio.ProdutoRepositorio;
import repositorio.VendedorRepositorio;
import servico.CancelamentoServico;
import servico.CategoriaServico;
import servico.ClienteServico;
import servico.CupomServico;
import servico.EnvioServico;
import servico.ExpiracaoServico;
import servico.ExportacaoServico;
import servico.IndicadorServico;
import servico.PedidoConsulta;
import servico.ProdutoServico;
import servico.RelatorioServico;
import servico.Usuario;
import servico.VendedorServico;
import util.RegraNegocioException;
import util.Relogio;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import modelo.Papel;

public class MenuGestao {
    private final Console c;
    private final Usuario ator;
    private final boolean loja;

    private final ProdutoServico produtos = new ProdutoServico();
    private final ProdutoRepositorio produtoRepo = new ProdutoRepositorio();
    private final CategoriaRepositorio categorias = new CategoriaRepositorio();
    private final VendedorRepositorio vendedores = new VendedorRepositorio();
    private final ClienteRepositorio clienteRepo = new ClienteRepositorio();
    private final PedidoConsulta pedidos = new PedidoConsulta();
    private final EnvioServico envio = new EnvioServico();
    private final CancelamentoServico cancelamento = new CancelamentoServico();
    private final ExpiracaoServico expiracao = new ExpiracaoServico();
    private final RelatorioServico relatorio = new RelatorioServico();
    private final IndicadorServico indicadores = new IndicadorServico();
    private final ExportacaoServico exportacao = new ExportacaoServico();

    public MenuGestao(Console console, Usuario ator) {
        this.c = console;
        this.ator = ator;
        this.loja = ator.papel() == Papel.LOJA;
    }

    public void executar() {
        String quem = loja ? "LOJA" : "VENDEDOR: " + vendedores.buscarPorId(ator.id()).map(v -> v.getNome()).orElse("?");
        while (true) {
            c.linha();
            c.linha("===== " + quem + " ===== (" + Tela.dataHora(Relogio.agora()) + ")");
            c.linha("1 - Produtos");
            c.linha("2 - Pedidos e envio");
            c.linha("3 - Relatórios e exportações");
            if (loja) {
                c.linha("4 - Administração da loja");
            }
            c.linha("0 - Sair");
            switch (c.inteiro("Escolha:")) {
                case 1 -> menuProdutos();
                case 2 -> menuPedidos();
                case 3 -> menuRelatorios();
                case 4 -> {
                    if (loja) {
                        menuAdministracao();
                    } else {
                        c.linha("  Opção inválida.");
                    }
                }
                case 0 -> {
                    return;
                }
                default -> c.linha("  Opção inválida.");
            }
        }
    }

    private void menuProdutos() {
        while (true) {
            c.linha();
            c.linha("--- Produtos ---");
            c.linha("1 - Listar produtos");
            c.linha("2 - Cadastrar produto");
            c.linha("3 - Alterar produto");
            c.linha("4 - Repor estoque");
            c.linha("5 - Ativar ou desativar produto");
            c.linha("6 - Excluir produto");
            c.linha("7 - Alerta de estoque baixo");
            c.linha("0 - Voltar");
            switch (c.inteiro("Escolha:")) {
                case 1 -> c.seguro(this::listarProdutos);
                case 2 -> c.seguro(this::cadastrarProduto);
                case 3 -> c.seguro(this::alterarProduto);
                case 4 -> c.seguro(() -> {
                    Produto p = produtos.reporEstoque(ator, c.id("Número do produto:"), c.inteiro("Quantidade a repor:"));
                    c.linha("  [OK] Estoque de " + p.getNome() + " agora é " + p.getEstoque() + ".");
                });
                case 5 -> c.seguro(this::ativarOuDesativar);
                case 6 -> c.seguro(() -> {
                    Long id = c.id("Número do produto:");
                    if (c.confirmar("Excluir o produto #" + id + "? (só é possível se nunca foi vendido)")) {
                        produtos.excluir(ator, id);
                        c.linha("  [OK] Produto excluído.");
                    }
                });
                case 7 -> c.seguro(() -> {
                    List<Produto> baixo = produtos.estoqueBaixo(ator);
                    if (baixo.isEmpty()) {
                        c.linha("  Nenhum produto com estoque baixo.");
                    }
                    baixo.forEach(p -> c.linha("  [!] " + Tela.produto(p)));
                });
                case 0 -> {
                    return;
                }
                default -> c.linha("  Opção inválida.");
            }
        }
    }

    private void listarProdutos() {
        List<Produto> lista = produtoRepo.listarTodos().stream()
                .filter(p -> loja || p.getVendedor().getId().equals(ator.id())).toList();
        if (lista.isEmpty()) {
            c.linha("  Nenhum produto cadastrado.");
        }
        lista.forEach(p -> c.linha("  " + Tela.produto(p)));
    }

    private void mostrarCategorias() {
        categorias.listarTodos().forEach(cat -> c.linha("   #" + cat.getId() + " " + cat.getNome()));
    }

    private void cadastrarProduto() {
        if (categorias.listarTodos().isEmpty()) {
            c.linha("  Não há categorias. A loja precisa cadastrar uma em Administração.");
            return;
        }
        String nome = c.texto("Nome:");
        String descricao = c.texto("Descrição:");
        BigDecimal preco = c.valor("Preço (R$):");
        int estoque = c.inteiro("Estoque inicial:");
        c.linha("  Categorias:");
        mostrarCategorias();
        Long categoriaId = c.id("Número da categoria:");
        Long vendedorId = null;
        if (loja) {
            c.linha("  Vendedores:");
            vendedores.listarTodos().forEach(v -> c.linha("   #" + v.getId() + " " + v.getNome()));
            vendedorId = c.id("Número do vendedor dono do produto:");
        }
        Produto p = produtos.cadastrar(ator, nome, descricao, preco, estoque, categoriaId, vendedorId);
        c.linha("  [OK] Produto #" + p.getId() + " cadastrado.");
    }

    private void alterarProduto() {
        Long id = c.id("Número do produto:");
        Produto p = produtoRepo.buscarPorId(id).orElseThrow(() -> new RegraNegocioException("Produto não encontrado."));
        c.linha("  Atual: " + Tela.produto(p));
        String nome = c.texto("Novo nome (Enter mantém):");
        String descricao = c.texto("Nova descrição (Enter mantém):");
        BigDecimal preco = c.valorOpcional("Novo preço (Enter mantém):");
        c.linha("  Categorias:");
        mostrarCategorias();
        Long categoriaId = c.idOpcional("Nova categoria (Enter mantém):");
        produtos.alterar(ator, id, nome.isEmpty() ? p.getNome() : nome,
                descricao.isEmpty() ? p.getDescricao() : descricao,
                preco == null ? p.getPreco() : preco,
                categoriaId == null ? p.getCategoria().getId() : categoriaId);
        c.linha("  [OK] Produto atualizado.");
    }

    private void ativarOuDesativar() {
        Long id = c.id("Número do produto:");
        if (c.confirmar("Ativar o produto? (n = desativar)")) {
            produtos.ativar(ator, id);
            c.linha("  [OK] Produto ativado.");
        } else {
            produtos.desativar(ator, id);
            c.linha("  [OK] Produto desativado.");
        }
    }

    private void menuPedidos() {
        while (true) {
            c.linha();
            c.linha("--- Pedidos e envio ---");
            c.linha("1 - Listar pedidos");
            c.linha("2 - Separar pedido");
            c.linha("3 - Enviar pedido (gera o código de rastreio)");
            c.linha("4 - Marcar pedido como entregue");
            if (loja) {
                c.linha("5 - Cancelar pedido");
            }
            c.linha("0 - Voltar");
            switch (c.inteiro("Escolha:")) {
                case 1 -> c.seguro(this::listarPedidos);
                case 2 -> c.seguro(() -> {
                    Pedido p = envio.separar(ator, c.id("Número do pedido:"));
                    c.linha("  [OK] Pedido #" + p.getId() + " separado.");
                });
                case 3 -> c.seguro(() -> {
                    Pedido p = envio.enviar(ator, c.id("Número do pedido:"));
                    c.linha("  [OK] Pedido #" + p.getId() + " enviado. Código de rastreio: " + p.getCodigoRastreio());
                });
                case 4 -> c.seguro(() -> {
                    Pedido p = envio.entregar(ator, c.id("Número do pedido:"));
                    c.linha("  [OK] Pedido #" + p.getId() + " entregue.");
                });
                case 5 -> {
                    if (loja) {
                        c.seguro(this::cancelarPedido);
                    } else {
                        c.linha("  Opção inválida.");
                    }
                }
                case 0 -> {
                    return;
                }
                default -> c.linha("  Opção inválida.");
            }
        }
    }

    private void listarPedidos() {
        List<Pedido> lista = pedidos.listar(ator);
        if (lista.isEmpty()) {
            c.linha("  Nenhum pedido.");
            return;
        }
        lista.forEach(p -> c.linha("  " + Tela.linhaPedido(p)));
        Long id = c.idOpcional("Ver detalhes de qual pedido? (Enter para voltar)");
        if (id != null) {
            Tela.pedido(c, pedidos.buscar(ator, id));
        }
    }

    private void cancelarPedido() {
        Long id = c.id("Número do pedido a cancelar:");
        if (c.confirmar("Cancelar o pedido #" + id + "?")) {
            Pedido p = cancelamento.cancelar(ator, id);
            c.linha("  [OK] Pedido #" + p.getId() + " cancelado.");
        }
    }

    private void menuRelatorios() {
        while (true) {
            c.linha();
            c.linha("--- Relatórios e exportações ---");
            c.linha("1 - Relatório do mês");
            c.linha("2 - Exportar CSV de vendas do mês");
            c.linha("3 - Nota fiscal (XML) de um pedido");
            c.linha("0 - Voltar");
            switch (c.inteiro("Escolha:")) {
                case 1 -> c.seguro(this::relatorioDoMes);
                case 2 -> c.seguro(this::exportarCsv);
                case 3 -> c.seguro(this::notaFiscal);
                case 0 -> {
                    return;
                }
                default -> c.linha("  Opção inválida.");
            }
        }
    }

    private void relatorioDoMes() {
        LocalDate hoje = Relogio.hoje();
        int ano = c.inteiroOu("Ano", hoje.getYear());
        int mes = c.inteiroOu("Mês", hoje.getMonthValue());
        Long vendedorId = loja ? c.idOpcional("Filtrar por vendedor (id) ou Enter para a loja inteira:") : null;

        c.linha();
        c.linha(String.format("  RELATÓRIO DE %02d/%d - %s", mes, ano, loja && vendedorId == null ? "loja inteira" : "vendedor"));
        c.linha("  Total vendido ......... " + Tela.dinheiro(relatorio.totalDoMes(ator, ano, mes, vendedorId)));
        c.linha("  Ticket médio .......... " + Tela.dinheiro(relatorio.ticketMedio(ator, ano, mes, vendedorId)));
        c.linha("  Maior pedido .......... " + Tela.dinheiro(relatorio.maiorPedido(ator, ano, mes, vendedorId)));
        c.linha("  Menor pedido .......... " + Tela.dinheiro(relatorio.menorPedido(ator, ano, mes, vendedorId)));
        c.linha("  Taxa de cancelamento .. " + Tela.percentual(indicadores.taxaCancelamento(ator, ano, mes, vendedorId)));

        c.linha("  Comissão a pagar:");
        indicadores.comissaoAPagar(ator, ano, mes, vendedorId)
                .forEach(x -> c.linha("    " + x.vendedorNome() + ": " + Tela.dinheiro(x.comissao())));

        c.linha("  Vendas por categoria:");
        var categoriasVendidas = indicadores.vendasPorCategoria(ator, ano, mes, vendedorId);
        if (categoriasVendidas.isEmpty()) {
            c.linha("    (sem vendas)");
        }
        categoriasVendidas.forEach(x -> c.linha("    " + x.categoriaNome() + ": " + x.quantidade() + " un. - " + Tela.dinheiro(x.valor())));

        c.linha("  Pedidos por forma de pagamento:");
        indicadores.pedidosPorFormaPagamento(ator, ano, mes, vendedorId)
                .forEach(x -> c.linha("    " + x.metodo() + ": " + x.pedidos() + " pedido(s) - " + Tela.dinheiro(x.valor())));

        c.linha("  Ranking de produtos:");
        var produtosVendidos = relatorio.rankingProdutos(ator, ano, mes, vendedorId);
        if (produtosVendidos.isEmpty()) {
            c.linha("    (sem vendas)");
        }
        int posicao = 1;
        for (var x : produtosVendidos) {
            c.linha("    " + posicao++ + ". " + x.produtoNome() + " - " + x.quantidade() + " un. - " + Tela.dinheiro(x.valor()));
        }

        c.linha("  Ranking de clientes:");
        var clientesTop = relatorio.rankingClientes(ator, ano, mes, vendedorId);
        if (clientesTop.isEmpty()) {
            c.linha("    (sem vendas)");
        }
        posicao = 1;
        for (var x : clientesTop) {
            c.linha("    " + posicao++ + ". " + x.clienteNome() + " - " + Tela.dinheiro(x.total()));
        }
    }

    private void exportarCsv() {
        LocalDate hoje = Relogio.hoje();
        int ano = c.inteiroOu("Ano", hoje.getYear());
        int mes = c.inteiroOu("Mês", hoje.getMonthValue());
        Long vendedorId = loja ? c.idOpcional("Filtrar por vendedor (id) ou Enter para a loja inteira:") : null;
        Path arquivo = exportacao.salvarCsvVendasDoMes(ator, ano, mes, vendedorId, Path.of("exportacoes"));
        c.linha("  [OK] CSV salvo em " + arquivo.toAbsolutePath());
    }

    private void notaFiscal() {
        Long id = c.id("Número do pedido:");
        Path arquivo = exportacao.salvarXmlNotaFiscal(ator, id, Path.of("exportacoes"));
        c.linha("  [OK] Nota fiscal (simulada) salva em " + arquivo.toAbsolutePath());
        if (c.confirmar("Mostrar o XML na tela?")) {
            c.linha(exportacao.xmlNotaFiscal(ator, id));
        }
    }

    private void menuAdministracao() {
        while (true) {
            c.linha();
            c.linha("--- Administração da loja ---");
            c.linha("1 - Cadastrar vendedor");
            c.linha("2 - Cadastrar categoria");
            c.linha("3 - Cadastrar cupom");
            c.linha("4 - Listar cupons");
            c.linha("5 - Listar clientes");
            c.linha("6 - Desativar cliente");
            c.linha("7 - Compensar boleto");
            c.linha("8 - Rodar rotina de expiração (cancela os pedidos vencidos)");
            c.linha("9 - Simular passagem do tempo");
            c.linha("0 - Voltar");
            switch (c.inteiro("Escolha:")) {
                case 1 -> c.seguro(() -> {
                    var v = new VendedorServico().cadastrar(ator, c.texto("Nome:"), c.texto("E-mail:"),
                            c.valor("Comissão (0 a 30%):"));
                    c.linha("  [OK] Vendedor #" + v.getId() + " cadastrado.");
                });
                case 2 -> c.seguro(() -> {
                    var cat = new CategoriaServico().cadastrar(ator, c.texto("Nome da categoria:"));
                    c.linha("  [OK] Categoria #" + cat.getId() + " cadastrada.");
                });
                case 3 -> c.seguro(this::cadastrarCupom);
                case 4 -> c.seguro(this::listarCupons);
                case 5 -> c.seguro(this::listarClientes);
                case 6 -> c.seguro(() -> {
                    Long id = c.id("Número do cliente:");
                    if (c.confirmar("Desativar o cliente #" + id + "?")) {
                        new ClienteServico().desativar(ator, id);
                        c.linha("  [OK] Cliente desativado.");
                    }
                });
                case 7 -> c.seguro(this::compensarBoleto);
                case 8 -> c.seguro(() -> {
                    List<Long> cancelados = expiracao.cancelarVencidos(ator);
                    c.linha(cancelados.isEmpty() ? "  Nenhum pedido vencido."
                            : "  [OK] " + cancelados.size() + " pedido(s) vencido(s) cancelado(s): " + cancelados);
                });
                case 9 -> simularTempo();
                case 0 -> {
                    return;
                }
                default -> c.linha("  Opção inválida.");
            }
        }
    }

    private void cadastrarCupom() {
        Cupom cupom = new CupomServico().cadastrar(ator, c.texto("Código do cupom:"),
                c.valor("Desconto (% acima de 0 e até 50):"), c.valor("Valor mínimo do pedido (R$):"),
                c.data("Válido até"), c.inteiro("Número máximo de usos:"),
                c.confirmar("Vale só na primeira compra?"));
        c.linha("  [OK] Cupom " + cupom.getCodigo() + " cadastrado.");
    }

    private void listarCupons() {
        List<Cupom> lista = new CupomServico().listar(ator);
        if (lista.isEmpty()) {
            c.linha("  Nenhum cupom cadastrado.");
        }
        for (Cupom k : lista) {
            c.linha(String.format("  %-14s %7s  mínimo %-11s válido até %s  usos %d/%d%s%s", k.getCodigo(),
                    Tela.percentual(k.getPercentualDesconto()), Tela.dinheiro(k.getValorMinimo()),
                    k.getValidade().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                    k.getUsosRealizados(), k.getUsosMaximos(),
                    k.isSomentePrimeiraCompra() ? "  [1ª compra]" : "", k.isAtivo() ? "" : "  [INATIVO]"));
        }
    }

    private void listarClientes() {
        List<Cliente> lista = clienteRepo.listarTodos();
        if (lista.isEmpty()) {
            c.linha("  Nenhum cliente cadastrado.");
        }
        for (Cliente k : lista) {
            c.linha(String.format("  #%-3d %-22s %-26s %s  %4d pontos  gasto %s%s", k.getId(), k.getNome(),
                    k.getEmail(), k.getUf(), k.getPontos(), Tela.dinheiro(k.getTotalGasto()),
                    k.isAtivo() ? "" : "  [INATIVO]"));
        }
    }

    private void compensarBoleto() {
        List<Pedido> pendentes = pedidos.listar(ator).stream()
                .filter(p -> p.getStatus() == StatusPedido.AGUARDANDO_PAGAMENTO && p.getPagamento() != null
                        && p.getPagamento().getMetodo() == MetodoPagamento.BOLETO).toList();
        if (pendentes.isEmpty()) {
            c.linha("  Nenhum boleto pendente.");
            return;
        }
        pendentes.forEach(p -> c.linha("  " + Tela.linhaPedido(p) + "  vence em "
                + p.getPagamento().getVencimento().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"))));
        Pedido pago = expiracao.compensarBoleto(ator, c.id("Número do pedido a compensar:"));
        c.linha("  [OK] Boleto compensado. Pedido #" + pago.getId() + " está " + pago.getStatus() + ".");
    }

    private void simularTempo() {
        c.linha("  Data do sistema agora: " + Tela.dataHora(Relogio.agora()));
        c.linha("  1 - Avançar horas");
        c.linha("  2 - Avançar dias");
        c.linha("  3 - Voltar ao relógio real");
        c.linha("  0 - Voltar");
        switch (c.inteiro("Escolha:")) {
            case 1 -> Relogio.fixar(Relogio.agora().plusHours(c.inteiro("Quantas horas?")));
            case 2 -> Relogio.fixar(Relogio.agora().plusDays(c.inteiro("Quantos dias?")));
            case 3 -> Relogio.liberar();
            default -> {
                return;
            }
        }
        c.linha("  Data do sistema agora: " + Tela.dataHora(Relogio.agora()));
    }
}
