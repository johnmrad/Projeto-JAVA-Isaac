package menu;

import util.RegraNegocioException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Console {

    public static class FimDaEntrada extends RuntimeException {
        public FimDaEntrada() { super("Fim da entrada"); }
    }

    private static final DateTimeFormatter DATA = DateTimeFormatter.ofPattern("dd/MM/uuuu");

    private final BufferedReader teclado;
    private final PrintStream tela;

    public Console(InputStream entrada, PrintStream saida) {
        this.teclado = new BufferedReader(new InputStreamReader(entrada));
        this.tela = saida;
    }

    public void linha(String texto) { tela.println(texto); }

    public void linha() { tela.println(); }

    public String texto(String pergunta) {
        tela.print(pergunta + " ");
        tela.flush();
        try {
            String lida = teclado.readLine();
            if (lida == null) {
                throw new FimDaEntrada();
            }
            return lida.trim();
        } catch (IOException e) {
            throw new FimDaEntrada();
        }
    }

    public int inteiro(String pergunta) {
        while (true) {
            try {
                return Integer.parseInt(texto(pergunta));
            } catch (NumberFormatException e) {
                linha("  Digite um número inteiro.");
            }
        }
    }

    public int inteiroOu(String pergunta, int padrao) {
        while (true) {
            String t = texto(pergunta + " [" + padrao + "]");
            if (t.isEmpty()) {
                return padrao;
            }
            try {
                return Integer.parseInt(t);
            } catch (NumberFormatException e) {
                linha("  Digite um número inteiro.");
            }
        }
    }

    public Long id(String pergunta) {
        while (true) {
            try {
                return Long.parseLong(texto(pergunta));
            } catch (NumberFormatException e) {
                linha("  Digite o número (id).");
            }
        }
    }

    public Long idOpcional(String pergunta) {
        while (true) {
            String t = texto(pergunta);
            if (t.isEmpty()) {
                return null;
            }
            try {
                return Long.parseLong(t);
            } catch (NumberFormatException e) {
                linha("  Digite o número (id) ou só Enter.");
            }
        }
    }

    public BigDecimal valor(String pergunta) {
        while (true) {
            try {
                return new BigDecimal(texto(pergunta).replace(',', '.'));
            } catch (NumberFormatException e) {
                linha("  Digite um valor, por exemplo 12,50.");
            }
        }
    }

    public BigDecimal valorOpcional(String pergunta) {
        while (true) {
            String t = texto(pergunta);
            if (t.isEmpty()) {
                return null;
            }
            try {
                return new BigDecimal(t.replace(',', '.'));
            } catch (NumberFormatException e) {
                linha("  Digite um valor, por exemplo 12,50, ou só Enter.");
            }
        }
    }

    public LocalDate data(String pergunta) {
        while (true) {
            try {
                return LocalDate.parse(texto(pergunta + " (dd/mm/aaaa)"), DATA);
            } catch (DateTimeParseException e) {
                linha("  Data inválida. Use o formato dd/mm/aaaa.");
            }
        }
    }

    public boolean confirmar(String pergunta) {
        while (true) {
            String t = texto(pergunta + " (s/n)").toLowerCase();
            if (t.equals("s") || t.equals("sim")) {
                return true;
            }
            if (t.equals("n") || t.equals("nao") || t.equals("não")) {
                return false;
            }
            linha("  Responda s ou n.");
        }
    }

    public void seguro(Runnable acao) {
        try {
            acao.run();
        } catch (FimDaEntrada e) {
            throw e;
        } catch (RegraNegocioException e) {
            linha("  [ERRO] " + e.getMessage());
        } catch (RuntimeException e) {
            linha("  [ERRO] Erro inesperado: " + e);
        }
    }
}
