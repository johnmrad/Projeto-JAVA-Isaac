package menu;

import servico.ClienteServico;
import servico.Usuario;
import servico.VendedorServico;
import util.Relogio;

public class MenuPrincipal {
    private final Console c;
    private final ClienteServico clientes = new ClienteServico();
    private final VendedorServico vendedores = new VendedorServico();

    public MenuPrincipal(Console console) {
        this.c = console;
    }

    public void executar() {
        c.linha("=========================================");
        c.linha("             E-COMMERCE");
        c.linha("=========================================");
        while (true) {
            c.linha();
            c.linha("===== INÍCIO ===== (" + Tela.dataHora(Relogio.agora()) + ")");
            c.linha("1 - Entrar como cliente");
            c.linha("2 - Entrar como vendedor");
            c.linha("3 - Entrar como loja");
            c.linha("4 - Cadastrar novo cliente");
            c.linha("5 - Carregar dados de exemplo (apaga tudo e recomeça)");
            c.linha("0 - Sair");
            switch (c.inteiro("Escolha:")) {
                case 1 -> c.seguro(() -> {
                    Usuario u = clientes.entrar(c.texto("E-mail do cliente:"));
                    new MenuCliente(c, u).executar();
                });
                case 2 -> c.seguro(() -> {
                    Usuario u = vendedores.entrar(c.texto("E-mail do vendedor:"));
                    new MenuGestao(c, u).executar();
                });
                case 3 -> c.seguro(() -> new MenuGestao(c, Usuario.loja()).executar());
                case 4 -> c.seguro(this::cadastrarCliente);
                case 5 -> c.seguro(this::carregarExemplo);
                case 0 -> {
                    c.linha("Até logo!");
                    return;
                }
                default -> c.linha("  Opção inválida.");
            }
        }
    }

    private void cadastrarCliente() {
        var cliente = clientes.cadastrar(c.texto("Nome:"), c.texto("E-mail:"), c.texto("CPF:"),
                c.texto("Cidade:"), c.texto("UF (ex.: PA):"), c.texto("Endereço:"));
        c.linha("  [OK] Cadastro feito! Entre como cliente usando o e-mail " + cliente.getEmail() + ".");
    }

    private void carregarExemplo() {
        if (!c.confirmar("Isso APAGA todos os dados atuais e carrega os dados de exemplo. Continuar?")) {
            return;
        }
        try {
            int comandos = DadosExemplo.carregar();
            if (comandos < 0) {
                c.linha("  [ERRO] Não achei sql/dados_exemplo.sql. Rode o programa na pasta do projeto.");
                return;
            }
            c.linha("  [OK] Dados de exemplo carregados. Para testar: cliente maria@email.com, vendedor a@loja.com, ou entre como loja.");
        } catch (java.io.IOException e) {
            c.linha("  [ERRO] Não consegui ler o arquivo de dados de exemplo: " + e.getMessage());
        }
    }
}
