package teste;

import modelo.Categoria;
import modelo.Cliente;
import modelo.ItemPedido;
import modelo.MetodoPagamento;
import modelo.Pagamento;
import modelo.Pedido;
import modelo.Produto;
import modelo.StatusPagamento;
import modelo.StatusPedido;
import modelo.Vendedor;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import servico.NotaFiscalXml;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.*;

public class NotaFiscalXmlTest {

    private Pedido pedidoPago(String nomeCliente) {
        Cliente cliente = new Cliente(nomeCliente, "maria@email.com", "52998224725", "Belém", "PA", "Rua A, 10");
        Vendedor vendedor = new Vendedor("Loja A", "a@loja.com", new BigDecimal("10"));
        Categoria categoria = new Categoria("Periféricos");
        Produto mouse = new Produto("Mouse & Cia", "d", new BigDecimal("80"), 5, categoria, vendedor);

        Pedido pedido = new Pedido(cliente, LocalDateTime.of(2026, 9, 10, 9, 0));
        pedido.setId(1L);
        pedido.setStatus(StatusPedido.ENTREGUE);
        pedido.setDataPagamento(LocalDateTime.of(2026, 9, 10, 9, 10, 0));
        ItemPedido item = new ItemPedido(mouse, 2, new BigDecimal("80.00"));
        item.setValorLiquido(new BigDecimal("160.00"));
        pedido.adicionarItem(item);
        pedido.setSubtotalBruto(new BigDecimal("160"));
        pedido.setBase(new BigDecimal("160"));
        pedido.setValorProdutos(new BigDecimal("160"));
        pedido.setFrete(new BigDecimal("12"));
        pedido.setTotal(new BigDecimal("172"));
        pedido.setValorCobrado(new BigDecimal("164"));
        pedido.setCodigoRastreio("EC000000001BR");
        Pagamento pg = new Pagamento(MetodoPagamento.PIX);
        pg.setStatus(StatusPagamento.APROVADO);
        pg.setAjuste(new BigDecimal("-8.00"));
        pedido.setPagamento(pg);
        return pedido;
    }

    private Document ler(String xml) throws Exception {
        return DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
    }

    private String texto(Document doc, String tag) {
        return doc.getElementsByTagName(tag).item(0).getTextContent();
    }

    @Test void xmlBemFormadoComAvisoDeDocumentoSimulado() throws Exception {
        Document doc = ler(NotaFiscalXml.gerar(pedidoPago("Maria Silva")));
        assertEquals("notaFiscal", doc.getDocumentElement().getTagName());
        assertEquals("true", doc.getDocumentElement().getAttribute("simulada"));
        assertEquals("DOCUMENTO SIMULADO - SEM VALIDADE FISCAL", texto(doc, "aviso"));
    }

    @Test void trazDestinatarioItensTotaisPagamentoERastreio() throws Exception {
        Document doc = ler(NotaFiscalXml.gerar(pedidoPago("Maria Silva")));
        assertEquals("1", texto(doc, "numero"));
        assertEquals("2026-09-10T09:10:00", texto(doc, "dataEmissao"));
        org.w3c.dom.Element destinatario = (org.w3c.dom.Element) doc.getElementsByTagName("destinatario").item(0);
        assertEquals("Maria Silva", destinatario.getElementsByTagName("nome").item(0).getTextContent());
        assertEquals("52998224725", texto(doc, "cpf"));
        assertEquals(1, doc.getElementsByTagName("item").getLength());
        assertEquals("Mouse & Cia", texto(doc, "produto"));
        assertEquals("160.00", texto(doc, "valorLiquido"));
        assertEquals("172.00", texto(doc, "total"));
        assertEquals("164.00", texto(doc, "valorCobrado"));
        assertEquals("PIX", texto(doc, "forma"));
        assertEquals("EC000000001BR", texto(doc, "codigoRastreio"));
    }

    @Test void caracteresEspeciaisSaemProtegidos() throws Exception {
        String xml = NotaFiscalXml.gerar(pedidoPago("Ana <b>&\"Costa\""));
        assertFalse(xml.contains("<b>"));
        Document doc = ler(xml);
        assertEquals("Mouse & Cia", texto(doc, "produto"));
    }

    @Test void semRastreioNaoTemATag() throws Exception {
        Pedido p = pedidoPago("Maria");
        p.setCodigoRastreio(null);
        assertEquals(0, ler(NotaFiscalXml.gerar(p)).getElementsByTagName("codigoRastreio").getLength());
    }
}
