package teste;

import modelo.Cupom;
import modelo.Pedido;
import modelo.StatusPedido;
import org.junit.jupiter.api.Test;
import ecommerce.Fidelidade;
import servico.CancelamentoServico;
import servico.CarrinhoServico;
import servico.EnvioServico;
import servico.ExportacaoServico;
import servico.IndicadorServico;
import servico.RelatorioServico;
import servico.Usuario;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

public class FluxoCompletoTest {
    private final CarrinhoServico carrinho = new CarrinhoServico();
    private final EnvioServico envio = new EnvioServico();
    private final CancelamentoServico cancelamento = new CancelamentoServico();
    private final RelatorioServico relatorio = new RelatorioServico();
    private final IndicadorServico indicadores = new IndicadorServico();
    private final ExportacaoServico exportacao = new ExportacaoServico();

    private void igual(String esperado, BigDecimal real) {
        assertEquals(0, new BigDecimal(esperado).compareTo(real), "esperado " + esperado + " mas veio " + real);
    }

    @Test void compraCompletaDoExemploDaSecao14() {
        try (CenarioD c = new CenarioD()) {
            Long vendedor = c.vendedor.getId();

            Pedido emCarrinho = c.carrinhoComExemplo(c.donoCliente);
            igual("310.00", emCarrinho.getBase());
            Pedido finalizado = carrinho.finalizar(c.donoCliente);
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, finalizado.getStatus());
            assertEquals(18, c.produto(c.mouse.getId()).getEstoque());
            assertEquals(9, c.produto(c.teclado.getId()).getEstoque());

            Pedido pago = c.pagarNoPix(c.donoCliente, finalizado.getId());
            assertEquals(StatusPedido.PAGO, pago.getStatus());
            igual("294.50", pago.getValorCobrado());
            assertEquals(29, c.cliente().getPontos());
            BigDecimal comissao = pago.getItens().stream().map(i -> i.getComissao()).reduce(BigDecimal.ZERO, BigDecimal::add);
            igual("31.00", comissao);

            envio.separar(c.donoVendedor, pago.getId());
            envio.enviar(c.donoVendedor, pago.getId());
            Pedido entregue = envio.entregar(c.donoVendedor, pago.getId());
            assertEquals(StatusPedido.ENTREGUE, entregue.getStatus());
            assertNotNull(c.pedido(pago.getId()).getCodigoRastreio());

            igual("310.00", relatorio.totalDoMes(c.loja, 2026, 6, vendedor));
            igual("31.00", indicadores.comissaoAPagar(c.loja, 2026, 6, vendedor).get(0).comissao());
            igual("310.00", indicadores.vendasPorCategoria(c.loja, 2026, 6, vendedor).get(0).valor());
            assertEquals(1, indicadores.pedidosPorFormaPagamento(c.loja, 2026, 6, vendedor).get(0).pedidos());
            igual("0.00", indicadores.taxaCancelamento(c.loja, 2026, 6, vendedor));
            String csv = new String(exportacao.csvVendasDoMes(c.donoVendedor, 2026, 6, null), 3,
                    exportacao.csvVendasDoMes(c.donoVendedor, 2026, 6, null).length - 3, StandardCharsets.UTF_8);
            String[] linhas = csv.split("\r\n");
            assertEquals(3, linhas.length);
            BigDecimal somaCsv = BigDecimal.ZERO;
            for (int i = 1; i < linhas.length; i++) {
                somaCsv = somaCsv.add(new BigDecimal(linhas[i].split(";")[9].replace(',', '.')));
            }
            igual("310.00", somaCsv);
            assertTrue(exportacao.xmlNotaFiscal(c.donoCliente, pago.getId()).contains("DOCUMENTO SIMULADO"));
        }
    }

    @Test void cupomDe10PorCentoDaSecao14() {
        try (CenarioD c = new CenarioD()) {
            Cupom cupom = c.novoCupom(10, 100);
            c.carrinhoComExemplo(c.donoCliente);
            Pedido comCupom = carrinho.aplicarCupom(c.donoCliente, cupom.getCodigo());
            igual("31.00", comCupom.getDescontoComercial());
            Pedido finalizado = carrinho.finalizar(c.donoCliente);
            Pedido pago = c.pagarNoPix(c.donoCliente, finalizado.getId());
            BigDecimal comissao = pago.getItens().stream().map(i -> i.getComissao()).reduce(BigDecimal.ZERO, BigDecimal::add);
            igual("27.90", comissao);
            assertEquals(1, c.cupom(cupom.getId()).getUsosRealizados());
        }
    }

    @Test void cancelarUmPedidoPagoFazTudoVoltarAoValorAnterior() {
        try (CenarioD c = new CenarioD()) {
            Long vendedor = c.vendedor.getId();
            c.definirCliente(0, "0");

            c.exemploPagoNoPix(c.donoCliente);
            BigDecimal gastoAntes = c.cliente().getTotalGasto();
            int pontosAntes = c.cliente().getPontos();
            int comprasAntes = c.cliente().getComprasPagas();
            String nivelAntes = Fidelidade.calcularNivel(gastoAntes.doubleValue());
            BigDecimal totalAntes = relatorio.totalDoMes(c.loja, 2026, 6, vendedor);
            BigDecimal comissaoAntes = indicadores.comissaoAPagar(c.loja, 2026, 6, vendedor).get(0).comissao();
            int estoqueAntes = c.produto(c.mouse.getId()).getEstoque();

            Pedido segunda = c.exemploPagoNoPix(c.donoCliente);
            assertEquals(2, c.cliente().getComprasPagas());
            igual("620.00", relatorio.totalDoMes(c.loja, 2026, 6, vendedor));
            assertEquals(Fidelidade.PRATA, Fidelidade.calcularNivel(c.cliente().getTotalGasto().doubleValue()));

            cancelamento.cancelar(c.donoCliente, segunda.getId());

            Pedido cancelado = c.pedido(segunda.getId());
            assertEquals(StatusPedido.CANCELADO, cancelado.getStatus());
            igual(gastoAntes.toPlainString(), c.cliente().getTotalGasto());
            assertEquals(pontosAntes, c.cliente().getPontos());
            assertEquals(comprasAntes, c.cliente().getComprasPagas());
            assertEquals(nivelAntes, Fidelidade.calcularNivel(c.cliente().getTotalGasto().doubleValue()));
            igual(totalAntes.toPlainString(), relatorio.totalDoMes(c.loja, 2026, 6, vendedor));
            igual(comissaoAntes.toPlainString(), indicadores.comissaoAPagar(c.loja, 2026, 6, vendedor).get(0).comissao());
            assertEquals(estoqueAntes, c.produto(c.mouse.getId()).getEstoque());
            igual("50.00", indicadores.taxaCancelamento(c.loja, 2026, 6, vendedor));
            assertEquals(3, new String(exportacao.csvVendasDoMes(c.loja, 2026, 6, vendedor), StandardCharsets.UTF_8).split("\r\n").length);
        }
    }

    @Test void csvDaLojaBateComORelatorioNumMesSoSeu() {
        try (CenarioD c = new CenarioD()) {
            c.exemploPagoNoPix(c.donoCliente);
            BigDecimal totalLoja = relatorio.totalDoMes(c.loja, 2026, 6, null);
            String csv = new String(exportacao.csvVendasDoMes(c.loja, 2026, 6, null), 3,
                    exportacao.csvVendasDoMes(c.loja, 2026, 6, null).length - 3, StandardCharsets.UTF_8);
            BigDecimal soma = BigDecimal.ZERO;
            String[] linhas = csv.split("\r\n");
            for (int i = 1; i < linhas.length; i++) {
                soma = soma.add(new BigDecimal(linhas[i].split(";")[9].replace(',', '.')));
            }
            igual(totalLoja.toPlainString(), soma);
        }
    }
}
