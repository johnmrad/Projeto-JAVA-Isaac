package teste;

import modelo.Cliente;
import modelo.Cupom;
import modelo.Pedido;
import modelo.StatusPagamento;
import modelo.StatusPedido;
import org.junit.jupiter.api.Test;
import ecommerce.Fidelidade;
import servico.CancelamentoServico;
import servico.CarrinhoServico;
import servico.EnvioServico;
import servico.RelatorioServico;
import servico.Usuario;
import util.RegraNegocioException;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

public class PosVendaTest {
    private final CancelamentoServico cancelamento = new CancelamentoServico();
    private final EnvioServico envio = new EnvioServico();
    private final CarrinhoServico carrinho = new CarrinhoServico();
    private final RelatorioServico relatorio = new RelatorioServico();

    private String recusa(Runnable acao) {
        return assertThrows(RegraNegocioException.class, acao::run).getMessage();
    }

    private void igual(String esperado, BigDecimal real) {
        assertEquals(0, new BigDecimal(esperado).compareTo(real), "esperado " + esperado + " mas veio " + real);
    }

    @Test void cancelarNoCarrinhoSoMudaOStatus() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.carrinhoComExemplo(c.donoCliente);
            cancelamento.cancelar(c.donoCliente, p.getId());
            assertEquals(StatusPedido.CANCELADO, c.pedido(p.getId()).getStatus());
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
            assertEquals(10, c.produto(c.teclado.getId()).getEstoque());
        }
    }

    @Test void cancelarAguardandoDevolveEstoqueCupomEPontos() {
        try (CenarioD c = new CenarioD()) {
            c.definirCliente(100, "0");
            Cupom cupom = c.novoCupom(10, 100);
            carrinho.definirQuantidade(c.donoCliente, c.mouse.getId(), 2);
            carrinho.definirQuantidade(c.donoCliente, c.teclado.getId(), 1);
            carrinho.aplicarCupom(c.donoCliente, cupom.getCodigo());
            carrinho.usarPontos(c.donoCliente, 40);
            Pedido p = carrinho.finalizar(c.donoCliente);
            assertEquals(18, c.produto(c.mouse.getId()).getEstoque());
            assertEquals(1, c.cupom(cupom.getId()).getUsosRealizados());
            assertEquals(60, c.cliente().getPontos());

            cancelamento.cancelar(c.donoCliente, p.getId());

            assertEquals(StatusPedido.CANCELADO, c.pedido(p.getId()).getStatus());
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
            assertEquals(10, c.produto(c.teclado.getId()).getEstoque());
            assertEquals(0, c.cupom(cupom.getId()).getUsosRealizados());
            assertEquals(100, c.cliente().getPontos());
            assertEquals(0, c.cliente().getComprasPagas());
        }
    }

    @Test void cancelarPagoEstornaTudoEOClienteVoltaAoQueEra() {
        try (CenarioD c = new CenarioD()) {
            c.definirCliente(7, "450");
            String antes = relatorio.totalDoMes(c.loja, 2026, 6, c.vendedor.getId()).toPlainString();
            assertEquals(Fidelidade.BRONZE, Fidelidade.calcularNivel(c.cliente().getTotalGasto().doubleValue()));

            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            Cliente pago = c.cliente();
            igual("294.50", pago.getTotalGasto().subtract(new BigDecimal("450")));
            assertEquals(7 + 29, pago.getPontos());
            assertEquals(1, pago.getComprasPagas());
            assertEquals(Fidelidade.PRATA, Fidelidade.calcularNivel(pago.getTotalGasto().doubleValue()));
            igual("310.00", relatorio.totalDoMes(c.loja, 2026, 6, c.vendedor.getId()));

            cancelamento.cancelar(c.donoCliente, p.getId());

            Pedido cancelado = c.pedido(p.getId());
            assertEquals(StatusPedido.CANCELADO, cancelado.getStatus());
            assertEquals(StatusPagamento.ESTORNADO, cancelado.getPagamento().getStatus());
            Cliente depois = c.cliente();
            igual("450.00", depois.getTotalGasto());
            assertEquals(7, depois.getPontos());
            assertEquals(0, depois.getComprasPagas());
            assertEquals(Fidelidade.BRONZE, Fidelidade.calcularNivel(depois.getTotalGasto().doubleValue()));
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
            igual(antes, relatorio.totalDoMes(c.loja, 2026, 6, c.vendedor.getId()));
        }
    }

    @Test void cancelarSeparadoTambemEstorna() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            envio.separar(c.donoVendedor, p.getId());

            cancelamento.cancelar(c.loja, p.getId());

            Pedido cancelado = c.pedido(p.getId());
            assertEquals(StatusPedido.CANCELADO, cancelado.getStatus());
            assertEquals(StatusPagamento.ESTORNADO, cancelado.getPagamento().getStatus());
            igual("0.00", c.cliente().getTotalGasto());
            assertEquals(0, c.cliente().getPontos());
            assertEquals(10, c.produto(c.teclado.getId()).getEstoque());
        }
    }

    @Test void depoisDeEnviadoNaoCancela() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            envio.separar(c.donoVendedor, p.getId());
            envio.enviar(c.donoVendedor, p.getId());
            assertEquals("Pedido já enviado não pode ser cancelado.",
                    recusa(() -> cancelamento.cancelar(c.donoCliente, p.getId())));
            envio.entregar(c.donoVendedor, p.getId());
            assertEquals("Pedido já enviado não pode ser cancelado.",
                    recusa(() -> cancelamento.cancelar(c.loja, p.getId())));
            assertEquals(StatusPedido.ENTREGUE, c.pedido(p.getId()).getStatus());
            assertEquals(18, c.produto(c.mouse.getId()).getEstoque());
        }
    }

    @Test void naoCancelaDuasVezes() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            cancelamento.cancelar(c.donoCliente, p.getId());
            assertEquals("Este pedido já está cancelado.", recusa(() -> cancelamento.cancelar(c.loja, p.getId())));
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
        }
    }

    @Test void clienteCancelaSoOsProprios_lojaCancelaQualquer() {
        try (CenarioD c = new CenarioD()) {
            Cliente outro = c.novoCliente("Outro", "outro" + System.nanoTime() + "@teste.com");
            Pedido p = c.finalizarExemplo(c.donoCliente);
            recusa(() -> cancelamento.cancelar(Usuario.cliente(outro.getId()), p.getId()));
            recusa(() -> cancelamento.cancelar(c.donoVendedor, p.getId()));
            recusa(() -> cancelamento.cancelar(null, p.getId()));
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, c.pedido(p.getId()).getStatus());
            cancelamento.cancelar(c.loja, p.getId());
            assertEquals(StatusPedido.CANCELADO, c.pedido(p.getId()).getStatus());
        }
    }

    @Test void pedidoInexistente() {
        assertEquals("Pedido não encontrado.", recusa(() -> cancelamento.cancelar(Usuario.loja(), -1L)));
    }

    @Test void pontosETotalGastoNuncaFicamAbaixoDeZero() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            c.definirCliente(5, "100");
            cancelamento.cancelar(c.donoCliente, p.getId());
            assertEquals(0, c.cliente().getPontos());
            igual("0.00", c.cliente().getTotalGasto());
            assertEquals(0, c.cliente().getComprasPagas());
        }
    }

    @Test void pagarECancelarAoMesmoTempoDeixamOEstadoCoerente() throws Exception {
        for (int rodada = 0; rodada < 5; rodada++) {
            try (CenarioD c = new CenarioD()) {
                Pedido p = c.finalizarExemplo(c.donoCliente);
                var pool = java.util.concurrent.Executors.newFixedThreadPool(2);
                var largada = new java.util.concurrent.CountDownLatch(1);
                var pagar = pool.submit(() -> {
                    largada.await();
                    try { c.pagarNoPix(c.donoCliente, p.getId()); return true; } catch (RegraNegocioException e) { return false; }
                });
                var cancelar = pool.submit(() -> {
                    largada.await();
                    try { cancelamento.cancelar(c.donoCliente, p.getId()); return true; } catch (RegraNegocioException e) { return false; }
                });
                largada.countDown();
                boolean pagou = pagar.get();
                boolean cancelou = cancelar.get();
                pool.shutdown();

                Pedido fim = c.pedido(p.getId());
                Cliente cliente = c.cliente();
                assertTrue(cancelou);
                assertEquals(StatusPedido.CANCELADO, fim.getStatus());
                assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
                assertEquals(10, c.produto(c.teclado.getId()).getEstoque());
                igual("0.00", cliente.getTotalGasto());
                assertEquals(0, cliente.getPontos());
                assertEquals(0, cliente.getComprasPagas());
                if (pagou) {
                    assertEquals(StatusPagamento.ESTORNADO, fim.getPagamento().getStatus());
                }
            }
        }
    }

    @Test void fluxoDeEnvioNaOrdem() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            assertNull(c.pedido(p.getId()).getCodigoRastreio());

            envio.separar(c.donoVendedor, p.getId());
            assertEquals(StatusPedido.SEPARADO, c.pedido(p.getId()).getStatus());
            assertNull(c.pedido(p.getId()).getCodigoRastreio());

            envio.enviar(c.donoVendedor, p.getId());
            Pedido enviado = c.pedido(p.getId());
            assertEquals(StatusPedido.ENVIADO, enviado.getStatus());
            assertEquals(EnvioServico.gerarCodigoRastreio(p.getId()), enviado.getCodigoRastreio());

            envio.entregar(c.donoVendedor, p.getId());
            assertEquals(StatusPedido.ENTREGUE, c.pedido(p.getId()).getStatus());
        }
    }

    @Test void passoForaDaOrdemERecusado() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            recusa(() -> envio.enviar(c.donoVendedor, p.getId()));
            recusa(() -> envio.entregar(c.donoVendedor, p.getId()));
            envio.separar(c.donoVendedor, p.getId());
            recusa(() -> envio.separar(c.donoVendedor, p.getId()));
            recusa(() -> envio.entregar(c.donoVendedor, p.getId()));
            assertEquals(StatusPedido.SEPARADO, c.pedido(p.getId()).getStatus());
        }
    }

    @Test void naoSeparaPedidoQueAindaNaoFoiPago() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            recusa(() -> envio.separar(c.donoVendedor, p.getId()));
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, c.pedido(p.getId()).getStatus());
        }
    }

    @Test void soOVendedorDonoDeUmItemMexeNoEnvio() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            recusa(() -> envio.separar(Usuario.vendedor(c.vendedor.getId() + 100000), p.getId()));
            recusa(() -> envio.separar(c.donoCliente, p.getId()));
            recusa(() -> envio.separar(null, p.getId()));
            assertEquals(StatusPedido.PAGO, c.pedido(p.getId()).getStatus());
            envio.separar(c.loja, p.getId());
            assertEquals(StatusPedido.SEPARADO, c.pedido(p.getId()).getStatus());
        }
    }

    @Test void vendedorDeOutroPedidoDosDadosDeExemploNaoMexe() {
        recusa(() -> envio.separar(Usuario.vendedor(2L), 3L));
    }

    @Test void codigoDeRastreioTemFormatoEUnicoPorPedido() {
        assertEquals("EC000000042BR", EnvioServico.gerarCodigoRastreio(42L));
        assertNotEquals(EnvioServico.gerarCodigoRastreio(1L), EnvioServico.gerarCodigoRastreio(2L));
    }
}
