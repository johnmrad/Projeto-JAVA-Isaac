package teste;

import modelo.ItemVendido;
import modelo.MetodoPagamento;
import modelo.StatusPedido;
import org.junit.jupiter.api.Test;
import servico.CsvVendas;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class CsvVendasTest {

    private ItemVendido item(String cliente, String produto) {
        return new ItemVendido(7L, LocalDateTime.of(2026, 10, 5, 10, 10, 0), cliente, "PA", 1L, "Loja A",
                1L, produto, 1L, "Periféricos", 3, new BigDecimal("80"), new BigDecimal("0"),
                new BigDecimal("1234.5"), new BigDecimal("24"), MetodoPagamento.PIX, StatusPedido.PAGO);
    }

    private String texto(byte[] csv) {
        return new String(csv, 3, csv.length - 3, StandardCharsets.UTF_8);
    }

    @Test void comecaComBomUtf8() {
        byte[] csv = CsvVendas.gerar(List.of());
        assertEquals((byte) 0xEF, csv[0]);
        assertEquals((byte) 0xBB, csv[1]);
        assertEquals((byte) 0xBF, csv[2]);
    }

    @Test void cabecalhoTem13Colunas() {
        assertEquals(13, CsvVendas.CABECALHO.size());
        String[] linhas = texto(CsvVendas.gerar(List.of())).split("\r\n");
        assertEquals(1, linhas.length);
        assertEquals(13, linhas[0].split(";", -1).length);
        assertTrue(linhas[0].startsWith("Pedido;Data do pagamento;Cliente;"));
    }

    @Test void umaLinhaPorItemComSeparadorPontoEVirgulaEDecimalComVirgula() {
        String[] linhas = texto(CsvVendas.gerar(List.of(item("Maria", "Mouse"), item("João", "Teclado")))).split("\r\n");
        assertEquals(3, linhas.length);
        assertEquals("7;05/10/2026 10:10:00;Maria;Loja A;Mouse;Periféricos;3;80,00;0,00;1234,50;24,00;PIX;PAGO", linhas[1]);
        assertEquals(13, linhas[1].split(";", -1).length);
        assertTrue(linhas[2].contains(";João;"));
    }

    @Test void textoComecandoComCaractereDeFormulaGanhaApostrofo() {
        assertEquals("'=SOMA(A1)", CsvVendas.texto("=SOMA(A1)"));
        assertEquals("'+55 91", CsvVendas.texto("+55 91"));
        assertEquals("'-cmd", CsvVendas.texto("-cmd"));
        assertEquals("'@usuario", CsvVendas.texto("@usuario"));
        assertEquals("Mouse = bom", CsvVendas.texto("Mouse = bom"));
        assertEquals("", CsvVendas.texto(null));
        assertEquals("", CsvVendas.texto(""));
    }

    @Test void apostrofoApareceNaLinhaDoItem() {
        String linha = texto(CsvVendas.gerar(List.of(item("=HYPERLINK(\"http://x\")", "@Mouse")))).split("\r\n")[1];
        assertTrue(linha.contains("\"'=HYPERLINK(\"\"http://x\"\")\""), linha);
        assertTrue(linha.contains(";'@Mouse;"), linha);
    }

    @Test void textoComSeparadorOuAspasOuQuebraDeLinhaFicaEntreAspas() {
        assertEquals("\"Silva; Filho\"", CsvVendas.texto("Silva; Filho"));
        assertEquals("\"Ele disse \"\"oi\"\"\"", CsvVendas.texto("Ele disse \"oi\""));
        assertEquals("\"linha 1\nlinha 2\"", CsvVendas.texto("linha 1\nlinha 2"));
        assertEquals("\"'=a;b\"", CsvVendas.texto("=a;b"));
    }

    @Test void numeroNegativoNaoGanhaApostrofo() {
        assertEquals("-15,50", CsvVendas.decimal(new BigDecimal("-15.5")));
    }

    @Test void decimalArredondaMeioCentavoParaCimaESemMilhar() {
        assertEquals("56,28", CsvVendas.decimal(new BigDecimal("56.275")));
        assertEquals("1234,50", CsvVendas.decimal(new BigDecimal("1234.5")));
        assertEquals("1000000,00", CsvVendas.decimal(new BigDecimal("1000000")));
        assertEquals("0,00", CsvVendas.decimal(null));
    }
}
