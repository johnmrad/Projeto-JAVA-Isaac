package teste;

import modelo.MetodoPagamento;
import modelo.Pedido;
import modelo.StatusPedido;
import org.junit.jupiter.api.Test;
import servico.ExpiracaoServico;
import servico.PagamentoServico;
import servico.Usuario;
import util.RegraNegocioException;
import util.Relogio;
import java.time.LocalDateTime;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class ExpiracaoTest {
    private static final LocalDateTime T0 = CenarioD.INICIO;

    private final ExpiracaoServico expiracao = new ExpiracaoServico();
    private final PagamentoServico pagamentos = new PagamentoServico();

    private StatusPedido status(CenarioD c, Pedido p) {
        return c.pedido(p.getId()).getStatus();
    }

    @Test void pedidoSemPagamentoExpiraDepoisDe24Horas() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);

            Relogio.fixar(T0.plusHours(23).plusMinutes(59));
            assertFalse(expiracao.cancelarSeVencido(p.getId()));
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, status(c, p));

            Relogio.fixar(T0.plusHours(24));
            assertFalse(expiracao.cancelarSeVencido(p.getId()));

            Relogio.fixar(T0.plusHours(24).plusMinutes(1));
            assertTrue(expiracao.cancelarSeVencido(p.getId()));
            assertEquals(StatusPedido.CANCELADO, status(c, p));
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
            assertFalse(expiracao.cancelarSeVencido(p.getId()));
        }
    }

    @Test void pagarPedidoVencidoCancelaEAvisaOCliente() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            assertEquals(18, c.produto(c.mouse.getId()).getEstoque());

            Relogio.fixar(T0.plusHours(25));
            RegraNegocioException aviso = assertThrows(RegraNegocioException.class,
                    () -> expiracao.pagar(c.donoCliente, p.getId(), MetodoPagamento.PIX, 1));
            assertEquals(ExpiracaoServico.AVISO_CANCELADO, aviso.getMessage());

            assertEquals(StatusPedido.CANCELADO, status(c, p));
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
            assertEquals(0, c.cliente().getComprasPagas());
            assertNull(c.pedido(p.getId()).getPagamento());
        }
    }

    @Test void pagarPedidoDentroDoPrazoFuncionaNormalmente() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            Relogio.fixar(T0.plusHours(23));
            Pedido pago = expiracao.pagar(c.donoCliente, p.getId(), MetodoPagamento.PIX, 1);
            assertEquals(StatusPedido.PAGO, pago.getStatus());
        }
    }

    @Test void quemNaoEDonoNaoCancelaPedidoAlheioTentandoPagar() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            Relogio.fixar(T0.plusHours(30));
            recusa(() -> expiracao.pagar(c.donoVendedor, p.getId(), MetodoPagamento.PIX, 1));
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, status(c, p));
        }
    }

    private void recusa(Runnable acao) {
        assertThrows(RegraNegocioException.class, acao::run);
    }

    @Test void boletoVenceDepoisDoDiaDoVencimento() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            pagamentos.pagar(c.donoCliente, p.getId(), MetodoPagamento.BOLETO, 1);
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, status(c, p));

            Relogio.fixar(LocalDateTime.of(2026, 6, 12, 23, 59));
            assertFalse(expiracao.cancelarSeVencido(p.getId()));

            Relogio.fixar(LocalDateTime.of(2026, 6, 13, 23, 59));
            assertFalse(expiracao.cancelarSeVencido(p.getId()));
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, status(c, p));

            Relogio.fixar(LocalDateTime.of(2026, 6, 14, 0, 0));
            assertTrue(expiracao.cancelarSeVencido(p.getId()));
            assertEquals(StatusPedido.CANCELADO, status(c, p));
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
        }
    }

    @Test void boletoCompensaNoDiaDoVencimento() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            pagamentos.pagar(c.donoCliente, p.getId(), MetodoPagamento.BOLETO, 1);
            Relogio.fixar(LocalDateTime.of(2026, 6, 13, 18, 0));
            Pedido pago = expiracao.compensarBoleto(c.loja, p.getId());
            assertEquals(StatusPedido.PAGO, pago.getStatus());
            assertEquals(1, c.cliente().getComprasPagas());
        }
    }

    @Test void compensarBoletoVencidoCancelaEAvisa() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            pagamentos.pagar(c.donoCliente, p.getId(), MetodoPagamento.BOLETO, 1);
            Relogio.fixar(LocalDateTime.of(2026, 6, 14, 9, 0));
            RegraNegocioException aviso = assertThrows(RegraNegocioException.class,
                    () -> expiracao.compensarBoleto(c.loja, p.getId()));
            assertEquals(ExpiracaoServico.AVISO_CANCELADO, aviso.getMessage());
            assertEquals(StatusPedido.CANCELADO, status(c, p));
            assertEquals(0, c.cliente().getComprasPagas());
        }
    }

    @Test void soALojaCompensaBoleto() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            pagamentos.pagar(c.donoCliente, p.getId(), MetodoPagamento.BOLETO, 1);
            recusa(() -> expiracao.compensarBoleto(c.donoCliente, p.getId()));
            recusa(() -> expiracao.compensarBoleto(c.donoVendedor, p.getId()));
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, status(c, p));
        }
    }

    @Test void rotinaGeralCancelaTodosOsVencidosDeUmaVez() {
        try (CenarioD c = new CenarioD()) {
            Pedido semPagamento = c.finalizarExemplo(c.donoCliente);
            var cliente2 = c.novoCliente("Dois", "dois" + System.nanoTime() + "@teste.com");
            Pedido boleto = c.finalizarExemplo(Usuario.cliente(cliente2.getId()));
            pagamentos.pagar(Usuario.cliente(cliente2.getId()), boleto.getId(), MetodoPagamento.BOLETO, 1);
            var cliente3 = c.novoCliente("Tres", "tres" + System.nanoTime() + "@teste.com");
            Pedido pago = c.exemploPagoNoPix(Usuario.cliente(cliente3.getId()));
            Relogio.fixar(T0.plusHours(20));
            var cliente4 = c.novoCliente("Quatro", "quatro" + System.nanoTime() + "@teste.com");
            Pedido recente = c.finalizarExemplo(Usuario.cliente(cliente4.getId()));

            Relogio.fixar(T0.plusHours(26));
            List<Long> primeira = expiracao.cancelarVencidos(c.loja);
            assertTrue(primeira.contains(semPagamento.getId()));
            assertFalse(primeira.contains(boleto.getId()));
            assertFalse(primeira.contains(pago.getId()));
            assertFalse(primeira.contains(recente.getId()));

            Relogio.fixar(LocalDateTime.of(2026, 6, 14, 0, 0));
            List<Long> segunda = expiracao.cancelarVencidos(c.loja);
            assertTrue(segunda.contains(boleto.getId()));
            assertTrue(segunda.contains(recente.getId()));
            assertFalse(segunda.contains(semPagamento.getId()));
            assertFalse(segunda.contains(pago.getId()));

            assertEquals(StatusPedido.CANCELADO, status(c, semPagamento));
            assertEquals(StatusPedido.CANCELADO, status(c, boleto));
            assertEquals(StatusPedido.CANCELADO, status(c, recente));
            assertEquals(StatusPedido.PAGO, status(c, pago));
            assertEquals(18, c.produto(c.mouse.getId()).getEstoque());
            assertTrue(expiracao.cancelarVencidos(c.loja).isEmpty());
        }
    }

    @Test void soALojaRodaARotina() {
        recusa(() -> expiracao.cancelarVencidos(Usuario.cliente(1L)));
        recusa(() -> expiracao.cancelarVencidos(Usuario.vendedor(1L)));
        recusa(() -> expiracao.cancelarVencidos(null));
    }
}
