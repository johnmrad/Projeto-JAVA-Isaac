package teste;

import modelo.Categoria;
import modelo.Cliente;
import modelo.Cupom;
import modelo.MetodoPagamento;
import modelo.Pedido;
import modelo.Produto;
import modelo.Vendedor;
import servico.CarrinhoServico;
import servico.CategoriaServico;
import servico.ClienteServico;
import servico.PagamentoServico;
import servico.ProdutoServico;
import servico.Usuario;
import servico.VendedorServico;
import util.Jpa;
import util.Relogio;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class CenarioD implements AutoCloseable {
    static final LocalDateTime INICIO = LocalDateTime.of(2026, 6, 10, 10, 0);
    private static final Random SORTEIO = new Random();

    final Usuario loja = Usuario.loja();
    final Vendedor vendedor;
    final Categoria categoria;
    final Cliente cliente;
    final Produto mouse;
    final Produto teclado;
    final Usuario donoVendedor;
    final Usuario donoCliente;

    private final CarrinhoServico carrinho = new CarrinhoServico();
    private final PagamentoServico pagamento = new PagamentoServico();
    private final List<Long> cupons = new ArrayList<>();
    private final List<Long> clientesExtras = new ArrayList<>();

    CenarioD() {
        Relogio.fixar(INICIO);
        String sufixo = Long.toString(System.nanoTime(), 36);
        vendedor = new VendedorServico().cadastrar(loja, "Vendedor " + sufixo, "v" + sufixo + "@teste.com", new BigDecimal("10"));
        categoria = new CategoriaServico().cadastrar(loja, "Categoria " + sufixo);
        cliente = novoCliente("Cliente " + sufixo, "c" + sufixo + "@teste.com");
        ProdutoServico produtos = new ProdutoServico();
        mouse = produtos.cadastrar(loja, "Mouse " + sufixo, "d", new BigDecimal("80.00"), 20, categoria.getId(), vendedor.getId());
        teclado = produtos.cadastrar(loja, "Teclado " + sufixo, "d", new BigDecimal("150.00"), 10, categoria.getId(), vendedor.getId());
        donoVendedor = Usuario.vendedor(vendedor.getId());
        donoCliente = Usuario.cliente(cliente.getId());
    }

    Cliente novoCliente(String nome, String email) {
        Cliente c = new ClienteServico().cadastrar(nome, email, cpfValido(), "Belém", "PA", "Rua Teste, 1");
        clientesExtras.add(c.getId());
        return c;
    }

    Pedido finalizarExemplo(Usuario dono) {
        carrinho.definirQuantidade(dono, mouse.getId(), 2);
        carrinho.definirQuantidade(dono, teclado.getId(), 1);
        return carrinho.finalizar(dono);
    }

    Pedido carrinhoComExemplo(Usuario dono) {
        carrinho.definirQuantidade(dono, mouse.getId(), 2);
        return carrinho.definirQuantidade(dono, teclado.getId(), 1);
    }

    Pedido pagarNoPix(Usuario dono, Long pedidoId) {
        return pagamento.pagar(dono, pedidoId, MetodoPagamento.PIX, 1);
    }

    Pedido exemploPagoNoPix(Usuario dono) {
        return pagarNoPix(dono, finalizarExemplo(dono).getId());
    }

    Cupom novoCupom(int percentual, int valorMinimo) {
        Cupom cupom = new Cupom("T" + Long.toString(System.nanoTime(), 36).toUpperCase(),
                new BigDecimal(percentual), new BigDecimal(valorMinimo), LocalDate.of(2026, 12, 31), 5, false);
        Jpa.executar(em -> em.persist(cupom));
        cupons.add(cupom.getId());
        return cupom;
    }

    Cliente cliente(Long id) { return Jpa.consultar(em -> em.find(Cliente.class, id)); }
    Cliente cliente() { return cliente(cliente.getId()); }
    Produto produto(Long id) { return Jpa.consultar(em -> em.find(Produto.class, id)); }
    Pedido pedido(Long id) { return Jpa.consultar(em -> em.find(Pedido.class, id)); }
    Cupom cupom(Long id) { return Jpa.consultar(em -> em.find(Cupom.class, id)); }

    void definirCliente(int pontos, String totalGasto) {
        Jpa.executar(em -> {
            Cliente c = em.find(Cliente.class, cliente.getId());
            c.setPontos(pontos);
            c.setTotalGasto(new BigDecimal(totalGasto));
        });
    }

    @Override
    public void close() {
        Relogio.liberar();
        List<Long> todosClientes = new ArrayList<>(clientesExtras);
        Jpa.executar(em -> {
            for (Long id : todosClientes) {
                apagar(em, "delete from pagamento where pedido_id in (select id from pedido where cliente_id = ?1)", id);
                apagar(em, "delete from item_pedido where pedido_id in (select id from pedido where cliente_id = ?1)", id);
                apagar(em, "delete from pedido where cliente_id = ?1", id);
                apagar(em, "delete from cliente where id = ?1", id);
            }
            for (Long id : cupons) {
                apagar(em, "delete from cupom where id = ?1", id);
            }
            apagar(em, "delete from produto where vendedor_id = ?1", vendedor.getId());
            apagar(em, "delete from vendedor where id = ?1", vendedor.getId());
            apagar(em, "delete from categoria where id = ?1", categoria.getId());
        });
    }

    private static void apagar(jakarta.persistence.EntityManager em, String sql, Long id) {
        em.createNativeQuery(sql).setParameter(1, id).executeUpdate();
    }

    static String cpfValido() {
        int[] d = new int[11];
        do {
            for (int i = 0; i < 9; i++) {
                d[i] = SORTEIO.nextInt(10);
            }
        } while (todosIguais(d));
        d[9] = digito(d, 9);
        d[10] = digito(d, 10);
        StringBuilder cpf = new StringBuilder();
        for (int x : d) {
            cpf.append(x);
        }
        return cpf.toString();
    }

    private static boolean todosIguais(int[] d) {
        for (int i = 1; i < 9; i++) {
            if (d[i] != d[0]) {
                return false;
            }
        }
        return true;
    }

    private static int digito(int[] d, int quantidade) {
        int soma = 0;
        for (int i = 0; i < quantidade; i++) {
            soma += d[i] * (quantidade + 1 - i);
        }
        int resto = (soma * 10) % 11;
        return resto == 10 ? 0 : resto;
    }
}
