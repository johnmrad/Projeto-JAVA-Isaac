# E-commerce — Parte da Pessoa B: cálculo, cupom e fidelidade

Tudo o que envolve **valores** do pedido: descontos, frete, pagamento, pontos e comissão.
Não usa banco de dados: as outras pessoas do grupo só chamam estas classes.

## Como rodar no VS Code

- **Menu:** abra `MenuCalculo.java` e clique em **Run** acima do `main`. A opção **9** carrega o exemplo da §14 e a opção **8** simula o pagamento.
- **Testes:** abra `CalculoPedidoTest.java` ou `CupomEFidelidadeTest.java` e clique em **Run Test**, ou use o ícone de frasco na barra lateral.

## As classes

| Classe | O que faz |
|---|---|
| `Configuracao` | Arquivo único com todos os números das regras. Trocar um valor aqui não mexe na lógica. |
| `Dinheiro` | Função única de arredondamento (2 casas, meio centavo para cima). |
| `ItemPedidoCalculo` | Um item: calcula seu subtotal, desconto por volume e comissão. |
| `CalculoPedido` | O motor: faz as contas do pedido na ordem da §4. |
| `PagamentoCalculo` | PIX, cartão (parcelas e juros) e boleto. |
| `Fidelidade` | Nível do cliente e pontos ganhos. |
| `CupomCalculo` | Um cupom e a validação de uso. |
| `CadastroCupons` | Lista (ArrayList) de cupons, com código único. |
| `MenuCalculo` | Menu no terminal para testar e apresentar. |

## Regras implementadas

**Ordem do cálculo (§4)**
1. **Subtotal bruto:** preço × quantidade de cada item.
2. **Desconto por volume, por item:** 5% a partir de 5 unidades, 10% a partir de 10.
3. **Base:** bruto − desconto por volume.
4. **Desconto comercial:** o **maior** entre fidelidade e cupom, sem somar. Em empate, fica a fidelidade, para não gastar o cupom.
5. **Pontos resgatados:** R$ 0,10 cada, no máximo 30% de (base − desconto comercial), limitado ao saldo.
6. **Valor dos produtos:** base − desconto comercial − pontos.
7. **Frete:** grátis a partir de R$ 250; senão, tabela por UF.
8. **Total:** valor dos produtos + frete.

**Pagamento (§6)**
- **PIX:** 5% de desconto só sobre o valor dos produtos, sem tocar no frete.
- **Cartão:** de 1x até o menor entre 12 e (total ÷ 20). Até 3x sem juros; a partir de 4x, total × 1,0199ⁿ.
- **Boleto:** sem ajuste, vence em 3 dias.

**Fidelidade**
- **Níveis:** Bronze; Prata a partir de R$ 500 gastos; Ouro a partir de R$ 1.500.
- **Pontos ganhos:** parte inteira de (valor cobrado ÷ 10).

**Comissão (§9):** subtotal do item × (valor dos produtos ÷ base) × % do vendedor, arredondada por item. Frete, juros e desconto do PIX ficam de fora.

**Cupom**
- **Cadastro:** código único; desconto acima de 0% e até 50%.
- **Uso:** precisa estar ativo, dentro da validade (o último dia vale), com usos disponíveis e com a base acima do valor mínimo. Se for "só primeira compra", o cliente precisa ter 0 compras pagas.

## Testes da §14 (todos passando)

| Cenário | Resultado |
|---|---|
| Base R$ 310 no PIX | R$ 294,50, 29 pontos, comissão R$ 31,00 |
| Com cupom de 10% | desconto R$ 31,00, comissão R$ 27,90 |
| Cartão de R$ 300 em 6x | R$ 337,65, parcela R$ 56,28 |

## Como as Pessoas C e D usam

```java
CalculoPedido calculo = new CalculoPedido(cliente.getUf());
calculo.adicionarItem(new ItemPedidoCalculo(produto.getNome(), produto.getPreco(), quantidade, vendedor.getComissao()));
calculo.setNivelFidelidade(Fidelidade.calcularNivel(cliente.getTotalGasto()));
calculo.setCupom(cupom, cliente.getComprasPagas());
calculo.setPontos(pontosQueQuerUsar, cliente.getSaldoPontos());
calculo.setPagamento(PagamentoCalculo.PIX, 1);
calculo.calcular();
```

**Pessoa C**
- Chamar `calcular()` de novo a cada mudança no carrinho.
- Se `isCupomRemovido()` for verdadeiro, tirar o cupom do carrinho.
- Ao finalizar, só chamar `cupom.consumirUso()` se `getOrigemDesconto()` for `"CUPOM"`.
- Ao confirmar o pagamento, gravar `getValorCobrado()` e, de cada item, `getValorLiquido()` e `getComissao()`. Depois somar `getPontosGanhos()` ao saldo do cliente.

**Pessoa D**
- No cancelamento, usar `cupom.devolverUso()`, `Fidelidade.retirarPontos(...)` e `Fidelidade.calcularNivel(...)`.

## ⚠️ Conferir com o documento de regras do grupo

O PDF de divisão de tarefas não informa o **desconto de cada nível** (usei Bronze 0%, Prata 5%, Ouro 10%) nem a **tabela de frete por UF** (usei valores por região). Se forem diferentes, troque só na classe `Configuracao`.
