# E-commerce — Parte da Pessoa D: envio, cancelamento, expiração, indicadores e exportações

Tudo o que acontece **depois que o cliente finaliza o pedido**: separar, enviar, entregar,
cancelar, expirar, indicadores do mês e exportações (CSV e XML). Usa o banco e as classes das
Pessoas A, B e C sem alterá-las.

## Como rodar

- **Testes:** com o PostgreSQL ligado e `sql/dados_exemplo.sql` carregado, rode `mvn test` ou use o ícone de frasco do VS Code.
  - Sem banco: `CsvVendasTest`, `NotaFiscalXmlTest` e `ExpiracaoRegraTest`.
  - Com banco: `PosVendaTest`, `ExpiracaoTest`, `IndicadoresTest`, `ExportacaoTest` e `FluxoCompletoTest`.
- Os testes com banco criam os próprios dados (`CenarioD`) e apagam tudo no final, então não mexem nos dados de exemplo
  nem nos testes das outras pessoas. O relógio fica fixo em junho de 2026.

## As classes

| Classe | O que faz |
|---|---|
| `EnvioServico` | `separar`, `enviar` (gera o código de rastreio) e `entregar`. |
| `CancelamentoServico` | `cancelar` e os efeitos do cancelamento (estoque, cupom, pontos, estorno). |
| `ExpiracaoServico` | Regra de "vencido", `pagar` e `compensarBoleto` com expiração, e a rotina `cancelarVencidos`. |
| `IndicadorServico` | Comissão a pagar, taxa de cancelamento, vendas por categoria, pedidos por forma de pagamento. |
| `ExportacaoServico` | CSV de vendas do mês e XML da nota fiscal simulada (na tela ou salvando arquivo). |
| `CsvVendas` / `NotaFiscalXml` | Só formatam o CSV e o XML (sem banco, por isso são fáceis de testar). |
| `PedidoLock`, `EscopoRelatorio` | Apoio interno: trava do pedido e "quem vê o quê". |
| `ItemVendidoRepositorio`, `PedidoRepositorio` | Consultas novas, no mesmo estilo dos repositórios da Pessoa A. |

## Regras implementadas

**Separar, enviar e entregar (§2):** só o vendedor dono de pelo menos um item do pedido (a loja também, porque "loja pode tudo").
Fora da ordem é recusado pela tabela de `FluxoPedido`. Ao enviar, gera o código de rastreio `EC` + id com 9 dígitos + `BR`.

**Cancelar (§2, §8):** vale no carrinho, aguardando, pago e separado; depois de enviado, recusa. Cliente cancela só os próprios; a loja cancela qualquer um.

| Status | O que acontece |
|---|---|
| Carrinho | Só muda o status. |
| Aguardando pagamento | Devolve estoque, uso do cupom e pontos resgatados. |
| Pago ou separado | Tudo acima, mais: pagamento vira `ESTORNADO`, subtrai total gasto e compras pagas, retira os pontos ganhos (nunca abaixo de 0). O nível se recalcula sozinho pelo total gasto. |

**Expiração (§7):** pedido finalizado sem pagamento vence 24h depois; boleto pendente vence quando a data de hoje passa do vencimento (no dia ainda vale).
Tentar pagar ou compensar pedido vencido **cancela e avisa o cliente**. `cancelarVencidos` cancela todos de uma vez (só a loja).

> ⚠️ **Use `ExpiracaoServico.pagar` e `compensarBoleto` no lugar dos de `PagamentoServico`.** Os da Pessoa C só recusam o pedido vencido, e recusar desfaz a transação,
> então o cancelamento não ficaria gravado. Os da `ExpiracaoServico` cancelam numa transação própria e depois chamam os da Pessoa C.

**Indicadores (§12):** usam os valores já gravados no pedido e a mesma definição de venda da Pessoa A (PAGO, SEPARADO, ENVIADO ou ENTREGUE, mês da data de pagamento).
- *Comissão a pagar:* soma das comissões gravadas nos itens vendidos, por vendedor (vendedor sem venda aparece com 0,00).
- *Taxa de cancelamento:* pedidos cancelados ÷ pedidos finalizados criados no mês, em %. Mês sem pedidos devolve 0,00.
- *Vendas por categoria:* quantidade e valor líquido por categoria.
- *Pedidos por forma de pagamento:* número de pedidos e valor por PIX, cartão e boleto (as três, com zeros); a soma bate com o total do mês.
- Loja vê tudo (ou filtra um vendedor); vendedor só o dele; cliente não vê.

**CSV de vendas do mês (§13):** uma linha por item vendido, separador `;`, decimal com vírgula, UTF-8 com BOM, prefixo `'` em texto que começa com `=`, `+`, `-` ou `@`.
A soma da coluna "Valor líquido" é igual ao total do mês do relatório (testado para loja e vendedores).

**XML da nota fiscal (§13):** só para pedido com pagamento confirmado, com o aviso `DOCUMENTO SIMULADO - SEM VALIDADE FISCAL` dentro do arquivo.
Quem pode ver o pedido (cliente dono, vendedor com item, loja) pode pedir a nota.

## Exemplo de uso

```java
Usuario loja = Usuario.loja();
new EnvioServico().separar(Usuario.vendedor(1L), pedidoId);
new EnvioServico().enviar(Usuario.vendedor(1L), pedidoId);          // gera o rastreio
new CancelamentoServico().cancelar(Usuario.cliente(1L), pedidoId);
new ExpiracaoServico().cancelarVencidos(loja);                       // rotina geral
new IndicadorServico().comissaoAPagar(loja, 2026, 10, null);
byte[] csv = new ExportacaoServico().csvVendasDoMes(Usuario.vendedor(1L), 2026, 10, null);
String xml = new ExportacaoServico().xmlNotaFiscal(Usuario.cliente(1L), pedidoId);
```

## ⚠️ Decisões minhas — conferir com o documento de regras do grupo

O PDF de divisão de tarefas **não traz** as seções de regras (§12 e §13). Onde faltava detalhe, escolhi o seguinte; se o documento disser outra coisa, só estas classes mudam:

- **13 colunas do CSV:** Pedido, Data do pagamento, Cliente, Vendedor, Produto, Categoria, Quantidade, Preço unitário, Desconto por volume, Valor líquido, Comissão, Forma de pagamento, Status do pedido (`CsvVendas.CABECALHO`).
- **Campos do XML:** identificação, emitente, destinatário (nome, CPF, e-mail, endereço), itens, totais, pagamento e rastreio (`NotaFiscalXml`).
- **Código de rastreio:** `EC` + id do pedido com 9 dígitos + `BR`.
- **Loja** pode separar, enviar e entregar qualquer pedido; o vendedor, só os dele.
- **Taxa de cancelamento:** carrinho cancelado (nunca finalizado) não entra no cálculo.
