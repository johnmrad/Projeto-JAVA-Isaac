## Getting Started

Welcome to the VS Code Java world. Here is a guideline to help you get started to write Java code in Visual Studio Code.

## Folder Structure

The workspace contains two folders by default, where:

- `src`: the folder to maintain sources
- `lib`: the folder to maintain dependencies

Meanwhile, the compiled output files will be generated in the `bin` folder by default.

> If you want to customize the folder structure, open `.vscode/settings.json` and update the related settings there.

## Dependency Management

The `JAVA PROJECTS` view allows you to manage your dependencies. More details can be found [here](https://github.com/microsoft/vscode-java-dependency#manage-dependencies).


---

## Regras de negócio (resumo do que está implementado)

- **Pedido:** CARRINHO → AGUARDANDO_PAGAMENTO → PAGO → SEPARADO → ENVIADO → ENTREGUE, mais CANCELADO. Qualquer passo fora da ordem é recusado.
- **Cálculo (§4):** subtotal bruto, desconto por volume por item, base, desconto comercial (o maior entre fidelidade e cupom, sem somar), pontos resgatados, valor dos produtos, frete e total.
- **Pagamento (§6):** PIX com 5% sobre os produtos; cartão em até 12x (mínimo R$ 20 por parcela), sem juros até 3x; boleto sem ajuste, vence em 3 dias.
- **Carrinho e finalização (§3):** um carrinho aberto por cliente, máximo de 20 unidades por produto; ao finalizar baixa estoque, consome cupom e debita pontos numa única transação.
- **Cancelamento (§8):** vale até o status SEPARADO; devolve estoque, cupom e pontos e, se já estava pago, estorna o pagamento e desfaz total gasto, compras e pontos ganhos.
- **Expiração (§7):** pedido sem pagamento vence em 24h; boleto vence depois do dia do vencimento; tentar pagar pedido vencido cancela e avisa.
- **Relatórios e indicadores (§11, §12):** venda é pedido PAGO, SEPARADO, ENVIADO ou ENTREGUE, no mês da data de pagamento, pelo valor líquido dos produtos.
- **Exportações (§13):** CSV de vendas do mês e XML da nota fiscal simulada.
- Detalhes de cada parte: `README-calculo.md` (Pessoa B) e `README-posvenda.md` (Pessoa D).

## Valores escolhidos pelo grupo (todos em `ecommerce/Configuracao.java`)

| Item | Valor |
|---|---|
| Desconto por volume | 5% a partir de 5 unidades; 10% a partir de 10 |
| PIX | 5% sobre o valor dos produtos |
| Níveis de fidelidade | Prata a partir de R$ 500; Ouro a partir de R$ 1.500 |
| Desconto por nível | Bronze 0%; Prata 3%; Ouro 5% |
| Expiração do pedido | 24 horas |
| Máximo por produto no carrinho | 20 unidades |
| Frete | Grátis a partir de R$ 250; senão tabela por região (PA R$ 12, Norte R$ 18, Nordeste R$ 22, Centro-Oeste R$ 24, Sudeste R$ 28, Sul R$ 32) |
| Pontos | Cada ponto vale R$ 0,10; resgate de no máximo 30%; ganha 1 ponto a cada R$ 10 cobrados |
| Cartão | Até 12x, parcela mínima de R$ 20, sem juros até 3x, 1,99% ao mês a partir de 4x |
| Boleto | Vence em 3 dias |
| Cupom | Desconto de 0% (exclusive) até 50% |
| Comissão do vendedor | De 0% a 30% |
| Estoque baixo | 5 unidades ou menos |


---

## Como rodar o sistema (App.java)

**1. Banco de dados.** Ligue o PostgreSQL e crie um banco chamado `ecommerce`. O programa usa, por padrão, o usuário `postgres`, senha vazia e `jdbc:postgresql://localhost:5432/ecommerce`.
Se os seus forem outros, defina as variáveis de ambiente `DB_USUARIO`, `DB_SENHA` e `DB_URL`. As tabelas são criadas sozinhas na primeira execução.

**2. Executar.** No VS Code, abra `App.java` e clique em **Run** acima do `main`. Ou, pelo terminal, na pasta do projeto:

```
mvn compile exec:java -Dexec.mainClass=App
```

**3. Dados de exemplo.** No menu inicial, escolha **5 - Carregar dados de exemplo** (apaga tudo e recomeça; precisa rodar na pasta do projeto para achar `sql/dados_exemplo.sql`).

**Quem entra:** não há senha (é uma simulação). Cliente e vendedor entram pelo e-mail; a loja entra direto.

| Perfil | Para testar com os dados de exemplo | O que faz |
|---|---|---|
| Cliente | `maria@email.com`, `joao@email.com`, `ana@email.com` | Catálogo, carrinho, cupom, pontos, finalizar, pagar (PIX, cartão, boleto), pedidos, cancelar, nota fiscal XML |
| Vendedor | `a@loja.com`, `b@loja.com` | Produtos, separar/enviar/entregar, estoque baixo, relatório do mês, CSV, nota fiscal |
| Loja | (entra direto) | Tudo do vendedor, mais cancelar qualquer pedido, cadastrar vendedor/categoria/cupom, clientes, compensar boleto, rotina de expiração e **simular passagem do tempo** |

**Roteiro rápido para apresentar (exemplo da §14):**
1. Menu inicial, opção 4: cadastre um cliente novo. (O cupom `BEMVINDO10` só vale na primeira compra, e os clientes de exemplo já compraram.)
2. Entre como esse cliente: coloque 2 mouses (produto 1) e 1 teclado (produto 2) no carrinho = R$ 310,00; aplique `BEMVINDO10` (desconto de R$ 31,00).
3. Finalize e pague no PIX. Saia e entre como vendedor `a@loja.com`: separe, envie (gera o rastreio) e entregue.
4. Entre como loja: veja o relatório do mês, exporte o CSV e a nota fiscal. Os arquivos ficam na pasta `exportacoes/`.
5. Para mostrar a expiração: finalize um pedido sem pagar, entre como loja, **Administração > Simular passagem do tempo** (avance 2 dias) e rode a **rotina de expiração**.

Os arquivos de código do menu ficam na pasta `src/main/java/menu`.
