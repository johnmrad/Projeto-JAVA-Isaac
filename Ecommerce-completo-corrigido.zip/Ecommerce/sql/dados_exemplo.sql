TRUNCATE pagamento, item_pedido, pedido, cupom, produto, cliente, vendedor, categoria
  RESTART IDENTITY CASCADE;

INSERT INTO categoria (id, nome) VALUES (1,'Periféricos'),(2,'Informática');

INSERT INTO vendedor (id, nome, email, comissao_percentual) VALUES
(1,'Loja A','a@loja.com',10.00),
(2,'Loja B','b@loja.com',8.00);

INSERT INTO cliente (id,nome,email,cpf,cidade,uf,endereco,pontos,total_gasto,compras_pagas,ativo) VALUES
(1,'Maria Silva','maria@email.com','52998224725','Belém','PA','Rua A, 10',54,546.50,2,TRUE),
(2,'João Souza','joao@email.com','11144477735','São Paulo','SP','Av. B, 20',128,1280.00,2,TRUE),
(3,'Ana Costa','ana@email.com','12345678909','Fortaleza','CE','Rua C, 30',105,1050.00,1,TRUE),
(4,'Pedro Lima','pedro@email.com','39053344705','Porto Alegre','RS','Rua D, 40',0,0,0,FALSE);

INSERT INTO produto (id,nome,descricao,preco,estoque,ativo,categoria_id,vendedor_id) VALUES
(1,'Mouse','Mouse USB',80.00,20,TRUE,1,1),
(2,'Teclado','Teclado ABNT2',150.00,3,TRUE,1,1),
(3,'Monitor','Monitor 24 pol',900.00,8,TRUE,2,2),
(4,'Headset','Headset gamer',200.00,0,TRUE,1,2),
(5,'Webcam','Webcam HD',120.00,2,FALSE,2,2);

INSERT INTO cupom (id,codigo,percentual_desconto,valor_minimo,validade,usos_maximos,usos_realizados,somente_primeira_compra,ativo) VALUES
(1,'BEMVINDO10',10.00,100.00,'2026-12-31',100,0,TRUE,TRUE);

INSERT INTO pedido (id,cliente_id,status,data_criacao,data_finalizacao,data_pagamento,pontos_usados,subtotal_bruto,desconto_volume,base,desconto_comercial,valor_pontos,valor_produtos,frete,total,valor_cobrado) VALUES
(1,1,'ENTREGUE','2026-09-10 09:00:00','2026-09-10 09:05:00','2026-09-10 09:10:00',0,310,0,310,0,0,310,0,310,294.50),
(2,2,'ENVIADO','2026-09-20 14:00:00','2026-09-20 14:05:00','2026-09-20 14:10:00',0,900,0,900,0,0,900,0,900,900),
(3,1,'PAGO','2026-10-05 10:00:00','2026-10-05 10:05:00','2026-10-05 10:10:00',0,240,0,240,0,0,240,12,252,252),
(4,3,'SEPARADO','2026-10-08 16:00:00','2026-10-08 16:05:00','2026-10-08 16:10:00',0,1050,0,1050,0,0,1050,0,1050,1050),
(5,2,'CANCELADO','2026-10-02 11:00:00','2026-10-02 11:05:00','2026-10-02 11:10:00',0,80,0,80,2.40,0,77.60,28,105.60,105.60),
(6,3,'AGUARDANDO_PAGAMENTO','2026-10-12 08:00:00','2026-10-12 08:05:00',NULL,0,150,0,150,4.50,0,145.50,22,167.50,167.50),
(7,2,'ENTREGUE','2026-08-15 12:00:00','2026-08-15 12:05:00','2026-08-15 12:10:00',0,400,20,380,0,0,380,0,380,380);

INSERT INTO item_pedido (pedido_id,produto_id,quantidade,preco_unitario,desconto_volume,valor_liquido,comissao) VALUES
(1,1,2,80,0,160,16.00),
(1,2,1,150,0,150,15.00),
(2,3,1,900,0,900,72.00),
(3,1,3,80,0,240,24.00),
(4,3,1,900,0,900,72.00),
(4,2,1,150,0,150,15.00),
(5,1,1,80,0,77.60,7.76),
(6,2,1,150,0,145.50,0),
(7,1,5,80,20,380,38.00);

INSERT INTO pagamento (pedido_id,metodo,status,parcelas,valor_base,ajuste,valor_final,vencimento) VALUES
(1,'PIX','APROVADO',1,310,-15.50,294.50,NULL),
(2,'CARTAO','APROVADO',3,900,0,900,NULL),
(3,'BOLETO','APROVADO',1,252,0,252,'2026-10-08'),
(4,'CARTAO','APROVADO',2,1050,0,1050,NULL),
(5,'CARTAO','ESTORNADO',1,105.60,0,105.60,NULL),
(7,'BOLETO','APROVADO',1,380,0,380,'2026-08-18');

SELECT setval(pg_get_serial_sequence('categoria','id'),   (SELECT MAX(id) FROM categoria));
SELECT setval(pg_get_serial_sequence('vendedor','id'),    (SELECT MAX(id) FROM vendedor));
SELECT setval(pg_get_serial_sequence('cliente','id'),     (SELECT MAX(id) FROM cliente));
SELECT setval(pg_get_serial_sequence('produto','id'),     (SELECT MAX(id) FROM produto));
SELECT setval(pg_get_serial_sequence('cupom','id'),       (SELECT MAX(id) FROM cupom));
SELECT setval(pg_get_serial_sequence('pedido','id'),      (SELECT MAX(id) FROM pedido));
SELECT setval(pg_get_serial_sequence('item_pedido','id'), (SELECT MAX(id) FROM item_pedido));
SELECT setval(pg_get_serial_sequence('pagamento','id'),   (SELECT MAX(id) FROM pagamento));