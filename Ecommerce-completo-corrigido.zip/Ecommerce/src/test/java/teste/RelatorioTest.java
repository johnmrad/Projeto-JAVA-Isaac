package teste;

import modelo.RankingCliente;
import modelo.VendaProduto;
import org.junit.jupiter.api.Test;
import servico.RelatorioServico;
import servico.Usuario;
import util.RegraNegocioException;
import java.math.BigDecimal;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class RelatorioTest {
    private final RelatorioServico r = new RelatorioServico();
    private final Usuario loja = Usuario.loja();

    private void igual(String esperado, BigDecimal real) {
        assertEquals(0, new BigDecimal(esperado).compareTo(real), "esperado " + esperado + " mas veio " + real);
    }

    @Test void setembroLoja() {
        igual("1210.00", r.totalDoMes(loja, 2026, 9, null));
        igual("605.00", r.ticketMedio(loja, 2026, 9, null));
        igual("900.00", r.maiorPedido(loja, 2026, 9, null));
        igual("310.00", r.menorPedido(loja, 2026, 9, null));
    }

    @Test void outubroLojaIgnoraCanceladoEAguardando() {
        igual("1290.00", r.totalDoMes(loja, 2026, 10, null));
        igual("645.00", r.ticketMedio(loja, 2026, 10, null));
        igual("1050.00", r.maiorPedido(loja, 2026, 10, null));
        igual("240.00", r.menorPedido(loja, 2026, 10, null));
    }

    @Test void porVendedor() {
        igual("310.00", r.totalDoMes(loja, 2026, 9, 1L));
        igual("900.00", r.totalDoMes(loja, 2026, 9, 2L));
        igual("390.00", r.totalDoMes(loja, 2026, 10, 1L));
        igual("195.00", r.ticketMedio(loja, 2026, 10, 1L));
    }

    @Test void vendedorSoVeOsProprios() {
        igual("310.00", r.totalDoMes(Usuario.vendedor(1L), 2026, 9, 2L));
    }

    @Test void clienteNaoVeRelatorio() {
        assertThrows(RegraNegocioException.class, () -> r.totalDoMes(Usuario.cliente(1L), 2026, 9, null));
    }

    @Test void mesSemVendasDevolveZeros() {
        igual("0.00", r.totalDoMes(loja, 2026, 7, null));
        igual("0.00", r.ticketMedio(loja, 2026, 7, null));
        igual("0.00", r.maiorPedido(loja, 2026, 7, null));
        igual("0.00", r.menorPedido(loja, 2026, 7, null));
        assertTrue(r.rankingProdutos(loja, 2026, 7, null).isEmpty());
        assertTrue(r.rankingClientes(loja, 2026, 7, null).isEmpty());
    }

    @Test void rankingProdutosPorQuantidadeEDesempatePorValor() {
        List<String> nomes = r.rankingProdutos(loja, 2026, 9, null).stream()
                .map(VendaProduto::produtoNome).toList();
        assertEquals(List.of("Mouse", "Monitor", "Teclado"), nomes);
    }

    @Test void rankingClientesPorValor() {
        List<String> nomes = r.rankingClientes(loja, 2026, 9, null).stream()
                .map(RankingCliente::clienteNome).toList();
        assertEquals(List.of("João Souza", "Maria Silva"), nomes);
    }
}