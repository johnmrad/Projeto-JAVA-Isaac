package teste;

import modelo.ComissaoVendedor;
import modelo.MetodoPagamento;
import modelo.VendaCategoria;
import modelo.VendaFormaPagamento;
import org.junit.jupiter.api.Test;
import servico.IndicadorServico;
import servico.RelatorioServico;
import servico.Usuario;
import util.RegraNegocioException;
import java.math.BigDecimal;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Indicadores da Pessoa D, conferidos com os dados de exemplo (só leitura).
 * Vendas: set/2026 = pedidos 1 e 2; out/2026 = pedidos 3 e 4 (o 5 está cancelado e o 6 aguardando).
 */
public class IndicadoresTest {
    private final IndicadorServico ind = new IndicadorServico();
    private final RelatorioServico relatorio = new RelatorioServico();
    private final Usuario loja = Usuario.loja();

    private void igual(String esperado, BigDecimal real) {
        assertEquals(0, new BigDecimal(esperado).compareTo(real), "esperado " + esperado + " mas veio " + real);
    }

    // ---------------- comissão a pagar ----------------

    @Test void comissaoPorVendedorEmSetembro() {
        List<ComissaoVendedor> c = ind.comissaoAPagar(loja, 2026, 9, null);
        assertEquals(2, c.size());
        assertEquals("Loja B", c.get(0).vendedorNome());   // ordenado da maior para a menor comissão
        igual("72.00", c.get(0).comissao());
        assertEquals("Loja A", c.get(1).vendedorNome());
        igual("31.00", c.get(1).comissao());
    }

    @Test void comissaoIgnoraPedidoCanceladoEAguardando() {
        List<ComissaoVendedor> c = ind.comissaoAPagar(loja, 2026, 10, null);
        igual("72.00", c.get(0).comissao());   // Loja B: monitor do pedido 4
        igual("39.00", c.get(1).comissao());   // Loja A: 24 do pedido 3 + 15 do teclado do pedido 4 (sem os 7,76 do cancelado)
    }

    @Test void vendedorSemVendaNoMesApareceComZero() {
        List<ComissaoVendedor> c = ind.comissaoAPagar(loja, 2026, 8, null);   // só o pedido 7, da Loja A
        igual("38.00", c.get(0).comissao());
        igual("0.00", c.get(1).comissao());
        ind.comissaoAPagar(loja, 2026, 7, null).forEach(x -> igual("0.00", x.comissao()));
    }

    @Test void vendedorSoVeAPropriaComissao() {
        List<ComissaoVendedor> c = ind.comissaoAPagar(Usuario.vendedor(1L), 2026, 9, 2L);   // tenta olhar o vendedor 2
        assertEquals(1, c.size());
        assertEquals("Loja A", c.get(0).vendedorNome());
        igual("31.00", c.get(0).comissao());
    }

    @Test void lojaFiltraUmVendedor() {
        List<ComissaoVendedor> c = ind.comissaoAPagar(loja, 2026, 9, 2L);
        assertEquals(1, c.size());
        igual("72.00", c.get(0).comissao());
    }

    // ---------------- taxa de cancelamento ----------------

    @Test void taxaDeCancelamentoDeOutubro() {
        // pedidos finalizados criados em outubro: 3, 4, 5 e 6; cancelado: só o 5
        igual("25.00", ind.taxaCancelamento(loja, 2026, 10, null));
        igual("25.00", ind.taxaCancelamento(loja, 2026, 10, 1L));   // os 4 têm item da Loja A
        igual("0.00", ind.taxaCancelamento(loja, 2026, 10, 2L));    // só o pedido 4 tem item da Loja B
    }

    @Test void taxaDeCancelamentoSemCancelamentoOuSemPedidos() {
        igual("0.00", ind.taxaCancelamento(loja, 2026, 9, null));
        igual("0.00", ind.taxaCancelamento(loja, 2026, 7, null));   // mês sem pedidos: sem erro de divisão
    }

    // ---------------- vendas por categoria ----------------

    @Test void vendasPorCategoria() {
        List<VendaCategoria> set = ind.vendasPorCategoria(loja, 2026, 9, null);
        assertEquals(2, set.size());
        assertEquals("Informática", set.get(0).categoriaNome());
        igual("900.00", set.get(0).valor());
        assertEquals(1, set.get(0).quantidade());
        assertEquals("Periféricos", set.get(1).categoriaNome());
        igual("310.00", set.get(1).valor());
        assertEquals(3, set.get(1).quantidade());

        List<VendaCategoria> out = ind.vendasPorCategoria(loja, 2026, 10, null);
        igual("900.00", out.get(0).valor());
        igual("390.00", out.get(1).valor());
        assertEquals(4, out.get(1).quantidade());
    }

    @Test void vendasPorCategoriaDeUmVendedorEMesSemVendas() {
        List<VendaCategoria> a = ind.vendasPorCategoria(Usuario.vendedor(1L), 2026, 9, null);
        assertEquals(1, a.size());
        assertEquals("Periféricos", a.get(0).categoriaNome());
        assertTrue(ind.vendasPorCategoria(loja, 2026, 7, null).isEmpty());
    }

    @Test void vendasPorCategoriaSomamOTotalDoMes() {
        BigDecimal soma = ind.vendasPorCategoria(loja, 2026, 10, null).stream()
                .map(VendaCategoria::valor).reduce(BigDecimal.ZERO, BigDecimal::add);
        igual(relatorio.totalDoMes(loja, 2026, 10, null).toPlainString(), soma);
    }

    // ---------------- pedidos por forma de pagamento ----------------

    @Test void pedidosPorFormaDePagamento() {
        List<VendaFormaPagamento> set = ind.pedidosPorFormaPagamento(loja, 2026, 9, null);
        assertEquals(List.of(MetodoPagamento.PIX, MetodoPagamento.CARTAO, MetodoPagamento.BOLETO),
                set.stream().map(VendaFormaPagamento::metodo).toList());
        assertEquals(1, set.get(0).pedidos());
        igual("310.00", set.get(0).valor());
        assertEquals(1, set.get(1).pedidos());
        igual("900.00", set.get(1).valor());
        assertEquals(0, set.get(2).pedidos());
        igual("0.00", set.get(2).valor());

        List<VendaFormaPagamento> out = ind.pedidosPorFormaPagamento(loja, 2026, 10, null);
        assertEquals(0, out.get(0).pedidos());
        assertEquals(1, out.get(1).pedidos());
        igual("1050.00", out.get(1).valor());
        assertEquals(1, out.get(2).pedidos());
        igual("240.00", out.get(2).valor());
    }

    @Test void formasDePagamentoSomamOTotalDoMes() {
        BigDecimal soma = ind.pedidosPorFormaPagamento(loja, 2026, 10, null).stream()
                .map(VendaFormaPagamento::valor).reduce(BigDecimal.ZERO, BigDecimal::add);
        igual(relatorio.totalDoMes(loja, 2026, 10, null).toPlainString(), soma);
        BigDecimal somaVendedor = ind.pedidosPorFormaPagamento(loja, 2026, 10, 1L).stream()
                .map(VendaFormaPagamento::valor).reduce(BigDecimal.ZERO, BigDecimal::add);
        igual(relatorio.totalDoMes(loja, 2026, 10, 1L).toPlainString(), somaVendedor);
    }

    @Test void mesSemVendasDevolveTresFormasComZero() {
        List<VendaFormaPagamento> v = ind.pedidosPorFormaPagamento(loja, 2026, 7, null);
        assertEquals(3, v.size());
        v.forEach(x -> {
            assertEquals(0, x.pedidos());
            igual("0.00", x.valor());
        });
    }

    // ---------------- permissões e mês inválido ----------------

    @Test void clienteNaoVeIndicadores() {
        Usuario cliente = Usuario.cliente(1L);
        assertThrows(RegraNegocioException.class, () -> ind.comissaoAPagar(cliente, 2026, 9, null));
        assertThrows(RegraNegocioException.class, () -> ind.taxaCancelamento(cliente, 2026, 9, null));
        assertThrows(RegraNegocioException.class, () -> ind.vendasPorCategoria(cliente, 2026, 9, null));
        assertThrows(RegraNegocioException.class, () -> ind.pedidosPorFormaPagamento(cliente, 2026, 9, null));
        assertThrows(RegraNegocioException.class, () -> ind.comissaoAPagar(null, 2026, 9, null));
    }

    @Test void mesInvalido() {
        assertEquals("Mês inválido.", assertThrows(RegraNegocioException.class,
                () -> ind.comissaoAPagar(loja, 2026, 13, null)).getMessage());
        assertThrows(RegraNegocioException.class, () -> ind.taxaCancelamento(loja, 2026, 0, null));
        assertThrows(RegraNegocioException.class, () -> ind.pedidosPorFormaPagamento(loja, 2026, 13, null));
    }
}
