package teste;

import modelo.MetodoPagamento;
import modelo.Pedido;
import modelo.StatusPedido;
import org.junit.jupiter.api.Test;
import servico.ExpiracaoServico;
import servico.PagamentoServico;
import servico.Usuario;
import util.RegraNegocioException;
import util.Relogio;
import java.time.LocalDateTime;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

/** Expiração de pedidos (Pessoa D). Precisa do banco com os dados de exemplo carregados. */
public class ExpiracaoTest {
    private static final LocalDateTime T0 = CenarioD.INICIO;   // pedidos finalizados em 10/06/2026 às 10:00

    private final ExpiracaoServico expiracao = new ExpiracaoServico();
    private final PagamentoServico pagamentos = new PagamentoServico();

    private StatusPedido status(CenarioD c, Pedido p) {
        return c.pedido(p.getId()).getStatus();
    }

    @Test void pedidoSemPagamentoExpiraDepoisDe24Horas() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);

            Relogio.fixar(T0.plusHours(23).plusMinutes(59));          // na véspera: ainda vale
            assertFalse(expiracao.cancelarSeVencido(p.getId()));
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, status(c, p));

            Relogio.fixar(T0.plusHours(24));                          // no prazo exato: ainda vale
            assertFalse(expiracao.cancelarSeVencido(p.getId()));

            Relogio.fixar(T0.plusHours(24).plusMinutes(1));           // depois do prazo: cancela
            assertTrue(expiracao.cancelarSeVencido(p.getId()));
            assertEquals(StatusPedido.CANCELADO, status(c, p));
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());   // estoque voltou
            assertFalse(expiracao.cancelarSeVencido(p.getId()));         // já cancelado: nada a fazer
        }
    }

    @Test void pagarPedidoVencidoCancelaEAvisaOCliente() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            assertEquals(18, c.produto(c.mouse.getId()).getEstoque());

            Relogio.fixar(T0.plusHours(25));
            RegraNegocioException aviso = assertThrows(RegraNegocioException.class,
                    () -> expiracao.pagar(c.donoCliente, p.getId(), MetodoPagamento.PIX, 1));
            assertEquals(ExpiracaoServico.AVISO_CANCELADO, aviso.getMessage());

            // o cancelamento ficou gravado, mesmo com o erro
            assertEquals(StatusPedido.CANCELADO, status(c, p));
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
            assertEquals(0, c.cliente().getComprasPagas());
            assertNull(c.pedido(p.getId()).getPagamento());
        }
    }

    @Test void pagarPedidoDentroDoPrazoFuncionaNormalmente() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            Relogio.fixar(T0.plusHours(23));
            Pedido pago = expiracao.pagar(c.donoCliente, p.getId(), MetodoPagamento.PIX, 1);
            assertEquals(StatusPedido.PAGO, pago.getStatus());
        }
    }

    @Test void quemNaoEDonoNaoCancelaPedidoAlheioTentandoPagar() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            Relogio.fixar(T0.plusHours(30));
            recusa(() -> expiracao.pagar(c.donoVendedor, p.getId(), MetodoPagamento.PIX, 1));
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, status(c, p));
        }
    }

    private void recusa(Runnable acao) {
        assertThrows(RegraNegocioException.class, acao::run);
    }

    @Test void boletoVenceDepoisDoDiaDoVencimento() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            pagamentos.pagar(c.donoCliente, p.getId(), MetodoPagamento.BOLETO, 1);   // vence em 13/06
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, status(c, p));

            Relogio.fixar(LocalDateTime.of(2026, 6, 12, 23, 59));      // véspera: vale (e passou das 24h, mas boleto tem prazo próprio)
            assertFalse(expiracao.cancelarSeVencido(p.getId()));

            Relogio.fixar(LocalDateTime.of(2026, 6, 13, 23, 59));      // no dia: ainda vale
            assertFalse(expiracao.cancelarSeVencido(p.getId()));
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, status(c, p));

            Relogio.fixar(LocalDateTime.of(2026, 6, 14, 0, 0));        // depois: expira
            assertTrue(expiracao.cancelarSeVencido(p.getId()));
            assertEquals(StatusPedido.CANCELADO, status(c, p));
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
        }
    }

    @Test void boletoCompensaNoDiaDoVencimento() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            pagamentos.pagar(c.donoCliente, p.getId(), MetodoPagamento.BOLETO, 1);
            Relogio.fixar(LocalDateTime.of(2026, 6, 13, 18, 0));
            Pedido pago = expiracao.compensarBoleto(c.loja, p.getId());
            assertEquals(StatusPedido.PAGO, pago.getStatus());
            assertEquals(1, c.cliente().getComprasPagas());
        }
    }

    @Test void compensarBoletoVencidoCancelaEAvisa() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            pagamentos.pagar(c.donoCliente, p.getId(), MetodoPagamento.BOLETO, 1);
            Relogio.fixar(LocalDateTime.of(2026, 6, 14, 9, 0));
            RegraNegocioException aviso = assertThrows(RegraNegocioException.class,
                    () -> expiracao.compensarBoleto(c.loja, p.getId()));
            assertEquals(ExpiracaoServico.AVISO_CANCELADO, aviso.getMessage());
            assertEquals(StatusPedido.CANCELADO, status(c, p));
            assertEquals(0, c.cliente().getComprasPagas());
        }
    }

    @Test void soALojaCompensaBoleto() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            pagamentos.pagar(c.donoCliente, p.getId(), MetodoPagamento.BOLETO, 1);
            recusa(() -> expiracao.compensarBoleto(c.donoCliente, p.getId()));
            recusa(() -> expiracao.compensarBoleto(c.donoVendedor, p.getId()));
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, status(c, p));
        }
    }

    @Test void rotinaGeralCancelaTodosOsVencidosDeUmaVez() {
        try (CenarioD c = new CenarioD()) {
            // 1) finalizado e sem pagamento, vai vencer
            Pedido semPagamento = c.finalizarExemplo(c.donoCliente);
            // 2) boleto pendente, vai vencer
            var cliente2 = c.novoCliente("Dois", "dois" + System.nanoTime() + "@teste.com");
            Pedido boleto = c.finalizarExemplo(Usuario.cliente(cliente2.getId()));
            pagamentos.pagar(Usuario.cliente(cliente2.getId()), boleto.getId(), MetodoPagamento.BOLETO, 1);
            // 3) já pago: nunca vence
            var cliente3 = c.novoCliente("Tres", "tres" + System.nanoTime() + "@teste.com");
            Pedido pago = c.exemploPagoNoPix(Usuario.cliente(cliente3.getId()));
            // 4) finalizado mais tarde: ainda no prazo
            Relogio.fixar(T0.plusHours(20));
            var cliente4 = c.novoCliente("Quatro", "quatro" + System.nanoTime() + "@teste.com");
            Pedido recente = c.finalizarExemplo(Usuario.cliente(cliente4.getId()));

            Relogio.fixar(T0.plusHours(26));    // 1 e 2 passaram de 24h... mas o boleto (2) só vence em 13/06
            List<Long> primeira = expiracao.cancelarVencidos(c.loja);
            assertTrue(primeira.contains(semPagamento.getId()));
            assertFalse(primeira.contains(boleto.getId()));
            assertFalse(primeira.contains(pago.getId()));
            assertFalse(primeira.contains(recente.getId()));   // finalizado há 6h

            Relogio.fixar(LocalDateTime.of(2026, 6, 14, 0, 0));
            List<Long> segunda = expiracao.cancelarVencidos(c.loja);
            assertTrue(segunda.contains(boleto.getId()));
            assertTrue(segunda.contains(recente.getId()));
            assertFalse(segunda.contains(semPagamento.getId()));   // já tinha sido cancelado
            assertFalse(segunda.contains(pago.getId()));

            assertEquals(StatusPedido.CANCELADO, status(c, semPagamento));
            assertEquals(StatusPedido.CANCELADO, status(c, boleto));
            assertEquals(StatusPedido.CANCELADO, status(c, recente));
            assertEquals(StatusPedido.PAGO, status(c, pago));
            // 4 pedidos finalizados de 2 unidades de mouse; só o pago continua com o estoque baixado
            assertEquals(18, c.produto(c.mouse.getId()).getEstoque());
            assertTrue(expiracao.cancelarVencidos(c.loja).isEmpty());
        }
    }

    @Test void soALojaRodaARotina() {
        recusa(() -> expiracao.cancelarVencidos(Usuario.cliente(1L)));
        recusa(() -> expiracao.cancelarVencidos(Usuario.vendedor(1L)));
        recusa(() -> expiracao.cancelarVencidos(null));
    }
}
