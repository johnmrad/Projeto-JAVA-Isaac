package teste;

import modelo.Cliente;
import modelo.MetodoPagamento;
import modelo.Pagamento;
import modelo.Pedido;
import modelo.StatusPedido;
import org.junit.jupiter.api.Test;
import servico.ExpiracaoServico;
import java.time.LocalDate;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.*;

/** A regra de "vencido" sozinha, sem banco: dá para rodar em qualquer máquina. */
public class ExpiracaoRegraTest {
    private static final LocalDateTime FINALIZADO = LocalDateTime.of(2026, 10, 10, 10, 0);

    private Cliente cliente() {
        return new Cliente("Ana", "ana@x.com", "52998224725", "Belém", "PA", "Rua 1");
    }

    private Pedido aguardando() {
        Pedido p = new Pedido(cliente(), FINALIZADO.minusMinutes(5));
        p.setStatus(StatusPedido.AGUARDANDO_PAGAMENTO);
        p.setDataFinalizacao(FINALIZADO);
        return p;
    }

    private Pedido comBoleto(LocalDate vencimento) {
        Pedido p = aguardando();
        Pagamento pg = new Pagamento(MetodoPagamento.BOLETO);
        pg.setVencimento(vencimento);
        p.setPagamento(pg);
        return p;
    }

    @Test void semPagamentoVence24HorasDepoisDeFinalizado() {
        Pedido p = aguardando();
        assertFalse(ExpiracaoServico.vencido(p, FINALIZADO.plusHours(23).plusMinutes(59)));
        assertFalse(ExpiracaoServico.vencido(p, FINALIZADO.plusHours(24)));
        assertTrue(ExpiracaoServico.vencido(p, FINALIZADO.plusHours(24).plusSeconds(1)));
        assertTrue(ExpiracaoServico.vencido(p, FINALIZADO.plusDays(10)));
    }

    @Test void boletoVenceQuandoAMeiaNoiteDoVencimentoPassa() {
        Pedido p = comBoleto(LocalDate.of(2026, 10, 13));
        assertFalse(ExpiracaoServico.vencido(p, LocalDateTime.of(2026, 10, 12, 12, 0)));
        assertFalse(ExpiracaoServico.vencido(p, LocalDateTime.of(2026, 10, 13, 0, 0)));
        assertFalse(ExpiracaoServico.vencido(p, LocalDateTime.of(2026, 10, 13, 23, 59, 59)));   // no dia ainda vale
        assertTrue(ExpiracaoServico.vencido(p, LocalDateTime.of(2026, 10, 14, 0, 0)));
    }

    @Test void boletoPendenteNaoSeguePrazoDe24Horas() {
        Pedido p = comBoleto(LocalDate.of(2026, 10, 13));
        assertFalse(ExpiracaoServico.vencido(p, FINALIZADO.plusDays(2)));
    }

    @Test void soPedidoAguardandoPagamentoPodeVencer() {
        for (StatusPedido s : StatusPedido.values()) {
            if (s == StatusPedido.AGUARDANDO_PAGAMENTO) {
                continue;
            }
            Pedido p = aguardando();
            p.setStatus(s);
            assertFalse(ExpiracaoServico.vencido(p, FINALIZADO.plusDays(30)), "status " + s);
        }
    }

    @Test void semDataDeFinalizacaoNaoVence() {
        Pedido p = new Pedido(cliente(), FINALIZADO);
        p.setStatus(StatusPedido.AGUARDANDO_PAGAMENTO);
        assertFalse(ExpiracaoServico.vencido(p, FINALIZADO.plusDays(30)));
    }
}
