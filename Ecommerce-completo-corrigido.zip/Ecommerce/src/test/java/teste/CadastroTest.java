package teste;

import modelo.Produto;
import org.junit.jupiter.api.Test;
import servico.*;
import util.RegraNegocioException;
import java.math.BigDecimal;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class CadastroTest {
    private final ClienteServico clientes = new ClienteServico();
    private final VendedorServico vendedores = new VendedorServico();
    private final ProdutoServico produtos = new ProdutoServico();

    private String recusa(Runnable acao) {
        return assertThrows(RegraNegocioException.class, acao::run).getMessage();
    }

    @Test void clienteCpfInvalido() {
        assertEquals("CPF inválido.", recusa(() ->
            clientes.cadastrar("Ana", "ana2@x.com", "111.111.111-11", "Belém", "PA", "Rua 1")));
    }

    @Test void clienteUfInvalida() {
        assertEquals("UF inválida.", recusa(() ->
            clientes.cadastrar("Ana", "ana2@x.com", "390.533.447-05", "Belém", "XX", "Rua 1")));
    }

    @Test void clienteCpfDuplicado() {
        assertEquals("CPF já cadastrado.", recusa(() ->
            clientes.cadastrar("Novo", "novo@email.com", "529.982.247-25", "Belém", "PA", "Rua 1")));
    }

    @Test void clienteEmailDuplicado() {
        assertEquals("E-mail já cadastrado.", recusa(() ->
            clientes.cadastrar("Novo", "maria@email.com", "935.411.347-80", "Belém", "PA", "Rua 1")));
    }

    @Test void clienteComPedidoEmAndamentoNaoDesativa() {
        assertEquals("Cliente com pedido em andamento não pode ser desativado.", recusa(() ->
            clientes.desativar(Usuario.cliente(3L), 3L)));
    }

    @Test void clienteNaoMexeEmOutroCliente() {
        recusa(() -> clientes.desativar(Usuario.cliente(2L), 1L));
    }

    @Test void clienteDesativadoNaoEntra() {
        assertEquals("Cliente desativado não entra no sistema.", recusa(() -> clientes.entrar("pedro@email.com")));
    }

    @Test void vendedorComissaoAcimaDe30() {
        assertEquals("Comissão deve ficar entre 0 e 30%.", recusa(() ->
            vendedores.cadastrar(Usuario.loja(), "Loja C", "c@loja.com", new BigDecimal("31"))));
    }

    @Test void clienteNaoCadastraVendedor() {
        recusa(() -> vendedores.cadastrar(Usuario.cliente(1L), "Loja C", "c@loja.com", new BigDecimal("10")));
    }

    @Test void produtoPrecoZero() {
        assertEquals("Preço deve ser maior que zero.", recusa(() ->
            produtos.cadastrar(Usuario.vendedor(1L), "Fone", "desc", BigDecimal.ZERO, 5, 1L, null)));
    }

    @Test void produtoEstoqueNegativo() {
        assertEquals("Estoque não pode ser negativo.", recusa(() ->
            produtos.cadastrar(Usuario.vendedor(1L), "Fone", "desc", BigDecimal.TEN, -1, 1L, null)));
    }

    @Test void vendedorNaoMexeEmProdutoDeOutro() {
        recusa(() -> produtos.reporEstoque(Usuario.vendedor(1L), 3L, 5));
    }

    @Test void produtoVendidoNaoPodeSerExcluido() {
        assertEquals("Produto já vendido: só pode ser desativado.", recusa(() ->
            produtos.excluir(Usuario.loja(), 1L)));
    }

    @Test void catalogoSoTemAtivosComEstoque() {
        List<Produto> lista = produtos.catalogo();
        assertEquals(3, lista.size());
        assertTrue(lista.stream().noneMatch(p -> p.getId().equals(4L) || p.getId().equals(5L)));
    }

    @Test void estoqueBaixoPorPapel() {
        assertEquals(2, produtos.estoqueBaixo(Usuario.loja()).size());
        List<Produto> a = produtos.estoqueBaixo(Usuario.vendedor(1L));
        assertEquals(1, a.size());
        assertEquals(2L, a.get(0).getId());
        assertEquals(1, produtos.estoqueBaixo(Usuario.vendedor(2L)).size());
    }
}