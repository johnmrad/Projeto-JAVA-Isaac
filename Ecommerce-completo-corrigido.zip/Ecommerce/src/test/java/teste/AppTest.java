package teste;

import menu.Console;
import menu.MenuPrincipal;
import modelo.Pedido;
import modelo.StatusPedido;
import org.junit.jupiter.api.Test;
import servico.CancelamentoServico;
import servico.EnvioServico;
import util.Jpa;
import util.Relogio;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

/**
 * O App de ponta a ponta: o teste "digita" nos menus (uma linha por Enter) e confere o que apareceu na
 * tela e o que ficou no banco. Precisa do banco com os dados de exemplo carregados.
 */
public class AppTest {

    /** Digita as linhas no menu inicial e devolve tudo o que foi mostrado. */
    private String digitar(String... linhas) {
        ByteArrayOutputStream saida = new ByteArrayOutputStream();
        Charset cs = Charset.defaultCharset();
        Console console = new Console(new ByteArrayInputStream(String.join("\n", linhas).concat("\n").getBytes(cs)),
                new PrintStream(saida, true, cs));
        try {
            new MenuPrincipal(console).executar();
        } catch (Console.FimDaEntrada e) {
            // o roteiro acabou; tudo bem
        }
        return saida.toString(cs);
    }

    private Pedido ultimoPedido(Long clienteId) {
        return Jpa.consultar(em -> em.createQuery(
                "select p from Pedido p where p.cliente.id = :id order by p.id desc", Pedido.class)
                .setParameter("id", clienteId).setMaxResults(1).getResultList().get(0));
    }

    private void igual(String esperado, BigDecimal real) {
        assertEquals(0, new BigDecimal(esperado).compareTo(real), "esperado " + esperado + " mas veio " + real);
    }

    @Test void clienteCompraEPagaNoPixPeloMenu() {
        try (CenarioD c = new CenarioD()) {
            String tela = digitar(
                    "1", c.cliente.getEmail(),
                    "2", c.mouse.getId().toString(), "2",
                    "2", c.teclado.getId().toString(), "1",
                    "6", "s",
                    "7", "1", "s",
                    "0", "0");
            assertTrue(tela.contains("finalizado"), tela);
            assertTrue(tela.contains("Pagamento aprovado"), tela);
            assertTrue(tela.contains("R$ 294,50"), tela);
            Pedido p = ultimoPedido(c.cliente.getId());
            assertEquals(StatusPedido.PAGO, p.getStatus());
            igual("294.50", p.getValorCobrado());
            assertEquals(29, c.cliente().getPontos());
        }
    }

    @Test void clienteVeCatalogoMeusDadosEMeusPedidos() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            String tela = digitar("1", c.cliente.getEmail(), "1", "11", "8", String.valueOf(p.getId()), "0", "0");
            assertTrue(tela.contains(c.mouse.getNome()), tela);               // catálogo
            assertTrue(tela.contains("Nível: BRONZE"), tela);                  // meus dados
            assertTrue(tela.contains("Pontos: 29"), tela);
            assertTrue(tela.contains("#" + p.getId()) && tela.contains("PIX - APROVADO"), tela);   // detalhes do pedido
        }
    }

    @Test void vendedorSeparaEnviaEEntregaPeloMenu() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            String id = String.valueOf(p.getId());
            String tela = digitar("2", c.vendedor.getEmail(),
                    "2", "2", id, "3", id, "4", id, "0", "0", "0");
            assertTrue(tela.contains("separado"), tela);
            assertTrue(tela.contains("Código de rastreio: " + EnvioServico.gerarCodigoRastreio(p.getId())), tela);
            assertTrue(tela.contains("entregue"), tela);
            assertEquals(StatusPedido.ENTREGUE, c.pedido(p.getId()).getStatus());
        }
    }

    @Test void clienteNaoCancelaPedidoJaEnviado() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            new EnvioServico().separar(c.donoVendedor, p.getId());
            new EnvioServico().enviar(c.donoVendedor, p.getId());
            String tela = digitar("1", c.cliente.getEmail(), "9", String.valueOf(p.getId()), "s", "0", "0");
            assertTrue(tela.contains("Pedido já enviado não pode ser cancelado."), tela);
            assertEquals(StatusPedido.ENVIADO, c.pedido(p.getId()).getStatus());
        }
    }

    @Test void clienteCancelaPedidoPagoPeloMenuETudoVoltaAoNormal() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            String tela = digitar("1", c.cliente.getEmail(), "9", String.valueOf(p.getId()), "s", "0", "0");
            assertTrue(tela.contains("cancelado"), tela);
            assertEquals(StatusPedido.CANCELADO, c.pedido(p.getId()).getStatus());
            assertEquals(0, c.cliente().getPontos());
            igual("0.00", c.cliente().getTotalGasto());
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
        }
    }

    @Test void pagarPedidoVencidoPeloMenuCancelaEAvisa() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            Relogio.fixar(CenarioD.INICIO.plusHours(30));
            String tela = digitar("1", c.cliente.getEmail(), "7", "1", "s", "0", "0");
            assertTrue(tela.contains("Pedido vencido"), tela);
            assertEquals(StatusPedido.CANCELADO, c.pedido(p.getId()).getStatus());
            assertEquals(20, c.produto(c.mouse.getId()).getEstoque());
        }
    }

    @Test void vendedorVeORelatorioDoMesComComissao() {
        try (CenarioD c = new CenarioD()) {
            c.exemploPagoNoPix(c.donoCliente);
            // Enter no ano e no mês usa a data do sistema (junho de 2026 nos testes)
            String tela = digitar("2", c.vendedor.getEmail(), "3", "1", "", "", "0", "0", "0");
            assertTrue(tela.contains("RELATÓRIO DE 06/2026"), tela);
            assertTrue(tela.contains("Total vendido ......... R$ 310,00"), tela);
            assertTrue(tela.contains(c.vendedor.getNome() + ": R$ 31,00"), tela);   // comissão do exemplo da §14
        }
    }

    @Test void vendedorExportaCsvENotaFiscalPeloMenu() throws Exception {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            String tela = digitar("2", c.vendedor.getEmail(), "3", "2", "", "", "3", String.valueOf(p.getId()), "s", "0", "0", "0");
            assertTrue(tela.contains("CSV salvo em"), tela);
            assertTrue(tela.contains("DOCUMENTO SIMULADO - SEM VALIDADE FISCAL"), tela);
            java.nio.file.Files.deleteIfExists(java.nio.file.Path.of("exportacoes", "nota-fiscal-" + p.getId() + ".xml"));
            java.nio.file.Files.deleteIfExists(java.nio.file.Path.of("exportacoes", "vendas-2026-06-vendedor-" + c.vendedor.getId() + ".csv"));
        }
    }

    @Test void lojaCadastraCupomPeloMenuEClienteUsa() {
        String codigo = "MENU" + Long.toString(System.nanoTime(), 36).toUpperCase();
        try (CenarioD c = new CenarioD()) {
            String tela = digitar("3", "4", "3", codigo, "15", "50", "31/12/2026", "3", "n", "4", "0", "0", "0");
            assertTrue(tela.contains("Cupom " + codigo + " cadastrado"), tela);
            assertTrue(tela.contains(codigo) && tela.contains("15,00%"), tela);   // aparece na listagem

            // o cliente aplica o cupom pelo menu: 15% de R$ 310,00 = R$ 46,50
            String compra = digitar("1", c.cliente.getEmail(),
                    "2", c.mouse.getId().toString(), "2", "2", c.teclado.getId().toString(), "1",
                    "4", codigo, "0", "0");
            assertTrue(compra.contains("Cupom aplicado"), compra);
            assertTrue(compra.contains("-R$ 46,50 (cupom " + codigo + ")"), compra);

            // cupom repetido é recusado
            String repetido = digitar("3", "4", "3", codigo, "10", "10", "31/12/2026", "1", "n", "0", "0", "0");
            assertTrue(repetido.contains("Cupom já cadastrado."), repetido);
        } finally {
            Jpa.executar(em -> {
                em.createNativeQuery("delete from pedido where cupom_id in (select id from cupom where codigo = ?1)")
                        .setParameter(1, codigo).executeUpdate();
                em.createNativeQuery("delete from cupom where codigo = ?1").setParameter(1, codigo).executeUpdate();
            });
        }
    }

    @Test void lojaRodaARotinaDeExpiracaoPeloMenu() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            Relogio.fixar(CenarioD.INICIO.plusHours(30));
            String tela = digitar("3", "4", "8", "0", "0", "0");
            assertTrue(tela.contains("cancelado(s)"), tela);
            assertEquals(StatusPedido.CANCELADO, c.pedido(p.getId()).getStatus());
        }
    }

    @Test void clienteNaoEntraNaAreaDoVendedorEOContrario() {
        try (CenarioD c = new CenarioD()) {
            assertTrue(digitar("2", c.cliente.getEmail(), "0").contains("Vendedor não encontrado."));
            assertTrue(digitar("1", c.vendedor.getEmail(), "0").contains("Cliente não encontrado."));
        }
    }

    @Test void entradaInvalidaNaoDerrubaOMenu() {
        String tela = digitar("abc", "99", "1", "naoexiste@teste.com", "0");
        assertTrue(tela.contains("Digite um número inteiro."), tela);
        assertTrue(tela.contains("Opção inválida."), tela);
        assertTrue(tela.contains("Cliente não encontrado."), tela);
        assertTrue(tela.contains("Até logo!"), tela);
    }

    @Test void cadastroDeClientePeloMenuEEntrada() {
        String email = "menu" + System.nanoTime() + "@teste.com";
        String cpf = CenarioD.cpfValido();
        try {
            String tela = digitar("4", "Novo Cliente", email, cpf, "Belém", "PA", "Rua do Teste, 1",
                    "1", email, "11", "0", "0");
            assertTrue(tela.contains("Cadastro feito!"), tela);
            assertTrue(tela.contains("Novo Cliente"), tela);
            assertTrue(tela.contains("Pontos: 0"), tela);
        } finally {
            Jpa.executar(em -> {
                em.createNativeQuery("delete from pedido where cliente_id in (select id from cliente where email = ?1)")
                        .setParameter(1, email).executeUpdate();
                em.createNativeQuery("delete from cliente where email = ?1").setParameter(1, email).executeUpdate();
            });
        }
    }

    @Test void cadastroComCpfInvalidoMostraOMotivo() {
        String tela = digitar("4", "Fulano", "fulano" + System.nanoTime() + "@teste.com", "111.111.111-11", "Belém", "PA", "Rua 1", "0");
        assertTrue(tela.contains("CPF inválido."), tela);
    }

    @Test void clienteComPedidoEmAndamentoNaoDesativaAConta() {
        try (CenarioD c = new CenarioD()) {
            c.finalizarExemplo(c.donoCliente);
            String tela = digitar("1", c.cliente.getEmail(), "12", "s", "0", "0");
            assertTrue(tela.contains("Cliente com pedido em andamento não pode ser desativado."), tela);
            assertTrue(c.cliente().isAtivo());
        }
    }

    @Test void semPedidoAguardandoPagamentoOMenuAvisa() {
        try (CenarioD c = new CenarioD()) {
            String tela = digitar("1", c.cliente.getEmail(), "7", "0", "0");
            assertTrue(tela.contains("Você não tem pedido aguardando pagamento"), tela);
        }
    }

    @Test void pagamentoNoCartaoMostraParcelasEJuros() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);   // total R$ 310,00
            String tela = digitar("1", c.cliente.getEmail(), "7", "2", "6", "s", "0", "0");
            assertTrue(tela.contains("6x de"), tela);
            Pedido pago = c.pedido(p.getId());
            assertEquals(StatusPedido.PAGO, pago.getStatus());
            assertEquals(6, pago.getPagamento().getParcelas());
            assertTrue(pago.getValorCobrado().compareTo(new BigDecimal("310")) > 0);   // 6x tem juros
        }
    }

    @Test void boletoGeradoPeloClienteECompensadoPelaLoja() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.finalizarExemplo(c.donoCliente);
            String compra = digitar("1", c.cliente.getEmail(), "7", "3", "s", "0", "0");
            assertTrue(compra.contains("Boleto gerado"), compra);
            assertEquals(StatusPedido.AGUARDANDO_PAGAMENTO, c.pedido(p.getId()).getStatus());
            String loja = digitar("3", "4", "7", String.valueOf(p.getId()), "0", "0", "0");
            assertTrue(loja.contains("Boleto compensado"), loja);
            assertEquals(StatusPedido.PAGO, c.pedido(p.getId()).getStatus());
        }
    }

    @Test void lojaCancelaQualquerPedidoPeloMenu() {
        try (CenarioD c = new CenarioD()) {
            Pedido p = c.exemploPagoNoPix(c.donoCliente);
            String tela = digitar("3", "2", "5", String.valueOf(p.getId()), "s", "0", "0", "0");
            assertTrue(tela.contains("cancelado"), tela);
            assertEquals(StatusPedido.CANCELADO, c.pedido(p.getId()).getStatus());
        }
    }

    @Test void vendedorNaoTemOpcaoDeAdministracao() {
        try (CenarioD c = new CenarioD()) {
            String tela = digitar("2", c.vendedor.getEmail(), "4", "0", "0");
            assertFalse(tela.contains("4 - Administração da loja"), tela);
            assertTrue(tela.contains("Opção inválida."), tela);
        }
    }

    @Test void vendedorCadastraEAlteraProdutoPeloMenu() {
        try (CenarioD c = new CenarioD()) {
            String nome = "Cabo " + System.nanoTime();
            String cat = c.categoria.getId().toString();
            String tela = digitar("2", c.vendedor.getEmail(), "1",
                    "2", nome, "Cabo USB", "19,90", "7", cat,   // cadastrar
                    "1",                                          // listar
                    "7",                                          // estoque baixo (7 não é baixo)
                    "0", "0", "0");
            assertTrue(tela.contains("Produto #") && tela.contains("cadastrado"), tela);
            assertTrue(tela.contains(nome) && tela.contains("R$ 19,90"), tela);
            // o produto do menu pertence ao vendedor do cenário e some junto com ele no close()
            List<?> achados = Jpa.consultar(em -> em.createQuery("select p from Produto p where p.nome = :n")
                    .setParameter("n", nome).getResultList());
            assertEquals(1, achados.size());
        }
    }
}
