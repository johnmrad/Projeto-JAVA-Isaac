package teste;

import modelo.Categoria;
import modelo.StatusPedido;
import org.junit.jupiter.api.Test;
import util.Relogio;
import java.time.LocalDate;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.*;

public class ModeloTest {
    @Test
    void contaComoVenda() {
        assertTrue(StatusPedido.PAGO.contaComoVenda());
        assertTrue(StatusPedido.SEPARADO.contaComoVenda());
        assertTrue(StatusPedido.ENVIADO.contaComoVenda());
        assertTrue(StatusPedido.ENTREGUE.contaComoVenda());
        assertFalse(StatusPedido.CARRINHO.contaComoVenda());
        assertFalse(StatusPedido.AGUARDANDO_PAGAMENTO.contaComoVenda());
        assertFalse(StatusPedido.CANCELADO.contaComoVenda());
    }

    @Test
    void equalsPorId() {
        Categoria a = new Categoria("A");
        Categoria b = new Categoria("B");
        assertNotEquals(a, b);
        a.setId(1L);
        b.setId(1L);
        assertEquals(a, b);
        b.setId(2L);
        assertNotEquals(a, b);
    }

    @Test
    void relogioFixo() {
        Relogio.fixar(LocalDateTime.of(2026, 10, 14, 10, 0));
        assertEquals(LocalDate.of(2026, 10, 14), Relogio.hoje());
        Relogio.liberar();
    }
}