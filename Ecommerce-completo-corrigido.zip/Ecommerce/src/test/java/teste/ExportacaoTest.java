package teste;

import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import servico.ExportacaoServico;
import servico.RelatorioServico;
import servico.Usuario;
import util.RegraNegocioException;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

/** CSV e XML com os dados de exemplo (só leitura). */
public class ExportacaoTest {
    private final ExportacaoServico exportacao = new ExportacaoServico();
    private final RelatorioServico relatorio = new RelatorioServico();
    private final Usuario loja = Usuario.loja();

    private void igual(String esperado, BigDecimal real) {
        assertEquals(0, new BigDecimal(esperado).compareTo(real), "esperado " + esperado + " mas veio " + real);
    }

    private List<String[]> linhas(byte[] csv) {
        String texto = new String(csv, 3, csv.length - 3, StandardCharsets.UTF_8);
        List<String[]> r = new ArrayList<>();
        for (String linha : texto.split("\r\n")) {
            r.add(linha.split(";", -1));
        }
        return r;
    }

    /** Soma da coluna "Valor líquido" (índice 9), lendo a vírgula como decimal. */
    private BigDecimal somaValorLiquido(List<String[]> linhas) {
        return linhas.stream().skip(1).map(c -> new BigDecimal(c[9].replace(',', '.')))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private BigDecimal somaComissao(List<String[]> linhas) {
        return linhas.stream().skip(1).map(c -> new BigDecimal(c[10].replace(',', '.')))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    // ---------------- CSV ----------------

    @Test void csvDoMesBateComORelatorioDaLoja() {
        for (int mes : new int[]{8, 9, 10}) {
            List<String[]> l = linhas(exportacao.csvVendasDoMes(loja, 2026, mes, null));
            igual(relatorio.totalDoMes(loja, 2026, mes, null).toPlainString(), somaValorLiquido(l));
        }
    }

    @Test void csvDoMesBateComORelatorioDoVendedor() {
        for (long vendedor : new long[]{1, 2}) {
            for (int mes : new int[]{8, 9, 10}) {
                List<String[]> l = linhas(exportacao.csvVendasDoMes(Usuario.vendedor(vendedor), 2026, mes, null));
                igual(relatorio.totalDoMes(Usuario.vendedor(vendedor), 2026, mes, null).toPlainString(), somaValorLiquido(l));
            }
        }
    }

    @Test void csvUmaLinhaPorItemVendido() {
        List<String[]> set = linhas(exportacao.csvVendasDoMes(loja, 2026, 9, null));
        assertEquals(1 + 3, set.size());   // cabeçalho + (mouse e teclado do pedido 1) + (monitor do pedido 2)
        set.forEach(c -> assertEquals(13, c.length));
        List<String[]> out = linhas(exportacao.csvVendasDoMes(loja, 2026, 10, null));
        assertEquals(1 + 3, out.size());   // pedido 3 (1 item) + pedido 4 (2 itens); o 5 cancelado e o 6 aguardando ficam de fora
        assertEquals(1, linhas(exportacao.csvVendasDoMes(loja, 2026, 7, null)).size());   // mês sem vendas: só o cabeçalho
    }

    @Test void csvTrazPrimeiraLinhaDoExemploDaSecao14() {
        List<String[]> l = linhas(exportacao.csvVendasDoMes(Usuario.vendedor(1L), 2026, 9, null));
        assertEquals(3, l.size());
        igual("310.00", somaValorLiquido(l));
        igual("31.00", somaComissao(l));   // comissão do exemplo: R$ 31,00
        assertEquals("1", l.get(1)[0]);
        assertEquals("10/09/2026 09:10:00", l.get(1)[1]);
        assertEquals("Maria Silva", l.get(1)[2]);
        assertEquals("Mouse", l.get(1)[4]);
        assertEquals("PIX", l.get(1)[11]);
        assertEquals("ENTREGUE", l.get(1)[12]);
    }

    @Test void vendedorSoRecebeOsPropriosItens() {
        List<String[]> l = linhas(exportacao.csvVendasDoMes(Usuario.vendedor(1L), 2026, 9, 2L));   // tenta pedir o do vendedor 2
        l.stream().skip(1).forEach(c -> assertEquals("Loja A", c[3]));
    }

    @Test void lojaFiltraUmVendedor() {
        List<String[]> l = linhas(exportacao.csvVendasDoMes(loja, 2026, 9, 2L));
        assertEquals(2, l.size());
        assertEquals("Monitor", l.get(1)[4]);
    }

    @Test void clienteNaoExportaVendas() {
        assertThrows(RegraNegocioException.class, () -> exportacao.csvVendasDoMes(Usuario.cliente(1L), 2026, 9, null));
        assertThrows(RegraNegocioException.class, () -> exportacao.csvVendasDoMes(null, 2026, 9, null));
        assertThrows(RegraNegocioException.class, () -> exportacao.csvVendasDoMes(loja, 2026, 13, null));
    }

    @Test void salvaOArquivoCsvComBom() throws Exception {
        Path pasta = Files.createTempDirectory("vendas-csv");
        Path arquivo = exportacao.salvarCsvVendasDoMes(Usuario.vendedor(1L), 2026, 9, null, pasta);
        assertEquals("vendas-2026-09-vendedor-1.csv", arquivo.getFileName().toString());
        byte[] bytes = Files.readAllBytes(arquivo);
        assertEquals((byte) 0xEF, bytes[0]);
        assertEquals(3, linhas(bytes).size());
        Files.delete(arquivo);
        Files.delete(pasta);
    }

    // ---------------- XML da nota ----------------

    private Document ler(String xml) throws Exception {
        return DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
    }

    @Test void notaDoPedidoPagoDoExemplo() throws Exception {
        Document doc = ler(exportacao.xmlNotaFiscal(loja, 1L));
        assertEquals("DOCUMENTO SIMULADO - SEM VALIDADE FISCAL", doc.getElementsByTagName("aviso").item(0).getTextContent());
        assertEquals(2, doc.getElementsByTagName("item").getLength());
        assertEquals("310.00", doc.getElementsByTagName("valorProdutos").item(0).getTextContent());
        assertEquals("294.50", doc.getElementsByTagName("valorCobrado").item(0).getTextContent());
        assertEquals("PIX", doc.getElementsByTagName("forma").item(0).getTextContent());
    }

    @Test void notaSoParaPagamentoConfirmado() {
        String aviso = "A nota fiscal só é emitida para pedido com pagamento confirmado.";
        assertEquals(aviso, assertThrows(RegraNegocioException.class, () -> exportacao.xmlNotaFiscal(loja, 5L)).getMessage());   // cancelado e estornado
        assertEquals(aviso, assertThrows(RegraNegocioException.class, () -> exportacao.xmlNotaFiscal(loja, 6L)).getMessage());   // aguardando
        assertEquals("Pedido não encontrado.", assertThrows(RegraNegocioException.class, () -> exportacao.xmlNotaFiscal(loja, -1L)).getMessage());
    }

    @Test void notaSoParaQuemPodeVerOPedido() throws Exception {
        assertNotNull(exportacao.xmlNotaFiscal(Usuario.cliente(1L), 1L));            // a própria cliente
        assertNotNull(exportacao.xmlNotaFiscal(Usuario.vendedor(1L), 1L));           // vendedor com item no pedido
        assertThrows(RegraNegocioException.class, () -> exportacao.xmlNotaFiscal(Usuario.cliente(2L), 1L));
        assertThrows(RegraNegocioException.class, () -> exportacao.xmlNotaFiscal(Usuario.vendedor(2L), 1L));
        assertThrows(RegraNegocioException.class, () -> exportacao.xmlNotaFiscal(null, 1L));
    }

    @Test void salvaOArquivoXml() throws Exception {
        Path pasta = Files.createTempDirectory("nota-xml");
        Path arquivo = exportacao.salvarXmlNotaFiscal(loja, 1L, pasta);
        assertEquals("nota-fiscal-1.xml", arquivo.getFileName().toString());
        ler(Files.readString(arquivo));   // é um XML válido
        Files.delete(arquivo);
        Files.delete(pasta);
    }
}
