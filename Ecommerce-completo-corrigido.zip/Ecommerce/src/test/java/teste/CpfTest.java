package teste;

import org.junit.jupiter.api.Test;
import util.ValidadorCpf;
import static org.junit.jupiter.api.Assertions.*;

public class CpfTest {
    @Test void validoComMascara() { assertTrue(ValidadorCpf.valido("529.982.247-25")); }
    @Test void validoSemMascara() { assertTrue(ValidadorCpf.valido("52998224725")); }
    @Test void digitoErrado() { assertFalse(ValidadorCpf.valido("529.982.247-24")); }
    @Test void todosIguais() { assertFalse(ValidadorCpf.valido("111.111.111-11")); }
    @Test void curto() { assertFalse(ValidadorCpf.valido("123")); }
    @Test void nulo() { assertFalse(ValidadorCpf.valido(null)); }
    @Test void limparGuardaSoNumeros() { assertEquals("52998224725", ValidadorCpf.limpar("529.982.247-25")); }
}