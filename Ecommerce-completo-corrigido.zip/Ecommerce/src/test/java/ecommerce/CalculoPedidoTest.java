package ecommerce;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Testes do motor de calculo. Cada metodo com @Test e um teste.
 * assertEquals(esperado, obtido, 0.001) confere se o valor esta certo (0.001 = tolerancia do double).
 */
public class CalculoPedidoTest {

    private LocalDate hoje = LocalDate.of(2026, 10, 14);

    /** Pedido do exemplo da secao 14: base R$ 310,00 e vendedor com 10%. */
    private CalculoPedido exemplo14() {
        CalculoPedido calculo = new CalculoPedido("PA");
        calculo.adicionarItem(new ItemPedidoCalculo("Fone", 100.00, 2, 10));
        calculo.adicionarItem(new ItemPedidoCalculo("Carregador", 110.00, 1, 10));
        calculo.setHoje(hoje);
        return calculo;
    }

    // ===================== exemplos da secao 14 =====================

    @Test
    public void exemplo14Pix() {
        CalculoPedido calculo = exemplo14();
        calculo.setPagamento(PagamentoCalculo.PIX, 1);
        calculo.calcular();

        assertEquals(310.00, calculo.getBase(), 0.001);
        assertEquals(0.00, calculo.getFrete(), 0.001);
        assertEquals(294.50, calculo.getValorCobrado(), 0.001);
        assertEquals(29, calculo.getPontosGanhos());
        assertEquals(31.00, calculo.getComissaoTotal(), 0.001);
    }

    @Test
    public void exemplo14ComCupomDe10PorCento() {
        CalculoPedido calculo = exemplo14();
        calculo.setCupom(new CupomCalculo("DEZ", 10, 0, hoje, 5, false), 0);
        calculo.calcular();

        assertEquals(31.00, calculo.getDescontoComercial(), 0.001);
        assertEquals("CUPOM", calculo.getOrigemDesconto());
        assertEquals(27.90, calculo.getComissaoTotal(), 0.001);
    }

    @Test
    public void exemplo14Cartao300Em6x() {
        assertEquals(337.65, PagamentoCalculo.valorNoCartao(300.00, 6), 0.001);
        assertEquals(56.28, PagamentoCalculo.valorParcela(337.65, 6), 0.001);
    }

    // ===================== desconto por volume =====================

    @Test
    public void descontoPorVolume() {
        assertEquals(0, new ItemPedidoCalculo("A", 10, 4, 0).getPercentualVolume(), 0.001);
        assertEquals(5, new ItemPedidoCalculo("A", 10, 5, 0).getPercentualVolume(), 0.001);
        assertEquals(5, new ItemPedidoCalculo("A", 10, 9, 0).getPercentualVolume(), 0.001);
        assertEquals(10, new ItemPedidoCalculo("A", 10, 10, 0).getPercentualVolume(), 0.001);
    }

    @Test
    public void descontoPorVolumeEPorItem() {
        CalculoPedido calculo = new CalculoPedido("SP");
        calculo.adicionarItem(new ItemPedidoCalculo("Caneta", 10.00, 5, 10));   // 50,00 - 5% = 47,50
        calculo.adicionarItem(new ItemPedidoCalculo("Caderno", 25.00, 4, 10));  // 100,00 sem desconto
        calculo.calcular();

        assertEquals(150.00, calculo.getSubtotalBruto(), 0.001);
        assertEquals(2.50, calculo.getDescontoVolume(), 0.001);
        assertEquals(147.50, calculo.getBase(), 0.001);
    }

    // ===================== desconto comercial =====================

    @Test
    public void fidelidadeECupomNaoSomamValeOMaior() {
        // Prata (3%) contra cupom de 10% -> vale o cupom
        CalculoPedido calculo = exemplo14();
        calculo.setNivelFidelidade(Fidelidade.PRATA);
        calculo.setCupom(new CupomCalculo("DEZ", 10, 0, hoje, 5, false), 3);
        calculo.calcular();
        assertEquals(31.00, calculo.getDescontoComercial(), 0.001);
        assertEquals("CUPOM", calculo.getOrigemDesconto());

        // Ouro (5%) contra cupom de 5% -> vale a fidelidade
        calculo.setNivelFidelidade(Fidelidade.OURO);
        calculo.setCupom(new CupomCalculo("CINCO", 5, 0, hoje, 5, false), 3);
        calculo.calcular();
        assertEquals(15.50, calculo.getDescontoComercial(), 0.001);
        assertEquals("FIDELIDADE", calculo.getOrigemDesconto());
    }

    @Test
    public void cupomSaiSozinhoAbaixoDoMinimo() {
        CalculoPedido calculo = exemplo14();
        calculo.setCupom(new CupomCalculo("GRANDE", 10, 500, hoje, 5, false), 0);
        calculo.calcular();

        assertTrue(calculo.isCupomRemovido());
        assertEquals(0.00, calculo.getDescontoComercial(), 0.001);
    }

    // ===================== pontos =====================

    @Test
    public void pontosLimitadosA30PorCento() {
        // base 310 -> 30% = R$ 93,00 -> no maximo 930 pontos
        CalculoPedido calculo = exemplo14();
        calculo.setPontos(5000, 5000);
        calculo.calcular();
        assertEquals(930, calculo.getPontosResgatados());
        assertEquals(93.00, calculo.getValorPontosResgatados(), 0.001);
    }

    @Test
    public void pontosLimitadosAoSaldo() {
        CalculoPedido calculo = exemplo14();
        calculo.setPontos(5000, 200);
        calculo.calcular();
        assertEquals(200, calculo.getPontosResgatados());
    }

    @Test
    public void pontosEntramDepoisDoDescontoComercial() {
        // 310 - 31 (cupom) = 279 -> 30% = 83,70 -> 837 pontos
        CalculoPedido calculo = exemplo14();
        calculo.setCupom(new CupomCalculo("DEZ", 10, 0, hoje, 5, false), 0);
        calculo.setPontos(10000, 10000);
        calculo.calcular();
        assertEquals(837, calculo.getPontosResgatados());
        assertEquals(195.30, calculo.getValorProdutos(), 0.001);
    }

    // ===================== frete =====================

    @Test
    public void freteGratisAPartirDe250() {
        CalculoPedido calculo = new CalculoPedido("PA");
        calculo.adicionarItem(new ItemPedidoCalculo("A", 250.00, 1, 0));
        calculo.calcular();
        assertEquals(0.00, calculo.getFrete(), 0.001);

        CalculoPedido outro = new CalculoPedido("PA");
        outro.adicionarItem(new ItemPedidoCalculo("A", 249.99, 1, 0));
        outro.calcular();
        assertEquals(12.00, outro.getFrete(), 0.001);
        assertEquals(261.99, outro.getTotal(), 0.001);
    }

    @Test
    public void ufInvalida() {
        CalculoPedido calculo = new CalculoPedido("XX");
        calculo.adicionarItem(new ItemPedidoCalculo("A", 10.00, 1, 0));
        assertThrows(IllegalArgumentException.class, () -> calculo.calcular());
    }

    // ===================== pagamento =====================

    @Test
    public void pixNaoDaDescontoNoFrete() {
        // 100,00 de produtos + 12,00 de frete: o PIX tira 5% so dos 100,00
        CalculoPedido calculo = new CalculoPedido("PA");
        calculo.adicionarItem(new ItemPedidoCalculo("A", 100.00, 1, 0));
        calculo.setPagamento(PagamentoCalculo.PIX, 1);
        calculo.calcular();
        assertEquals(112.00, calculo.getTotal(), 0.001);
        assertEquals(107.00, calculo.getValorCobrado(), 0.001);
    }

    @Test
    public void maximoDeParcelas() {
        assertEquals(1, PagamentoCalculo.maximoParcelas(19.99));
        assertEquals(1, PagamentoCalculo.maximoParcelas(39.99));
        assertEquals(2, PagamentoCalculo.maximoParcelas(40.00));
        assertEquals(5, PagamentoCalculo.maximoParcelas(100.00));
        assertEquals(12, PagamentoCalculo.maximoParcelas(300.00));
    }

    @Test
    public void ate3xSemJuros() {
        assertEquals(300.00, PagamentoCalculo.valorNoCartao(300.00, 1), 0.001);
        assertEquals(300.00, PagamentoCalculo.valorNoCartao(300.00, 3), 0.001);
        assertTrue(PagamentoCalculo.valorNoCartao(300.00, 4) > 300.00);
    }

    @Test
    public void parcelasAcimaDoPermitido() {
        assertThrows(IllegalArgumentException.class, () -> PagamentoCalculo.valorNoCartao(100.00, 6));
        assertThrows(IllegalArgumentException.class, () -> PagamentoCalculo.valorNoCartao(100.00, 0));
    }

    @Test
    public void boletoVenceEm3Dias() {
        CalculoPedido calculo = exemplo14();
        calculo.setPagamento(PagamentoCalculo.BOLETO, 1);
        calculo.calcular();
        assertEquals(calculo.getTotal(), calculo.getValorCobrado(), 0.001);
        assertEquals(LocalDate.of(2026, 10, 17), calculo.getVencimentoBoleto());
    }

    // ===================== comissao =====================

    @Test
    public void comissaoArredondadaPorItem() {
        // base 100, cupom 7% -> valor dos produtos 93 -> fator 0,93
        CalculoPedido calculo = new CalculoPedido("SP");
        calculo.adicionarItem(new ItemPedidoCalculo("A", 33.33, 1, 15)); // 33,33 x 0,93 x 15% = 4,6495 -> 4,65
        calculo.adicionarItem(new ItemPedidoCalculo("B", 66.67, 1, 8));  // 66,67 x 0,93 x 8%  = 4,9602 -> 4,96
        calculo.setCupom(new CupomCalculo("SETE", 7, 0, hoje, 5, false), 0);
        calculo.setHoje(hoje);
        calculo.calcular();
        assertEquals(4.65, calculo.getItens().get(0).getComissao(), 0.001);
        assertEquals(4.96, calculo.getItens().get(1).getComissao(), 0.001);
    }

    @Test
    public void somaDosValoresLiquidosBateComValorDosProdutos() {
        CalculoPedido calculo = new CalculoPedido("SP");
        calculo.adicionarItem(new ItemPedidoCalculo("A", 10.01, 3, 10));
        calculo.adicionarItem(new ItemPedidoCalculo("B", 7.77, 7, 10));
        calculo.adicionarItem(new ItemPedidoCalculo("C", 1.99, 11, 10));
        calculo.setCupom(new CupomCalculo("SETE", 7, 0, hoje, 5, false), 0);
        calculo.setPontos(33, 33);
        calculo.setHoje(hoje);
        calculo.calcular();

        double soma = 0;
        for (ItemPedidoCalculo item : calculo.getItens()) {
            soma = soma + item.getValorLiquido();
        }
        assertEquals(calculo.getValorProdutos(), soma, 0.001);
    }

    @Test
    public void carrinhoVazioDaZero() {
        CalculoPedido calculo = new CalculoPedido("PA");
        calculo.calcular();
        assertEquals(0.00, calculo.getTotal(), 0.001);
    }

    @Test
    public void arredondamentoMeioCentavoParaCima() {
        assertEquals(56.28, Dinheiro.arredondar(56.275), 0.0001);
        assertEquals(56.27, Dinheiro.arredondar(56.2749), 0.0001);
        assertEquals(0.01, Dinheiro.arredondar(0.005), 0.0001);
    }
}
