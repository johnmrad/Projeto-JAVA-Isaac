package ecommerce;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Testes de cupom e fidelidade.
 * assertThrows(Erro.class, () -> codigo) confere que aquele codigo da erro.
 * O "() ->" so quer dizer "este e o codigo que deve ser executado".
 */
public class CupomEFidelidadeTest {

    private LocalDate hoje = LocalDate.of(2026, 10, 14);

    // ===================== cadastro de cupom =====================

    @Test
    public void codigoDoCupomDeveSerUnico() {
        CadastroCupons cadastro = new CadastroCupons();
        cadastro.cadastrar(new CupomCalculo("PROMO10", 10, 100, hoje, 2, false));
        assertThrows(IllegalArgumentException.class,
                () -> cadastro.cadastrar(new CupomCalculo("promo10", 5, 0, hoje, 1, false)));
        assertNotNull(cadastro.buscar("promo10"));
        assertNull(cadastro.buscar("NAOEXISTE"));
    }

    @Test
    public void percentualMaiorQueZeroEAte50() {
        assertThrows(IllegalArgumentException.class, () -> new CupomCalculo("ZERO", 0, 0, hoje, 1, false));
        assertThrows(IllegalArgumentException.class, () -> new CupomCalculo("MUITO", 50.01, 0, hoje, 1, false));
        assertEquals(50, new CupomCalculo("METADE", 50, 0, hoje, 1, false).getPercentualDesconto(), 0.001);
    }

    // ===================== validacao de cupom =====================

    @Test
    public void cupomValido() {
        CupomCalculo cupom = new CupomCalculo("PROMO10", 10, 100, hoje, 2, false);
        assertTrue(cupom.podeSerUsado(310, 3, hoje));
    }

    @Test
    public void cupomInativo() {
        CupomCalculo cupom = new CupomCalculo("PROMO10", 10, 100, hoje, 2, false);
        cupom.desativar();
        assertFalse(cupom.podeSerUsado(310, 0, hoje));
    }

    @Test
    public void ultimoDiaDaValidadeAindaVale() {
        CupomCalculo cupom = new CupomCalculo("PROMO10", 10, 100, hoje, 2, false); // vale ate hoje
        assertTrue(cupom.podeSerUsado(310, 0, hoje));
        assertFalse(cupom.podeSerUsado(310, 0, hoje.plusDays(1)));
    }

    @Test
    public void usosEsgotadosEDevolucao() {
        CupomCalculo cupom = new CupomCalculo("PROMO10", 10, 100, hoje, 2, false);
        cupom.consumirUso();
        cupom.consumirUso();
        assertFalse(cupom.podeSerUsado(310, 0, hoje));
        cupom.devolverUso();   // cancelamento devolve o uso
        assertTrue(cupom.podeSerUsado(310, 0, hoje));
    }

    @Test
    public void baseAbaixoDoMinimo() {
        CupomCalculo cupom = new CupomCalculo("PROMO10", 10, 100, hoje, 2, false);
        assertFalse(cupom.podeSerUsado(99.99, 0, hoje));
        assertTrue(cupom.podeSerUsado(100.00, 0, hoje));
    }

    @Test
    public void somentePrimeiraCompra() {
        CupomCalculo cupom = new CupomCalculo("BEMVINDO", 10, 0, hoje, 10, true);
        assertTrue(cupom.podeSerUsado(310, 0, hoje));
        assertFalse(cupom.podeSerUsado(310, 1, hoje));
    }

    // ===================== fidelidade =====================

    @Test
    public void nivelPeloTotalGasto() {
        assertEquals(Fidelidade.BRONZE, Fidelidade.calcularNivel(0));
        assertEquals(Fidelidade.BRONZE, Fidelidade.calcularNivel(499.99));
        assertEquals(Fidelidade.PRATA, Fidelidade.calcularNivel(500));
        assertEquals(Fidelidade.PRATA, Fidelidade.calcularNivel(1499.99));
        assertEquals(Fidelidade.OURO, Fidelidade.calcularNivel(1500));
    }

    @Test
    public void pontosGanhos() {
        assertEquals(29, Fidelidade.calcularPontosGanhos(294.50));
        assertEquals(1, Fidelidade.calcularPontosGanhos(10.00));
        assertEquals(0, Fidelidade.calcularPontosGanhos(9.99));
    }

    @Test
    public void saldoDePontosNuncaFicaNegativo() {
        assertEquals(10, Fidelidade.retirarPontos(39, 29));
        assertEquals(0, Fidelidade.retirarPontos(20, 29));
    }
}
