import menu.Console;
import menu.MenuPrincipal;
import util.Jpa;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Programa principal do e-commerce (menu no terminal).
 *
 * Antes de rodar: PostgreSQL ligado e um banco chamado "ecommerce". Se o seu usuário, senha ou endereço
 * forem outros, use as variáveis DB_USUARIO, DB_SENHA e DB_URL (veja util/Jpa.java).
 * As tabelas são criadas sozinhas; para ter dados de exemplo use a opção 5 do menu inicial.
 */
public class App {
    public static void main(String[] args) {
        Console console = new Console(System.in, System.out);

        // 1) Testa a conexão direto no PostgreSQL. Se falhar aqui, o motivo é o verdadeiro
        //    (o Hibernate 6 engole o erro de conexão e só reclama de "Dialect").
        String problema = problemaDeConexao();
        if (problema != null) {
            console.linha("Não consegui conectar ao banco de dados PostgreSQL.");
            console.linha("Tentei: " + Jpa.URL + " com o usuário \"" + Jpa.USUARIO + "\" e "
                    + (Jpa.SENHA.isEmpty() ? "SEM senha (DB_SENHA não definida)" : "a senha de DB_SENHA") + ".");
            console.linha("Motivo: " + problema);
            console.linha("Usuário, senha e endereço podem ser trocados com DB_USUARIO, DB_SENHA e DB_URL.");
            System.exit(1);
        }

        // 2) Conectou: liga o Hibernate, que cria as tabelas se ainda não existirem.
        try {
            Jpa.consultar(em -> 1);
        } catch (Throwable e) {
            console.linha("Conectei ao PostgreSQL, mas o Hibernate não conseguiu iniciar (criar/atualizar as tabelas).");
            console.linha("Motivo: " + motivo(e));
            System.exit(1);
        }

        try {
            new MenuPrincipal(console).executar();
        } catch (Console.FimDaEntrada e) {
            console.linha();
            console.linha("Entrada encerrada. Até logo!");
        }
        System.exit(0);   // fecha também as conexões com o banco
    }

    /** Abre e fecha uma conexão com o PostgreSQL. Devolve o motivo da falha, ou null se deu certo. */
    private static String problemaDeConexao() {
        try {
            Class.forName("org.postgresql.Driver");   // garante o driver registrado (no exec:java também)
        } catch (ClassNotFoundException e) {
            return "o driver do PostgreSQL não está no classpath. Rode pelo Maven "
                    + "(mvn compile exec:java -Dexec.mainClass=App) ou pelo Run do VS Code com o pom.xml carregado.";
        }
        try (Connection conexao = DriverManager.getConnection(Jpa.URL, Jpa.USUARIO, Jpa.SENHA)) {
            return null;
        } catch (SQLException e) {
            return explicar(e);
        }
    }

    /** Traduz os erros de conexão mais comuns do PostgreSQL (pelo SQLState) e mantém a mensagem original. */
    private static String explicar(SQLException e) {
        String dica = switch (e.getSQLState() == null ? "" : e.getSQLState()) {
            case "28P01" -> "senha errada para o usuário \"" + Jpa.USUARIO + "\". Defina DB_SENHA com a senha do seu PostgreSQL.";
            case "08004" -> "o PostgreSQL recusou a conexão (geralmente pediu senha e nenhuma foi informada). Defina DB_SENHA.";
            case "28000" -> "o PostgreSQL recusou o usuário \"" + Jpa.USUARIO + "\". Confira DB_USUARIO.";
            case "3D000" -> "o banco não existe. Crie com: CREATE DATABASE ecommerce;";
            case "08001" -> "não achei o PostgreSQL nesse endereço. Ele está ligado? A porta é a 5432?";
            default -> null;
        };
        return dica == null ? e.getMessage() : dica + "\n        (" + e.getMessage() + ")";
    }

    /** Primeiro erro de banco (SQLException) da cadeia; se não houver, a causa mais funda. */
    private static String motivo(Throwable e) {
        Throwable causa = e;
        for (Throwable t = e; t != null; t = t.getCause()) {
            if (t instanceof SQLException sql) {
                return explicar(sql);
            }
            causa = t;
        }
        return causa.getMessage() != null ? causa.getMessage() : causa.toString();
    }
}
