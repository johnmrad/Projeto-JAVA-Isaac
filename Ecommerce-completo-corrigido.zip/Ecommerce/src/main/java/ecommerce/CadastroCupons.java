package ecommerce;

import java.util.ArrayList;

/**
 * Guarda todos os cupons numa ArrayList e nao deixa cadastrar dois com o mesmo codigo.
 */
public class CadastroCupons {

    private ArrayList<CupomCalculo> cupons = new ArrayList<>();

    /** Cadastra o cupom. O codigo precisa ser unico. */
    public void cadastrar(CupomCalculo novo) {
        if (buscar(novo.getCodigo()) != null) {
            throw new IllegalArgumentException("Ja existe um cupom com o codigo " + novo.getCodigo() + ".");
        }
        cupons.add(novo);
    }

    /** Procura pelo codigo (sem diferenciar maiusculas e minusculas). Devolve null se nao achar. */
    public CupomCalculo buscar(String codigo) {
        for (CupomCalculo c : cupons) {
            if (c.getCodigo().equalsIgnoreCase(codigo.trim())) {
                return c;
            }
        }
        return null;
    }

    public ArrayList<CupomCalculo> listar() {
        return cupons;
    }
}
