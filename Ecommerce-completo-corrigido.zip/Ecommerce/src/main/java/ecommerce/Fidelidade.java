package ecommerce;

/**
 * Regras do programa de fidelidade.
 * Os metodos sao "static": nao precisa criar um objeto, e so chamar Fidelidade.calcularNivel(...).
 */
public class Fidelidade {

    public static final String BRONZE = "BRONZE";
    public static final String PRATA = "PRATA";
    public static final String OURO = "OURO";

    /** Nivel pelo total ja gasto: Bronze; Prata a partir de R$ 500; Ouro a partir de R$ 1.500. */
    public static String calcularNivel(double totalGasto) {
        if (totalGasto >= Configuracao.NIVEL_OURO_A_PARTIR_DE) {
            return OURO;
        } else if (totalGasto >= Configuracao.NIVEL_PRATA_A_PARTIR_DE) {
            return PRATA;
        }
        return BRONZE;
    }

    /** Percentual de desconto que cada nivel ganha sobre a base do pedido. */
    public static double percentualDesconto(String nivel) {
        if (OURO.equals(nivel)) {
            return Configuracao.DESCONTO_OURO;
        } else if (PRATA.equals(nivel)) {
            return Configuracao.DESCONTO_PRATA;
        }
        return Configuracao.DESCONTO_BRONZE;
    }

    /** Pontos ganhos numa compra: parte inteira de (valor cobrado / 10). */
    public static int calcularPontosGanhos(double valorCobrado) {
        if (valorCobrado <= 0) {
            return 0;
        }
        // (int) corta as casas decimais: 29.45 vira 29
        return (int) (valorCobrado / Configuracao.REAIS_POR_PONTO_GANHO + 0.0000001);
    }

    /** Pessoa D usa no cancelamento: tira os pontos ganhos, mas o saldo nunca fica abaixo de 0. */
    public static int retirarPontos(int saldoAtual, int pontosParaRetirar) {
        int novoSaldo = saldoAtual - pontosParaRetirar;
        if (novoSaldo < 0) {
            return 0;
        }
        return novoSaldo;
    }
}
