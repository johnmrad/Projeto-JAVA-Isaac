package ecommerce;

/**
 * Um item do pedido: qual produto, por quanto, quantas unidades e a comissao do vendedor.
 * O proprio item sabe calcular o seu subtotal, o desconto por volume e a sua comissao.
 */
public class ItemPedidoCalculo {

    private String nomeProduto;
    private double precoUnitario;
    private int quantidade;
    private double comissaoVendedor;   // em %, de 0 a 30

    // preenchidos pelo CalculoPedido
    private double valorLiquido;       // quanto este item representa no "valor dos produtos"
    private double comissao;           // comissao do vendedor neste item, em R$

    public ItemPedidoCalculo(String nomeProduto, double precoUnitario, int quantidade, double comissaoVendedor) {
        if (precoUnitario <= 0) {
            throw new IllegalArgumentException("O preco de " + nomeProduto + " deve ser maior que zero.");
        }
        if (quantidade <= 0) {
            throw new IllegalArgumentException("A quantidade de " + nomeProduto + " deve ser maior que zero.");
        }
        if (comissaoVendedor < 0) {
            throw new IllegalArgumentException("A comissao do vendedor nao pode ser negativa.");
        }
        this.nomeProduto = nomeProduto;
        this.precoUnitario = precoUnitario;
        this.quantidade = quantidade;
        this.comissaoVendedor = comissaoVendedor;
    }

    /** Preco x quantidade. */
    public double getSubtotalBruto() {
        return Dinheiro.arredondar(precoUnitario * quantidade);
    }

    /** 10% a partir de 10 unidades, 5% a partir de 5, senao 0%. */
    public double getPercentualVolume() {
        if (quantidade >= Configuracao.VOLUME_QTD_FAIXA2) {
            return Configuracao.VOLUME_DESCONTO_FAIXA2;
        } else if (quantidade >= Configuracao.VOLUME_QTD_FAIXA1) {
            return Configuracao.VOLUME_DESCONTO_FAIXA1;
        }
        return 0;
    }

    public double getDescontoVolume() {
        return Dinheiro.porcentagem(getSubtotalBruto(), getPercentualVolume());
    }

    /** Subtotal do item depois do desconto por volume (e o que entra na "base"). */
    public double getSubtotal() {
        return Dinheiro.arredondar(getSubtotalBruto() - getDescontoVolume());
    }

    /**
     * Comissao do item (§9): subtotal x (valor dos produtos / base) x % do vendedor.
     * O "fator" e (valor dos produtos / base): a parte do item que sobrou depois dos descontos.
     * Frete, juros e desconto do PIX nao entram.
     */
    public void calcularComissao(double fator) {
        this.comissao = Dinheiro.arredondar(getSubtotal() * fator * comissaoVendedor / 100);
    }

    // ---------------- getters e setters ----------------

    public String getNomeProduto() {
        return nomeProduto;
    }

    public double getPrecoUnitario() {
        return precoUnitario;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double getComissaoVendedor() {
        return comissaoVendedor;
    }

    public double getValorLiquido() {
        return valorLiquido;
    }

    public void setValorLiquido(double valorLiquido) {
        this.valorLiquido = valorLiquido;
    }

    public double getComissao() {
        return comissao;
    }
}
