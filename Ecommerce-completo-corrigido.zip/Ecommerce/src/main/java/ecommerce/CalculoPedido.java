package ecommerce;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 * MOTOR DE CALCULO DO PEDIDO (Pessoa B).
 *
 * Como usar (Pessoa C):
 *   CalculoPedido calculo = new CalculoPedido("PA");
 *   calculo.adicionarItem(new ItemPedidoCalculo("Fone", 100.00, 2, 10));
 *   calculo.setNivelFidelidade(Fidelidade.calcularNivel(cliente.getTotalGasto()));
 *   calculo.setCupom(cupom, cliente.getComprasPagas());
 *   calculo.setPontos(pontosQueQuerUsar, cliente.getSaldoPontos());
 *   calculo.setPagamento(PagamentoCalculo.PIX, 1);
 *   calculo.calcular();
 *   double cobrado = calculo.getValorCobrado();
 *
 * Ordem do calculo (§4):
 *   1. subtotal bruto
 *   2. desconto por volume (por item)
 *   3. base = bruto - desconto por volume
 *   4. desconto comercial = o MAIOR entre fidelidade e cupom (nao soma os dois)
 *   5. pontos resgatados (R$ 0,10 cada, no maximo 30% de (base - desconto comercial), limitado ao saldo)
 *   6. valor dos produtos = base - desconto comercial - pontos
 *   7. frete (gratis a partir de R$ 250, senao tabela por UF)
 *   8. total = valor dos produtos + frete
 *   depois: pagamento, pontos ganhos e comissao de cada item.
 */
public class CalculoPedido {

    // ================= DADOS DE ENTRADA =================
    private ArrayList<ItemPedidoCalculo> itens = new ArrayList<>();
    private String uf;
    private String nivelFidelidade = Fidelidade.BRONZE;
    private CupomCalculo cupom;                     // pode ser null (sem cupom)
    private int comprasPagasCliente;
    private int pontosSolicitados;
    private int saldoPontos;
    private String formaPagamento;           // PIX, CARTAO, BOLETO ou null (ainda nao escolheu)
    private int parcelas = 1;
    private LocalDate hoje = LocalDate.now();

    // ================= RESULTADOS =================
    private double subtotalBruto;
    private double descontoVolume;
    private double base;
    private double descontoComercial;
    private String origemDesconto = "NENHUM";   // NENHUM, FIDELIDADE ou CUPOM
    private boolean cupomRemovido;
    private String motivoCupomRemovido = "";
    private int pontosResgatados;
    private double valorPontosResgatados;
    private double valorProdutos;
    private double frete;
    private double total;
    private double ajustePagamento;             // negativo no PIX, positivo com juros
    private double valorCobrado;
    private int maximoParcelas = 1;
    private double valorParcela;
    private LocalDate vencimentoBoleto;
    private int pontosGanhos;

    public CalculoPedido(String uf) {
        this.uf = uf;
    }

    // ================= CALCULO PRINCIPAL =================

    /** Faz todas as contas. A Pessoa C chama de novo a cada mudanca no carrinho. */
    public void calcular() {
        zerarResultados();
        if (itens.isEmpty()) {
            return;   // carrinho vazio: tudo fica zero
        }
        calcularBase();
        calcularDescontoComercial();
        calcularPontosResgatados();
        calcularFreteETotal();
        calcularPagamento();
        calcularComissoesEValoresLiquidos();
    }

    /** Passos 1 a 3: subtotal bruto, desconto por volume e base. */
    private void calcularBase() {
        for (ItemPedidoCalculo item : itens) {
            subtotalBruto = subtotalBruto + item.getSubtotalBruto();
            descontoVolume = descontoVolume + item.getDescontoVolume();
        }
        subtotalBruto = Dinheiro.arredondar(subtotalBruto);
        descontoVolume = Dinheiro.arredondar(descontoVolume);
        base = Dinheiro.arredondar(subtotalBruto - descontoVolume);
    }

    /** Passo 4: desconto comercial = o maior entre fidelidade e cupom. */
    private void calcularDescontoComercial() {
        double descontoFidelidade = Dinheiro.porcentagem(base, Fidelidade.percentualDesconto(nivelFidelidade));

        double descontoCupom = 0;
        if (cupom != null) {
            try {
                cupom.validar(base, comprasPagasCliente, hoje);
                descontoCupom = Dinheiro.porcentagem(base, cupom.getPercentualDesconto());
            } catch (IllegalArgumentException e) {
                // ex.: o carrinho ficou abaixo do valor minimo -> o cupom sai sozinho
                cupomRemovido = true;
                motivoCupomRemovido = e.getMessage();
            }
        }

        // nao soma: fica so o maior. Se empatar, fica a fidelidade (para nao gastar o cupom a toa)
        if (descontoCupom > descontoFidelidade) {
            descontoComercial = descontoCupom;
            origemDesconto = "CUPOM";
        } else if (descontoFidelidade > 0) {
            descontoComercial = descontoFidelidade;
            origemDesconto = "FIDELIDADE";
        }
    }

    /** Passo 5: pontos resgatados. */
    private void calcularPontosResgatados() {
        double limiteEmReais = (base - descontoComercial) * Configuracao.RESGATE_MAXIMO / 100;
        int limiteEmPontos = (int) (limiteEmReais / Configuracao.VALOR_DO_PONTO + 0.0000001);

        // o menor entre: o que o cliente pediu, o saldo dele e o limite de 30%
        pontosResgatados = Math.min(pontosSolicitados, saldoPontos);
        pontosResgatados = Math.min(pontosResgatados, limiteEmPontos);
        if (pontosResgatados < 0) {
            pontosResgatados = 0;
        }
        valorPontosResgatados = Dinheiro.arredondar(pontosResgatados * Configuracao.VALOR_DO_PONTO);
    }

    /** Passos 6 a 8: valor dos produtos, frete e total. */
    private void calcularFreteETotal() {
        valorProdutos = Dinheiro.arredondar(base - descontoComercial - valorPontosResgatados);

        double freteDaTabela = Configuracao.fretePorUf(uf);   // tambem confere se a UF existe
        if (valorProdutos >= Configuracao.FRETE_GRATIS_A_PARTIR_DE) {
            frete = 0;
        } else {
            frete = freteDaTabela;
        }
        total = Dinheiro.arredondar(valorProdutos + frete);
        maximoParcelas = PagamentoCalculo.maximoParcelas(total);
    }

    /** Pagamento: ajuste, valor cobrado, parcelas, vencimento do boleto e pontos ganhos. */
    private void calcularPagamento() {
        if (formaPagamento == null) {
            valorCobrado = total;   // forma ainda nao escolhida (carrinho)
            valorParcela = total;
            return;
        }

        if (formaPagamento.equals(PagamentoCalculo.PIX)) {
            valorCobrado = Dinheiro.arredondar(total - PagamentoCalculo.descontoPix(valorProdutos));
            parcelas = 1;
        } else if (formaPagamento.equals(PagamentoCalculo.CARTAO)) {
            valorCobrado = PagamentoCalculo.valorNoCartao(total, parcelas);
        } else if (formaPagamento.equals(PagamentoCalculo.BOLETO)) {
            valorCobrado = total;
            parcelas = 1;
            vencimentoBoleto = PagamentoCalculo.vencimentoBoleto(hoje);
        } else {
            throw new IllegalArgumentException("Forma de pagamento invalida: " + formaPagamento);
        }

        ajustePagamento = Dinheiro.arredondar(valorCobrado - total);
        valorParcela = PagamentoCalculo.valorParcela(valorCobrado, parcelas);
        pontosGanhos = Fidelidade.calcularPontosGanhos(valorCobrado);
    }

    /**
     * Comissao de cada item (§9) e quanto cada item representa no valor dos produtos.
     * O ultimo item fica com a diferenca de centavos, para a soma bater certinho
     * com o valor dos produtos (assim o CSV da Pessoa D bate com o relatorio).
     */
    private void calcularComissoesEValoresLiquidos() {
        double fator = valorProdutos / base;   // quanto sobrou da base depois dos descontos
        double somaLiquidos = 0;

        for (int i = 0; i < itens.size(); i++) {
            ItemPedidoCalculo item = itens.get(i);
            item.calcularComissao(fator);

            if (i == itens.size() - 1) {
                item.setValorLiquido(Dinheiro.arredondar(valorProdutos - somaLiquidos));
            } else {
                double liquido = Dinheiro.arredondar(item.getSubtotal() * fator);
                item.setValorLiquido(liquido);
                somaLiquidos = somaLiquidos + liquido;
            }
        }
    }

    private void zerarResultados() {
        subtotalBruto = 0;
        descontoVolume = 0;
        base = 0;
        descontoComercial = 0;
        origemDesconto = "NENHUM";
        cupomRemovido = false;
        motivoCupomRemovido = "";
        pontosResgatados = 0;
        valorPontosResgatados = 0;
        valorProdutos = 0;
        frete = 0;
        total = 0;
        ajustePagamento = 0;
        valorCobrado = 0;
        maximoParcelas = 1;
        valorParcela = 0;
        vencimentoBoleto = null;
        pontosGanhos = 0;
    }

    /** Soma das comissoes de todos os itens. */
    public double getComissaoTotal() {
        double soma = 0;
        for (ItemPedidoCalculo item : itens) {
            soma = soma + item.getComissao();
        }
        return Dinheiro.arredondar(soma);
    }

    /** Texto com todas as contas, para mostrar no menu. */
    public String gerarResumo() {
        String texto = "";
        for (ItemPedidoCalculo item : itens) {
            texto += "  " + item.getQuantidade() + "x " + item.getNomeProduto()
                    + " de " + Dinheiro.formatar(item.getPrecoUnitario())
                    + " = " + Dinheiro.formatar(item.getSubtotalBruto());
            if (item.getDescontoVolume() > 0) {
                texto += " (desconto por volume: -" + Dinheiro.formatar(item.getDescontoVolume()) + ")";
            }
            texto += "\n";
        }
        texto += "  Subtotal bruto ........... " + Dinheiro.formatar(subtotalBruto) + "\n";
        texto += "  Desconto por volume ...... -" + Dinheiro.formatar(descontoVolume) + "\n";
        texto += "  Base ..................... " + Dinheiro.formatar(base) + "\n";
        texto += "  Desconto comercial ....... -" + Dinheiro.formatar(descontoComercial) + " (" + origemDesconto + ")\n";
        if (cupomRemovido) {
            texto += "  * Cupom removido: " + motivoCupomRemovido + "\n";
        }
        texto += "  Pontos resgatados ........ -" + Dinheiro.formatar(valorPontosResgatados) + " (" + pontosResgatados + " pontos)\n";
        texto += "  Valor dos produtos ....... " + Dinheiro.formatar(valorProdutos) + "\n";
        texto += "  Frete .................... " + Dinheiro.formatar(frete) + "\n";
        texto += "  TOTAL .................... " + Dinheiro.formatar(total) + "\n";
        if (formaPagamento != null) {
            texto += "  Ajuste " + formaPagamento + " ............ " + Dinheiro.formatar(ajustePagamento) + "\n";
            texto += "  VALOR COBRADO ............ " + Dinheiro.formatar(valorCobrado) + "\n";
            if (formaPagamento.equals(PagamentoCalculo.CARTAO)) {
                texto += "  Parcelas ................. " + parcelas + "x de " + Dinheiro.formatar(valorParcela)
                        + " (maximo " + maximoParcelas + "x)\n";
            }
            if (vencimentoBoleto != null) {
                texto += "  Vencimento do boleto ..... " + vencimentoBoleto + "\n";
            }
            texto += "  Pontos que vai ganhar .... " + pontosGanhos + "\n";
        }
        texto += "  Comissao dos vendedores .. " + Dinheiro.formatar(getComissaoTotal()) + "\n";
        return texto;
    }

    // ================= SETTERS (entrada) =================

    public void adicionarItem(ItemPedidoCalculo item) {
        itens.add(item);
    }

    public void removerItem(int posicao) {
        itens.remove(posicao);
    }

    public void limparItens() {
        itens.clear();
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public void setNivelFidelidade(String nivelFidelidade) {
        this.nivelFidelidade = nivelFidelidade;
    }

    public void setCupom(CupomCalculo cupom, int comprasPagasCliente) {
        this.cupom = cupom;
        this.comprasPagasCliente = comprasPagasCliente;
    }

    public void setPontos(int pontosSolicitados, int saldoPontos) {
        this.pontosSolicitados = pontosSolicitados;
        this.saldoPontos = saldoPontos;
    }

    public void setPagamento(String formaPagamento, int parcelas) {
        this.formaPagamento = formaPagamento;
        this.parcelas = parcelas;
    }

    public void setHoje(LocalDate hoje) {
        this.hoje = hoje;
    }

    // ================= GETTERS (resultados) =================

    public ArrayList<ItemPedidoCalculo> getItens() {
        return itens;
    }

    public CupomCalculo getCupom() {
        return cupom;
    }

    public double getSubtotalBruto() {
        return subtotalBruto;
    }

    public double getDescontoVolume() {
        return descontoVolume;
    }

    public double getBase() {
        return base;
    }

    public double getDescontoComercial() {
        return descontoComercial;
    }

    public String getOrigemDesconto() {
        return origemDesconto;
    }

    public boolean isCupomRemovido() {
        return cupomRemovido;
    }

    public String getMotivoCupomRemovido() {
        return motivoCupomRemovido;
    }

    public int getPontosResgatados() {
        return pontosResgatados;
    }

    public double getValorPontosResgatados() {
        return valorPontosResgatados;
    }

    public double getValorProdutos() {
        return valorProdutos;
    }

    public double getFrete() {
        return frete;
    }

    public double getTotal() {
        return total;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public double getAjustePagamento() {
        return ajustePagamento;
    }

    public double getValorCobrado() {
        return valorCobrado;
    }

    public int getParcelas() {
        return parcelas;
    }

    public int getMaximoParcelas() {
        return maximoParcelas;
    }

    public double getValorParcela() {
        return valorParcela;
    }

    public LocalDate getVencimentoBoleto() {
        return vencimentoBoleto;
    }

    public int getPontosGanhos() {
        return pontosGanhos;
    }
}
