package ecommerce;

import java.time.LocalDate;

/**
 * Cupom de desconto em porcentagem.
 * Os usos so mudam pelos metodos consumirUso() e devolverUso() (encapsulamento).
 */
public class CupomCalculo {

    private String codigo;
    private double percentualDesconto;     // maior que 0 e ate 50
    private double valorMinimo;            // base minima do pedido
    private LocalDate validade;             // ultimo dia em que o cupom vale
    private int usosMaximos;
    private int usosFeitos;
    private boolean somentePrimeiraCompra;
    private boolean ativo;

    public CupomCalculo(String codigo, double percentualDesconto, double valorMinimo,
                 LocalDate validade, int usosMaximos, boolean somentePrimeiraCompra) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("Informe o codigo do cupom.");
        }
        if (percentualDesconto <= 0 || percentualDesconto > Configuracao.CUPOM_DESCONTO_MAXIMO) {
            throw new IllegalArgumentException("O desconto do cupom deve ser maior que 0% e no maximo "
                    + Configuracao.CUPOM_DESCONTO_MAXIMO + "%.");
        }
        if (valorMinimo < 0) {
            throw new IllegalArgumentException("O valor minimo do cupom nao pode ser negativo.");
        }
        if (validade == null) {
            throw new IllegalArgumentException("Informe a validade do cupom.");
        }
        if (usosMaximos < 1) {
            throw new IllegalArgumentException("O cupom precisa ter pelo menos 1 uso.");
        }
        this.codigo = codigo.trim().toUpperCase();
        this.percentualDesconto = percentualDesconto;
        this.valorMinimo = valorMinimo;
        this.validade = validade;
        this.usosMaximos = usosMaximos;
        this.usosFeitos = 0;
        this.somentePrimeiraCompra = somentePrimeiraCompra;
        this.ativo = true;
    }

    /**
     * Confere se o cupom pode ser usado. Se nao puder, lanca um erro com o motivo.
     *
     * @param base          base do pedido (depois do desconto por volume)
     * @param comprasPagas  quantas compras pagas o cliente ja tem
     * @param hoje          data de hoje (recebida de fora para facilitar os testes)
     */
    public void validar(double base, int comprasPagas, LocalDate hoje) {
        if (!ativo) {
            throw new IllegalArgumentException("O cupom " + codigo + " esta inativo.");
        }
        if (hoje.isAfter(validade)) {   // no ultimo dia ainda vale
            throw new IllegalArgumentException("O cupom " + codigo + " esta vencido.");
        }
        if (usosFeitos >= usosMaximos) {
            throw new IllegalArgumentException("O cupom " + codigo + " nao tem mais usos.");
        }
        if (base < valorMinimo) {
            throw new IllegalArgumentException("O cupom " + codigo + " exige pedido de no minimo "
                    + Dinheiro.formatar(valorMinimo) + ".");
        }
        if (somentePrimeiraCompra && comprasPagas > 0) {
            throw new IllegalArgumentException("O cupom " + codigo + " vale so na primeira compra.");
        }
    }

    /** Mesma conferencia, mas responde true ou false em vez de lancar erro. */
    public boolean podeSerUsado(double base, int comprasPagas, LocalDate hoje) {
        try {
            validar(base, comprasPagas, hoje);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    /** Pessoa C chama ao finalizar o pedido, se o desconto aplicado foi o do cupom. */
    public void consumirUso() {
        if (usosFeitos >= usosMaximos) {
            throw new IllegalArgumentException("O cupom " + codigo + " nao tem mais usos.");
        }
        usosFeitos++;
    }

    /** Pessoa D chama ao cancelar um pedido que usou o cupom. */
    public void devolverUso() {
        if (usosFeitos > 0) {
            usosFeitos--;
        }
    }

    public void ativar() {
        ativo = true;
    }

    public void desativar() {
        ativo = false;
    }

    // ---------------- getters ----------------

    public String getCodigo() {
        return codigo;
    }

    public double getPercentualDesconto() {
        return percentualDesconto;
    }

    public double getValorMinimo() {
        return valorMinimo;
    }

    public LocalDate getValidade() {
        return validade;
    }

    public int getUsosMaximos() {
        return usosMaximos;
    }

    public int getUsosFeitos() {
        return usosFeitos;
    }

    public boolean isSomentePrimeiraCompra() {
        return somentePrimeiraCompra;
    }

    public boolean isAtivo() {
        return ativo;
    }

    @Override
    public String toString() {
        return codigo + " - " + percentualDesconto + "% | minimo " + Dinheiro.formatar(valorMinimo)
                + " | valido ate " + validade + " | usos " + usosFeitos + "/" + usosMaximos
                + (somentePrimeiraCompra ? " | so 1a compra" : "")
                + (ativo ? "" : " | INATIVO");
    }
}
