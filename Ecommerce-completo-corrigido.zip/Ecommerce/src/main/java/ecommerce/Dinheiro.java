package ecommerce;

/**
 * Funcao UNICA de arredondamento, usada por todo o grupo.
 * Regra: 2 casas decimais, meio centavo para cima (ex.: 56,275 vira 56,28).
 */
public class Dinheiro {

    /**
     * Arredonda um valor em reais para 2 casas.
     *
     * Por que somar 0.0000001? O tipo double guarda alguns numeros de forma aproximada:
     * 56.275 fica guardado como 56.27499999... e arredondaria para 56.27.
     * Somar um valor minusculo corrige isso sem mudar nenhum valor real.
     */
    public static double arredondar(double valor) {
        if (valor < 0) {
            return -arredondar(-valor); // negativo: arredonda o positivo e devolve o sinal
        }
        return Math.round(valor * 100 + 0.0000001) / 100.0;
    }

    /** Calcula uma porcentagem ja arredondada. Ex.: porcentagem(310, 10) = 31.00 */
    public static double porcentagem(double valor, double percentual) {
        return arredondar(valor * percentual / 100);
    }

    /** Mostra o valor no formato brasileiro. Ex.: formatar(294.5) = "R$ 294,50" */
    public static String formatar(double valor) {
        if (valor < 0) {
            return "-" + formatar(-valor);
        }
        return "R$ " + String.format("%.2f", valor).replace('.', ',');
    }
}
