package ecommerce;

import java.time.LocalDate;

/**
 * Regras das formas de pagamento (§6).
 *  - PIX: 5% de desconto so sobre o valor dos produtos (frete nao tem desconto).
 *  - CARTAO: de 1x ate o menor entre 12 e (total / 20); ate 3x sem juros;
 *            de 4x em diante: total x 1,0199 elevado ao numero de parcelas.
 *  - BOLETO: sem desconto nem juros, vence em 3 dias.
 */
public class PagamentoCalculo {

    public static final String PIX = "PIX";
    public static final String CARTAO = "CARTAO";
    public static final String BOLETO = "BOLETO";

    /** Desconto do PIX (valor positivo). */
    public static double descontoPix(double valorProdutos) {
        return Dinheiro.porcentagem(valorProdutos, Configuracao.DESCONTO_PIX);
    }

    /** Maior numero de parcelas permitido para esse total (no minimo 1). */
    public static int maximoParcelas(double total) {
        int pelaParcelaMinima = (int) (total / Configuracao.CARTAO_PARCELA_MINIMA + 0.0000001);
        int maximo = Math.min(Configuracao.CARTAO_MAX_PARCELAS, pelaParcelaMinima);
        if (maximo < 1) {
            maximo = 1;
        }
        return maximo;
    }

    /** Quanto o cliente paga no cartao, com juros a partir de 4x. */
    public static double valorNoCartao(double total, int parcelas) {
        int maximo = maximoParcelas(total);
        if (parcelas < 1 || parcelas > maximo) {
            throw new IllegalArgumentException("Parcelas invalidas. Para este pedido escolha de 1 a " + maximo + "x.");
        }
        if (parcelas <= Configuracao.CARTAO_PARCELAS_SEM_JUROS) {
            return Dinheiro.arredondar(total);
        }
        double taxa = 1 + Configuracao.CARTAO_JUROS / 100;          // 1.0199
        return Dinheiro.arredondar(total * Math.pow(taxa, parcelas)); // Math.pow(a, b) = a elevado a b
    }

    /** Valor de cada parcela. */
    public static double valorParcela(double valorCobrado, int parcelas) {
        return Dinheiro.arredondar(valorCobrado / parcelas);
    }

    /** Data de vencimento do boleto: hoje + 3 dias. */
    public static LocalDate vencimentoBoleto(LocalDate hoje) {
        return hoje.plusDays(Configuracao.BOLETO_DIAS_VENCIMENTO);
    }
}
