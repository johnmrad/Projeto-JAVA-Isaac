package ecommerce;

/**
 * ARQUIVO UNICO DE CONFIGURACAO ("Decisoes minhas").
 *
 * Todos os numeros das regras ficam aqui. Se o grupo quiser mudar um valor,
 * muda so nesta classe, sem mexer na logica das outras.
 *
 * "public static final" = constante: um valor fixo que qualquer classe pode ler,
 * por exemplo: Configuracao.DESCONTO_PIX
 */
public class Configuracao {

    // ----- Desconto por volume (por item) -----
    public static final int VOLUME_QTD_FAIXA1 = 5;          // a partir de 5 unidades...
    public static final double VOLUME_DESCONTO_FAIXA1 = 5;   // ...5% de desconto
    public static final int VOLUME_QTD_FAIXA2 = 10;         // a partir de 10 unidades...
    public static final double VOLUME_DESCONTO_FAIXA2 = 10;  // ...10% de desconto

    // ----- Pagamento -----
    public static final double DESCONTO_PIX = 5;             // 5% sobre o valor dos produtos
    public static final int CARTAO_MAX_PARCELAS = 12;
    public static final double CARTAO_PARCELA_MINIMA = 20;   // total / 20 = maximo de parcelas
    public static final int CARTAO_PARCELAS_SEM_JUROS = 3;
    public static final double CARTAO_JUROS = 1.99;          // % ao mes, a partir de 4x
    public static final int BOLETO_DIAS_VENCIMENTO = 3;

    // ----- Fidelidade -----
    public static final double NIVEL_PRATA_A_PARTIR_DE = 500;
    public static final double NIVEL_OURO_A_PARTIR_DE = 1500;
    public static final double DESCONTO_BRONZE = 0;          // % sobre a base
    public static final double DESCONTO_PRATA = 3;
    public static final double DESCONTO_OURO = 5;

    // ----- Pontos -----
    public static final double VALOR_DO_PONTO = 0.10;        // cada ponto vale R$ 0,10
    public static final double RESGATE_MAXIMO = 30;          // no maximo 30% do pedido
    public static final double REAIS_POR_PONTO_GANHO = 10;   // ganha 1 ponto a cada R$ 10

    // ----- Cupom -----
    public static final double CUPOM_DESCONTO_MAXIMO = 50;   // ate 50%

    // ----- Pedido e carrinho (usados pelas pessoas C e D) -----
    public static final int HORAS_PARA_EXPIRAR_PEDIDO = 24;
    public static final int MAXIMO_UNIDADES_POR_PRODUTO = 20;

    // ----- Frete -----
    public static final double FRETE_GRATIS_A_PARTIR_DE = 250;
    public static final double FRETE_PA = 12;
    public static final double FRETE_NORTE = 18;
    public static final double FRETE_NORDESTE = 22;
    public static final double FRETE_CENTRO_OESTE = 24;
    public static final double FRETE_SUDESTE = 28;
    public static final double FRETE_SUL = 32;

    /**
     * Devolve o frete da tabela para a UF.
     * Se a UF nao existir, lanca um erro (a Pessoa A pode usar isso para validar a UF do cliente).
     */
    public static double fretePorUf(String uf) {
        if (uf == null) {
            throw new IllegalArgumentException("Informe a UF de entrega.");
        }
        switch (uf.toUpperCase()) {
            case "PA":
                return FRETE_PA;
            case "AC": case "AM": case "AP": case "RO": case "RR": case "TO":
                return FRETE_NORTE;
            case "AL": case "BA": case "CE": case "MA": case "PB": case "PE": case "PI": case "RN": case "SE":
                return FRETE_NORDESTE;
            case "DF": case "GO": case "MS": case "MT":
                return FRETE_CENTRO_OESTE;
            case "ES": case "MG": case "RJ": case "SP":
                return FRETE_SUDESTE;
            case "PR": case "RS": case "SC":
                return FRETE_SUL;
            default:
                throw new IllegalArgumentException("UF invalida: " + uf);
        }
    }
}
