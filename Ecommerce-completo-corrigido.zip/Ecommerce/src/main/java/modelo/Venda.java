package modelo;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record Venda(Long pedidoId, Long clienteId, String clienteNome,
                    LocalDateTime dataPagamento, BigDecimal valor) {}