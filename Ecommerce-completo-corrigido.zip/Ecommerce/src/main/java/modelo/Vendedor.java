package modelo;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class Vendedor extends Entidade {
    @Column(nullable = false, length = 100)
    private String nome;
    @Column(nullable = false, unique = true, length = 150)
    private String email;
    @Column(nullable = false, precision = 5, scale = 2)
    private BigDecimal comissaoPercentual;

    protected Vendedor() {}

    public Vendedor(String nome, String email, BigDecimal comissaoPercentual) {
        this.nome = nome;
        this.email = email;
        this.comissaoPercentual = comissaoPercentual;
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public BigDecimal getComissaoPercentual() { return comissaoPercentual; }
    public void setComissaoPercentual(BigDecimal c) { this.comissaoPercentual = c; }
}