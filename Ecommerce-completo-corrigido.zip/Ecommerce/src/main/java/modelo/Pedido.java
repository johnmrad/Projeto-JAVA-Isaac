package modelo;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Pedido extends Entidade {
    @ManyToOne(optional = false)
    private Cliente cliente;
    @Enumerated(EnumType.STRING)
    private StatusPedido status = StatusPedido.CARRINHO;
    private LocalDateTime dataCriacao;
    private LocalDateTime dataFinalizacao;
    private LocalDateTime dataPagamento;
    @ManyToOne
    private Cupom cupom;
    private int pontosUsados;
    private String codigoRastreio;
    @OneToOne(mappedBy = "pedido", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Pagamento pagamento;
    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<ItemPedido> itens = new ArrayList<>();

    private BigDecimal subtotalBruto = BigDecimal.ZERO;
    private BigDecimal descontoVolume = BigDecimal.ZERO;
    private BigDecimal base = BigDecimal.ZERO;
    private BigDecimal descontoComercial = BigDecimal.ZERO;
    private BigDecimal valorPontos = BigDecimal.ZERO;
    private BigDecimal valorProdutos = BigDecimal.ZERO;
    private BigDecimal frete = BigDecimal.ZERO;
    private BigDecimal total = BigDecimal.ZERO;
    private BigDecimal valorCobrado = BigDecimal.ZERO;

    protected Pedido() {}

    public Pedido(Cliente cliente, LocalDateTime dataCriacao) {
        this.cliente = cliente;
        this.dataCriacao = dataCriacao;
    }

    public void adicionarItem(ItemPedido item) {
        item.setPedido(this);
        itens.add(item);
    }

    public void setPagamento(Pagamento pagamento) {
        this.pagamento = pagamento;
        if (pagamento != null) {
            pagamento.setPedido(this);
        }
    }

    public Cliente getCliente() { return cliente; }
    public StatusPedido getStatus() { return status; }
    public void setStatus(StatusPedido status) { this.status = status; }
    public LocalDateTime getDataCriacao() { return dataCriacao; }
    public LocalDateTime getDataFinalizacao() { return dataFinalizacao; }
    public void setDataFinalizacao(LocalDateTime d) { this.dataFinalizacao = d; }
    public LocalDateTime getDataPagamento() { return dataPagamento; }
    public void setDataPagamento(LocalDateTime d) { this.dataPagamento = d; }
    public Cupom getCupom() { return cupom; }
    public void setCupom(Cupom cupom) { this.cupom = cupom; }
    public int getPontosUsados() { return pontosUsados; }
    public void setPontosUsados(int p) { this.pontosUsados = p; }
    public String getCodigoRastreio() { return codigoRastreio; }
    public void setCodigoRastreio(String c) { this.codigoRastreio = c; }
    public Pagamento getPagamento() { return pagamento; }
    public List<ItemPedido> getItens() { return itens; }
    public BigDecimal getSubtotalBruto() { return subtotalBruto; }
    public void setSubtotalBruto(BigDecimal v) { this.subtotalBruto = v; }
    public BigDecimal getDescontoVolume() { return descontoVolume; }
    public void setDescontoVolume(BigDecimal v) { this.descontoVolume = v; }
    public BigDecimal getBase() { return base; }
    public void setBase(BigDecimal v) { this.base = v; }
    public BigDecimal getDescontoComercial() { return descontoComercial; }
    public void setDescontoComercial(BigDecimal v) { this.descontoComercial = v; }
    public BigDecimal getValorPontos() { return valorPontos; }
    public void setValorPontos(BigDecimal v) { this.valorPontos = v; }
    public BigDecimal getValorProdutos() { return valorProdutos; }
    public void setValorProdutos(BigDecimal v) { this.valorProdutos = v; }
    public BigDecimal getFrete() { return frete; }
    public void setFrete(BigDecimal v) { this.frete = v; }
    public BigDecimal getTotal() { return total; }
    public void setTotal(BigDecimal v) { this.total = v; }
    public BigDecimal getValorCobrado() { return valorCobrado; }
    public void setValorCobrado(BigDecimal v) { this.valorCobrado = v; }
}