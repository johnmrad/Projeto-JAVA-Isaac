package modelo;

import java.math.BigDecimal;

public record VendaCategoria(Long categoriaId, String categoriaNome, long quantidade, BigDecimal valor) {}
