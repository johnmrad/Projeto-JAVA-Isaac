package modelo;

public enum StatusPedido {
    CARRINHO, AGUARDANDO_PAGAMENTO, PAGO, SEPARADO, ENVIADO, ENTREGUE, CANCELADO;

    public boolean contaComoVenda() {
        return this == PAGO || this == SEPARADO || this == ENVIADO || this == ENTREGUE;
    }
}