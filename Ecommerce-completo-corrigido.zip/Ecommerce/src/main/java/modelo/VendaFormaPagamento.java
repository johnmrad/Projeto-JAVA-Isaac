package modelo;

import java.math.BigDecimal;

public record VendaFormaPagamento(MetodoPagamento metodo, long pedidos, BigDecimal valor) {}
