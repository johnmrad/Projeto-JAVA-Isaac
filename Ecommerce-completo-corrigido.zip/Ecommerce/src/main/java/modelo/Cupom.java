package modelo;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
public class Cupom extends Entidade {
    @Column(nullable = false, unique = true, length = 30)
    private String codigo;
    private BigDecimal percentualDesconto;
    private BigDecimal valorMinimo;
    private LocalDate validade;
    private int usosMaximos;
    private int usosRealizados;
    private boolean somentePrimeiraCompra;
    private boolean ativo = true;

    protected Cupom() {}

    public Cupom(String codigo, BigDecimal percentualDesconto, BigDecimal valorMinimo,
                 LocalDate validade, int usosMaximos, boolean somentePrimeiraCompra) {
        this.codigo = codigo;
        this.percentualDesconto = percentualDesconto;
        this.valorMinimo = valorMinimo;
        this.validade = validade;
        this.usosMaximos = usosMaximos;
        this.somentePrimeiraCompra = somentePrimeiraCompra;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public BigDecimal getPercentualDesconto() { return percentualDesconto; }
    public void setPercentualDesconto(BigDecimal p) { this.percentualDesconto = p; }
    public BigDecimal getValorMinimo() { return valorMinimo; }
    public void setValorMinimo(BigDecimal v) { this.valorMinimo = v; }
    public LocalDate getValidade() { return validade; }
    public void setValidade(LocalDate validade) { this.validade = validade; }
    public int getUsosMaximos() { return usosMaximos; }
    public void setUsosMaximos(int usosMaximos) { this.usosMaximos = usosMaximos; }
    public int getUsosRealizados() { return usosRealizados; }
    public void setUsosRealizados(int usosRealizados) { this.usosRealizados = usosRealizados; }
    public boolean isSomentePrimeiraCompra() { return somentePrimeiraCompra; }
    public void setSomentePrimeiraCompra(boolean s) { this.somentePrimeiraCompra = s; }
    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }
}