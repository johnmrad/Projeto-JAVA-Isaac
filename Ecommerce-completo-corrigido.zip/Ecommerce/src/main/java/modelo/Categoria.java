package modelo;

import jakarta.persistence.*;

@Entity
public class Categoria extends Entidade {
    @Column(nullable = false, unique = true, length = 100)
    private String nome;

    protected Categoria() {}

    public Categoria(String nome) {
        this.nome = nome;
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
}