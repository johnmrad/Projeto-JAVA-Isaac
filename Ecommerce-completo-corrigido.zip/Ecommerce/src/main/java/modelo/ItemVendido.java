package modelo;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Uma linha de venda: um item de um pedido que conta como venda (§12).
 * Serve de base para comissão a pagar, vendas por categoria e para o CSV do mês (§13).
 */
public record ItemVendido(Long pedidoId, LocalDateTime dataPagamento,
                          String clienteNome, String clienteUf,
                          Long vendedorId, String vendedorNome,
                          Long produtoId, String produtoNome,
                          Long categoriaId, String categoriaNome,
                          int quantidade, BigDecimal precoUnitario,
                          BigDecimal descontoVolume, BigDecimal valorLiquido,
                          BigDecimal comissao, MetodoPagamento metodo, StatusPedido status) {}
