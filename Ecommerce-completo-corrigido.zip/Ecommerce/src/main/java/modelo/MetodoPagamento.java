package modelo;

public enum MetodoPagamento { PIX, CARTAO, BOLETO }