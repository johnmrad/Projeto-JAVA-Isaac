package modelo;

public enum Papel { CLIENTE, VENDEDOR, LOJA }