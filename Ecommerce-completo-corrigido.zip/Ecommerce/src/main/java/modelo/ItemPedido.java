package modelo;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class ItemPedido extends Entidade {
    @ManyToOne(optional = false)
    private Pedido pedido;
    @ManyToOne(optional = false)
    private Produto produto;
    private int quantidade;
    private BigDecimal precoUnitario;
    private BigDecimal descontoVolume = BigDecimal.ZERO;
    private BigDecimal valorLiquido = BigDecimal.ZERO;
    private BigDecimal comissao = BigDecimal.ZERO;

    protected ItemPedido() {}

    public ItemPedido(Produto produto, int quantidade, BigDecimal precoUnitario) {
        this.produto = produto;
        this.quantidade = quantidade;
        this.precoUnitario = precoUnitario;
    }

    public Pedido getPedido() { return pedido; }
    public void setPedido(Pedido pedido) { this.pedido = pedido; }
    public Produto getProduto() { return produto; }
    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    public BigDecimal getPrecoUnitario() { return precoUnitario; }
    public void setPrecoUnitario(BigDecimal p) { this.precoUnitario = p; }
    public BigDecimal getDescontoVolume() { return descontoVolume; }
    public void setDescontoVolume(BigDecimal d) { this.descontoVolume = d; }
    public BigDecimal getValorLiquido() { return valorLiquido; }
    public void setValorLiquido(BigDecimal v) { this.valorLiquido = v; }
    public BigDecimal getComissao() { return comissao; }
    public void setComissao(BigDecimal c) { this.comissao = c; }
}