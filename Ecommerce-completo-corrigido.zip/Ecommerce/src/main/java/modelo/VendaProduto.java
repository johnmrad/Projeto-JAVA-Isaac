package modelo;

import java.math.BigDecimal;

public record VendaProduto(Long produtoId, String produtoNome, Long quantidade, BigDecimal valor) {}