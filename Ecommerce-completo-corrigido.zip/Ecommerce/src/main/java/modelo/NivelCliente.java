package modelo;

public enum NivelCliente { BRONZE, PRATA, OURO }