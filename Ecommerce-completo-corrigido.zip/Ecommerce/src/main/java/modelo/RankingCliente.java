package modelo;

import java.math.BigDecimal;

public record RankingCliente(Long clienteId, String clienteNome, BigDecimal total) {}