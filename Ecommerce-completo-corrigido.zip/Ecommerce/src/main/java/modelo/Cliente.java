package modelo;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class Cliente extends Entidade {
    @Column(nullable = false, length = 100)
    private String nome;
    @Column(nullable = false, unique = true, length = 150)
    private String email;
    @Column(nullable = false, unique = true, length = 11)
    private String cpf;
    @Column(nullable = false, length = 80)
    private String cidade;
    @Column(nullable = false, length = 2)
    private String uf;
    @Column(nullable = false, length = 200)
    private String endereco;
    private int pontos;
    private BigDecimal totalGasto = BigDecimal.ZERO;
    private int comprasPagas;
    private boolean ativo = true;

    protected Cliente() {}

    public Cliente(String nome, String email, String cpf, String cidade, String uf, String endereco) {
        this.nome = nome;
        this.email = email;
        this.cpf = cpf;
        this.cidade = cidade;
        this.uf = uf;
        this.endereco = endereco;
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }
    public String getCidade() { return cidade; }
    public void setCidade(String cidade) { this.cidade = cidade; }
    public String getUf() { return uf; }
    public void setUf(String uf) { this.uf = uf; }
    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
    public int getPontos() { return pontos; }
    public void setPontos(int pontos) { this.pontos = pontos; }
    public BigDecimal getTotalGasto() { return totalGasto; }
    public void setTotalGasto(BigDecimal totalGasto) { this.totalGasto = totalGasto; }
    public int getComprasPagas() { return comprasPagas; }
    public void setComprasPagas(int comprasPagas) { this.comprasPagas = comprasPagas; }
    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }
}