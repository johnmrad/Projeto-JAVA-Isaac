package modelo;

import java.math.BigDecimal;

public record ComissaoVendedor(Long vendedorId, String vendedorNome, BigDecimal comissao) {}
