package modelo;

public enum StatusPagamento { PENDENTE, APROVADO, ESTORNADO }