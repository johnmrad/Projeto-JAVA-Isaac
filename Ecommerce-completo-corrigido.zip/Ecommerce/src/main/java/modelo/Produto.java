package modelo;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class Produto extends Entidade {
    @Column(nullable = false, length = 150)
    private String nome;
    @Column(length = 500)
    private String descricao;
    private BigDecimal preco;
    private int estoque;
    private boolean ativo = true;
    @ManyToOne(optional = false)
    private Categoria categoria;
    @ManyToOne(optional = false)
    private Vendedor vendedor;

    protected Produto() {}

    public Produto(String nome, String descricao, BigDecimal preco, int estoque,
                   Categoria categoria, Vendedor vendedor) {
        this.nome = nome;
        this.descricao = descricao;
        this.preco = preco;
        this.estoque = estoque;
        this.categoria = categoria;
        this.vendedor = vendedor;
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public BigDecimal getPreco() { return preco; }
    public void setPreco(BigDecimal preco) { this.preco = preco; }
    public int getEstoque() { return estoque; }
    public void setEstoque(int estoque) { this.estoque = estoque; }
    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }
    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }
    public Vendedor getVendedor() { return vendedor; }
    public void setVendedor(Vendedor vendedor) { this.vendedor = vendedor; }
}