package modelo;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
public class Pagamento extends Entidade {
    @OneToOne(optional = false)
    @JoinColumn(unique = true)
    private Pedido pedido;
    @Enumerated(EnumType.STRING)
    private MetodoPagamento metodo;
    @Enumerated(EnumType.STRING)
    private StatusPagamento status = StatusPagamento.PENDENTE;
    private int parcelas = 1;
    private BigDecimal valorBase = BigDecimal.ZERO;
    private BigDecimal ajuste = BigDecimal.ZERO;
    private BigDecimal valorFinal = BigDecimal.ZERO;
    private LocalDate vencimento;

    protected Pagamento() {}

    public Pagamento(MetodoPagamento metodo) { this.metodo = metodo; }

    public Pedido getPedido() { return pedido; }
    public void setPedido(Pedido pedido) { this.pedido = pedido; }
    public MetodoPagamento getMetodo() { return metodo; }
    public void setMetodo(MetodoPagamento metodo) { this.metodo = metodo; }
    public StatusPagamento getStatus() { return status; }
    public void setStatus(StatusPagamento status) { this.status = status; }
    public int getParcelas() { return parcelas; }
    public void setParcelas(int parcelas) { this.parcelas = parcelas; }
    public BigDecimal getValorBase() { return valorBase; }
    public void setValorBase(BigDecimal v) { this.valorBase = v; }
    public BigDecimal getAjuste() { return ajuste; }
    public void setAjuste(BigDecimal ajuste) { this.ajuste = ajuste; }
    public BigDecimal getValorFinal() { return valorFinal; }
    public void setValorFinal(BigDecimal v) { this.valorFinal = v; }
    public LocalDate getVencimento() { return vencimento; }
    public void setVencimento(LocalDate vencimento) { this.vencimento = vencimento; }
}