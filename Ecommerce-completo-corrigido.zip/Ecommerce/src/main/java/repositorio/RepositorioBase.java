package repositorio;

import jakarta.persistence.TypedQuery;
import modelo.Entidade;
import util.Jpa;
import java.util.List;
import java.util.Optional;

public abstract class RepositorioBase<T extends Entidade> {
    protected final Class<T> tipo;

    protected RepositorioBase(Class<T> tipo) {
        this.tipo = tipo;
    }

    public T salvar(T e) {
        Jpa.executar(em -> {
            if (e.getId() == null) {
                em.persist(e);
            } else {
                em.merge(e);
            }
        });
        return e;
    }

    public Optional<T> buscarPorId(Long id) {
        return Jpa.consultar(em -> Optional.ofNullable(em.find(tipo, id)));
    }

    protected List<T> listar(String jpql, Object... params) {
        return Jpa.consultar(em -> {
            TypedQuery<T> q = em.createQuery(jpql, tipo);
            for (int i = 0; i < params.length; i++) {
                q.setParameter(i + 1, params[i]);
            }
            return q.getResultList();
        });
    }

    protected Optional<T> buscarUm(String jpql, Object... params) {
        return listar(jpql, params).stream().findFirst();
    }
}