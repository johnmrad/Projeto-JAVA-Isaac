package repositorio;

import modelo.Cliente;
import modelo.StatusPedido;
import util.Jpa;
import java.util.List;
import java.util.Optional;

public class ClienteRepositorio extends RepositorioBase<Cliente> {
    public ClienteRepositorio() { super(Cliente.class); }

    public Optional<Cliente> buscarPorCpf(String cpf) {
        return buscarUm("from Cliente where cpf = ?1", cpf);
    }

    public Optional<Cliente> buscarPorEmail(String email) {
        return buscarUm("from Cliente where email = ?1", email);
    }

    public List<Cliente> listarTodos() {
        return listar("from Cliente order by nome");
    }

    public boolean temPedidoEmAndamento(Long clienteId) {
        List<StatusPedido> andamento = List.of(StatusPedido.AGUARDANDO_PAGAMENTO,
                StatusPedido.PAGO, StatusPedido.SEPARADO, StatusPedido.ENVIADO);
        return Jpa.consultar(em -> em.createQuery(
                "select count(p) from Pedido p where p.cliente.id = :id and p.status in :st", Long.class)
                .setParameter("id", clienteId)
                .setParameter("st", andamento)
                .getSingleResult() > 0);
    }
}