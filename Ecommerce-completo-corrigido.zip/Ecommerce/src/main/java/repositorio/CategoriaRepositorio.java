package repositorio;

import modelo.Categoria;
import java.util.List;
import java.util.Optional;

public class CategoriaRepositorio extends RepositorioBase<Categoria> {
    public CategoriaRepositorio() { super(Categoria.class); }

    public Optional<Categoria> buscarPorNome(String nome) {
        return buscarUm("from Categoria where nome = ?1", nome);
    }

    public List<Categoria> listarTodos() {
        return listar("from Categoria order by nome");
    }
}