package repositorio;

import modelo.Cupom;
import java.util.List;
import java.util.Optional;

public class CupomRepositorio extends RepositorioBase<Cupom> {
    public CupomRepositorio() { super(Cupom.class); }

    public Optional<Cupom> buscarPorCodigo(String codigo) {
        return buscarUm("select c from Cupom c where upper(c.codigo) = upper(?1)", codigo);
    }

    public List<Cupom> listarTodos() {
        return listar("select c from Cupom c order by c.codigo");
    }
}
