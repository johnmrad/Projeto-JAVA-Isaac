package repositorio;

import modelo.StatusPedido;
import modelo.Venda;
import modelo.VendaProduto;
import util.Jpa;
import java.util.Arrays;
import java.util.List;

public class VendaRepositorio {

    private static final List<StatusPedido> STATUS_VENDA = Arrays.stream(StatusPedido.values())
            .filter(StatusPedido::contaComoVenda).toList();

    private static final String FILTRO =
        " where p.status in :st and extract(year from p.dataPagamento) = :ano"
        + " and extract(month from p.dataPagamento) = :mes";

    public List<Venda> vendasDoMes(int ano, int mes, Long vendedorId) {
        return Jpa.consultar(em -> {
            if (vendedorId == null) {
                return em.createQuery(
                    "select new modelo.Venda(p.id, c.id, c.nome, p.dataPagamento, p.valorProdutos) "
                    + "from Pedido p join p.cliente c" + FILTRO, Venda.class)
                    .setParameter("st", STATUS_VENDA)
                    .setParameter("ano", ano)
                    .setParameter("mes", mes)
                    .getResultList();
            }
            return em.createQuery(
                "select new modelo.Venda(p.id, c.id, c.nome, p.dataPagamento, sum(i.valorLiquido)) "
                + "from Pedido p join p.cliente c join p.itens i join i.produto pr"
                + FILTRO + " and pr.vendedor.id = :ven "
                + "group by p.id, c.id, c.nome, p.dataPagamento", Venda.class)
                .setParameter("st", STATUS_VENDA)
                .setParameter("ano", ano)
                .setParameter("mes", mes)
                .setParameter("ven", vendedorId)
                .getResultList();
        });
    }

    public List<VendaProduto> rankingProdutos(int ano, int mes, Long vendedorId) {
        String filtroVendedor = vendedorId == null ? "" : " and pr.vendedor.id = :ven";
        return Jpa.consultar(em -> {
            var q = em.createQuery(
                "select new modelo.VendaProduto(pr.id, pr.nome, sum(i.quantidade), sum(i.valorLiquido)) "
                + "from Pedido p join p.itens i join i.produto pr"
                + FILTRO + filtroVendedor
                + " group by pr.id, pr.nome "
                + "order by sum(i.quantidade) desc, sum(i.valorLiquido) desc, pr.nome", VendaProduto.class)
                .setParameter("st", STATUS_VENDA)
                .setParameter("ano", ano)
                .setParameter("mes", mes);
            if (vendedorId != null) {
                q.setParameter("ven", vendedorId);
            }
            return q.getResultList();
        });
    }
}