package repositorio;

import modelo.MetodoPagamento;
import modelo.Pedido;
import modelo.StatusPedido;
import util.Jpa;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PedidoRepositorio extends RepositorioBase<Pedido> {
    public PedidoRepositorio() { super(Pedido.class); }

    /** Ids dos pedidos num status, do mais antigo para o mais novo (usado pela rotina de expiração). */
    public List<Long> idsPorStatus(StatusPedido status) {
        return Jpa.consultar(em -> em.createQuery(
                "select p.id from Pedido p where p.status = :st order by p.id", Long.class)
                .setParameter("st", status)
                .getResultList());
    }

    /** Forma de pagamento de cada pedido da lista (pedido sem pagamento não aparece no mapa). */
    public Map<Long, MetodoPagamento> metodosDosPedidos(List<Long> pedidoIds) {
        Map<Long, MetodoPagamento> mapa = new HashMap<>();
        if (pedidoIds.isEmpty()) {
            return mapa;
        }
        Jpa.consultar(em -> em.createQuery(
                "select p.id, pg.metodo from Pedido p join p.pagamento pg where p.id in :ids", Object[].class)
                .setParameter("ids", pedidoIds)
                .getResultList())
            .forEach(linha -> mapa.put((Long) linha[0], (MetodoPagamento) linha[1]));
        return mapa;
    }

    /**
     * Pedidos finalizados que foram criados no mês (base da taxa de cancelamento).
     * Com vendedorId, só os pedidos que têm pelo menos um item desse vendedor.
     */
    public long contarFinalizadosCriadosNoMes(int ano, int mes, Long vendedorId, boolean soCancelados) {
        StringBuilder jpql = new StringBuilder(
                "select count(p) from Pedido p where p.dataFinalizacao is not null"
                + " and extract(year from p.dataCriacao) = :ano"
                + " and extract(month from p.dataCriacao) = :mes");
        if (soCancelados) {
            jpql.append(" and p.status = :cancelado");
        }
        if (vendedorId != null) {
            jpql.append(" and exists (select i.id from ItemPedido i where i.pedido = p"
                    + " and i.produto.vendedor.id = :ven)");
        }
        return Jpa.consultar(em -> {
            var q = em.createQuery(jpql.toString(), Long.class)
                    .setParameter("ano", ano)
                    .setParameter("mes", mes);
            if (soCancelados) {
                q.setParameter("cancelado", StatusPedido.CANCELADO);
            }
            if (vendedorId != null) {
                q.setParameter("ven", vendedorId);
            }
            return q.getSingleResult();
        });
    }

    /** Pedidos do cliente (inclusive o carrinho), do mais novo para o mais antigo. */
    public List<Pedido> listarPorCliente(Long clienteId) {
        return listar("select p from Pedido p where p.cliente.id = ?1 order by p.id desc", clienteId);
    }

    /** Pedidos que têm pelo menos um item do vendedor (sem carrinhos). */
    public List<Pedido> listarPorVendedor(Long vendedorId) {
        return listar("select distinct p from Pedido p join p.itens i where i.produto.vendedor.id = ?1"
                + " and p.status <> ?2 order by p.id desc", vendedorId, StatusPedido.CARRINHO);
    }

    public List<Pedido> listarTodosSemCarrinho() {
        return listar("select p from Pedido p where p.status <> ?1 order by p.id desc", StatusPedido.CARRINHO);
    }
}
