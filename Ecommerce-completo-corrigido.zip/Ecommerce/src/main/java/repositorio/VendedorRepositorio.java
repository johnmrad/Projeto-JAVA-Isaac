package repositorio;

import modelo.Vendedor;
import java.util.List;
import java.util.Optional;

public class VendedorRepositorio extends RepositorioBase<Vendedor> {
    public VendedorRepositorio() { super(Vendedor.class); }

    public Optional<Vendedor> buscarPorEmail(String email) {
        return buscarUm("from Vendedor where email = ?1", email);
    }

    public List<Vendedor> listarTodos() {
        return listar("from Vendedor order by nome");
    }
}