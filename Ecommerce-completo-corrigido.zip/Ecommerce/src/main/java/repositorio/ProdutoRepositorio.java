package repositorio;

import modelo.Produto;
import util.Jpa;
import java.util.List;

public class ProdutoRepositorio extends RepositorioBase<Produto> {
    public ProdutoRepositorio() { super(Produto.class); }

    public List<Produto> listarTodos() {
        return listar("from Produto order by nome");
    }

    public List<Produto> listarAtivosComEstoque() {
        return listar("from Produto where ativo = true and estoque > 0 order by nome");
    }

    public List<Produto> listarEstoqueBaixo(int limite) {
        return listar("from Produto where ativo = true and estoque <= ?1 order by estoque, nome", limite);
    }

    public boolean existeEmPedido(Long produtoId) {
        return Jpa.consultar(em -> em.createQuery(
                "select count(i) from ItemPedido i where i.produto.id = :id", Long.class)
                .setParameter("id", produtoId)
                .getSingleResult() > 0);
    }

    public void excluir(Long id) {
        Jpa.executar(em -> em.remove(em.find(Produto.class, id)));
    }
}