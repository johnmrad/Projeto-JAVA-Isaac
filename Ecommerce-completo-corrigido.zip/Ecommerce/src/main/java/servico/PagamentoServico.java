package servico;

import ecommerce.Configuracao;
import jakarta.persistence.EntityManager;
import jakarta.persistence.LockModeType;
import modelo.Cliente;
import modelo.MetodoPagamento;
import modelo.Pagamento;
import modelo.Pedido;
import modelo.StatusPagamento;
import modelo.StatusPedido;
import util.Jpa;
import util.RegraNegocioException;
import util.Relogio;
import util.Validacao;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class PagamentoServico {

    public Pedido pagar(Usuario ator, Long pedidoId, MetodoPagamento metodo, int parcelas) {
        Validacao.exigir(metodo != null, "Escolha a forma de pagamento.");
        return Jpa.transacao(em -> {
            Pedido pedido = pedidoTravado(em, pedidoId);
            Permissao.exigirProprioOuLoja(ator, pedido.getCliente().getId());
            Validacao.exigir(pedido.getStatus() == StatusPedido.AGUARDANDO_PAGAMENTO,
                    "Este pedido não está aguardando pagamento.");
            Validacao.exigir(!vencido(pedido), "Pedido vencido: o prazo para pagar acabou.");

            Pagamento pagamento = pedido.getPagamento();
            if (pagamento == null) {
                pagamento = new Pagamento(metodo);
                pedido.setPagamento(pagamento);
            } else {
                Validacao.exigir(metodo != MetodoPagamento.BOLETO, "O boleto deste pedido já foi gerado.");
                pagamento.setMetodo(metodo);
            }

            int parcelasUsadas = metodo == MetodoPagamento.CARTAO ? parcelas : 1;
            BigDecimal valorFinal = CalculadoraDoPedido.valorCobrado(pedido, metodo, parcelasUsadas);
            pagamento.setParcelas(parcelasUsadas);
            pagamento.setValorBase(pedido.getTotal());
            pagamento.setAjuste(valorFinal.subtract(pedido.getTotal()));
            pagamento.setValorFinal(valorFinal);
            pedido.setValorCobrado(valorFinal);

            if (metodo == MetodoPagamento.BOLETO) {
                pagamento.setVencimento(CalculadoraDoPedido.vencimentoBoleto());
            } else {
                pagamento.setVencimento(null);
                confirmar(pedido);
            }
            return pedido;
        });
    }

    public Pedido compensarBoleto(Usuario ator, Long pedidoId) {
        Permissao.exigirLoja(ator);
        return Jpa.transacao(em -> {
            Pedido pedido = pedidoTravado(em, pedidoId);
            Pagamento pagamento = pedido.getPagamento();
            Validacao.exigir(pagamento != null && pagamento.getMetodo() == MetodoPagamento.BOLETO
                    && pagamento.getStatus() == StatusPagamento.PENDENTE, "Este pedido não tem boleto pendente.");
            Validacao.exigir(!vencido(pedido), "Pedido vencido: o prazo para pagar acabou.");
            confirmar(pedido);
            return pedido;
        });
    }

    private void confirmar(Pedido pedido) {
        pedido.getPagamento().setStatus(StatusPagamento.APROVADO);
        FluxoPedido.mudar(pedido, StatusPedido.PAGO);
        pedido.setDataPagamento(Relogio.agora());

        Cliente cliente = pedido.getCliente();
        cliente.setTotalGasto(cliente.getTotalGasto().add(pedido.getValorCobrado()));
        cliente.setComprasPagas(cliente.getComprasPagas() + 1);
        cliente.setPontos(cliente.getPontos() + CalculadoraDoPedido.pontosGanhos(pedido.getValorCobrado()));
    }

    private boolean vencido(Pedido pedido) {
        Pagamento pagamento = pedido.getPagamento();
        if (pagamento != null && pagamento.getMetodo() == MetodoPagamento.BOLETO) {
            return Relogio.hoje().isAfter(pagamento.getVencimento());
        }
        LocalDateTime prazo = pedido.getDataFinalizacao().plusHours(Configuracao.HORAS_PARA_EXPIRAR_PEDIDO);
        return Relogio.agora().isAfter(prazo);
    }

    private Pedido pedidoTravado(EntityManager em, Long pedidoId) {
        Long clienteId = em.createQuery("select p.cliente.id from Pedido p where p.id = :id", Long.class)
                .setParameter("id", pedidoId)
                .getResultStream().findFirst()
                .orElseThrow(() -> new RegraNegocioException("Pedido não encontrado."));
        em.find(Cliente.class, clienteId, LockModeType.PESSIMISTIC_WRITE);
        return em.find(Pedido.class, pedidoId);
    }
}
