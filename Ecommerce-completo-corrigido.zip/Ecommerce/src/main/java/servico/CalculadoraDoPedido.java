package servico;

import ecommerce.CalculoPedido;
import ecommerce.CupomCalculo;
import ecommerce.Dinheiro;
import ecommerce.Fidelidade;
import ecommerce.ItemPedidoCalculo;
import ecommerce.PagamentoCalculo;
import modelo.Cliente;
import modelo.Cupom;
import modelo.ItemPedido;
import modelo.MetodoPagamento;
import modelo.Pedido;
import util.RegraNegocioException;
import util.Relogio;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

public class CalculadoraDoPedido {

    public static void recalcular(Pedido pedido) {
        Cliente cliente = pedido.getCliente();
        CalculoPedido calculo = new CalculoPedido(cliente.getUf());
        calculo.setHoje(Relogio.hoje());
        for (ItemPedido item : pedido.getItens()) {
            calculo.adicionarItem(new ItemPedidoCalculo(
                    item.getProduto().getNome(),
                    item.getPrecoUnitario().doubleValue(),
                    item.getQuantidade(),
                    item.getProduto().getVendedor().getComissaoPercentual().doubleValue()));
        }
        calculo.setNivelFidelidade(Fidelidade.calcularNivel(cliente.getTotalGasto().doubleValue()));
        if (pedido.getCupom() != null) {
            calculo.setCupom(paraCalculo(pedido.getCupom()), cliente.getComprasPagas());
        }
        calculo.setPontos(pedido.getPontosUsados(), cliente.getPontos());
        calculo.calcular();
        guardarResultado(calculo, pedido);
    }

    public static void validarCupom(Cupom cupom, Pedido pedido) {
        try {
            paraCalculo(cupom).validar(pedido.getBase().doubleValue(),
                    pedido.getCliente().getComprasPagas(), Relogio.hoje());
        } catch (IllegalArgumentException e) {
            throw new RegraNegocioException(e.getMessage());
        }
    }

    public static BigDecimal valorCobrado(Pedido pedido, MetodoPagamento metodo, int parcelas) {
        double total = pedido.getTotal().doubleValue();
        double valorProdutos = pedido.getValorProdutos().doubleValue();
        try {
            return switch (metodo) {
                case PIX -> emReais(Dinheiro.arredondar(total - PagamentoCalculo.descontoPix(valorProdutos)));
                case CARTAO -> emReais(PagamentoCalculo.valorNoCartao(total, parcelas));
                case BOLETO -> emReais(total);
            };
        } catch (IllegalArgumentException e) {
            throw new RegraNegocioException(e.getMessage());
        }
    }

    public static int pontosGanhos(BigDecimal valorCobrado) {
        return Fidelidade.calcularPontosGanhos(valorCobrado.doubleValue());
    }

    public static LocalDate vencimentoBoleto() {
        return PagamentoCalculo.vencimentoBoleto(Relogio.hoje());
    }

    private static CupomCalculo paraCalculo(Cupom cupom) {
        CupomCalculo cupomCalculo = new CupomCalculo(cupom.getCodigo(),
                cupom.getPercentualDesconto().doubleValue(), cupom.getValorMinimo().doubleValue(),
                cupom.getValidade(), cupom.getUsosMaximos(), cupom.isSomentePrimeiraCompra());
        for (int i = 0; i < cupom.getUsosRealizados(); i++) {
            cupomCalculo.consumirUso();
        }
        if (!cupom.isAtivo()) {
            cupomCalculo.desativar();
        }
        return cupomCalculo;
    }

    private static void guardarResultado(CalculoPedido calculo, Pedido pedido) {
        pedido.setSubtotalBruto(emReais(calculo.getSubtotalBruto()));
        pedido.setDescontoVolume(emReais(calculo.getDescontoVolume()));
        pedido.setBase(emReais(calculo.getBase()));
        pedido.setDescontoComercial(emReais(calculo.getDescontoComercial()));
        pedido.setPontosUsados(calculo.getPontosResgatados());
        pedido.setValorPontos(emReais(calculo.getValorPontosResgatados()));
        pedido.setValorProdutos(emReais(calculo.getValorProdutos()));
        pedido.setFrete(emReais(calculo.getFrete()));
        pedido.setTotal(emReais(calculo.getTotal()));
        pedido.setValorCobrado(emReais(calculo.getValorCobrado()));
        for (int i = 0; i < pedido.getItens().size(); i++) {
            ItemPedido item = pedido.getItens().get(i);
            ItemPedidoCalculo resultado = calculo.getItens().get(i);
            item.setDescontoVolume(emReais(resultado.getDescontoVolume()));
            item.setValorLiquido(emReais(resultado.getValorLiquido()));
            item.setComissao(emReais(resultado.getComissao()));
        }
        if (!calculo.getOrigemDesconto().equals("CUPOM")) {
            pedido.setCupom(null);
        }
    }

    private static BigDecimal emReais(double valor) {
        return BigDecimal.valueOf(valor).setScale(2, RoundingMode.HALF_UP);
    }
}
