package servico;

import ecommerce.CupomCalculo;
import modelo.Cupom;
import repositorio.CupomRepositorio;
import util.RegraNegocioException;
import util.Validacao;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;

/**
 * Cadastro de cupons no banco (só a loja). As regras do cupom (código, desconto acima de 0% e até 50%,
 * valor mínimo, validade, usos) são as da Pessoa B: aqui a CupomCalculo só valida e o Cupom é gravado.
 */
public class CupomServico {
    private final CupomRepositorio repo = new CupomRepositorio();

    public Cupom cadastrar(Usuario ator, String codigo, BigDecimal percentual, BigDecimal valorMinimo,
                           LocalDate validade, int usosMaximos, boolean somentePrimeiraCompra) {
        Permissao.exigirLoja(ator);
        Validacao.exigir(percentual != null && valorMinimo != null, "Informe o desconto e o valor mínimo.");
        CupomCalculo regra;
        try {
            regra = new CupomCalculo(codigo, percentual.doubleValue(), valorMinimo.doubleValue(),
                    validade, usosMaximos, somentePrimeiraCompra);
        } catch (IllegalArgumentException e) {
            throw new RegraNegocioException(e.getMessage());
        }
        Validacao.exigir(repo.buscarPorCodigo(regra.getCodigo()).isEmpty(), "Cupom já cadastrado.");
        return repo.salvar(new Cupom(regra.getCodigo(), percentual.setScale(2, RoundingMode.HALF_UP),
                valorMinimo.setScale(2, RoundingMode.HALF_UP), validade, usosMaximos, somentePrimeiraCompra));
    }

    public List<Cupom> listar(Usuario ator) {
        Permissao.exigirLoja(ator);
        return repo.listarTodos();
    }
}
