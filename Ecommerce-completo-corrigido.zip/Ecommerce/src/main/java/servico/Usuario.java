package servico;

import modelo.Papel;

public record Usuario(Papel papel, Long id) {
    public static Usuario loja() { return new Usuario(Papel.LOJA, null); }
    public static Usuario cliente(Long id) { return new Usuario(Papel.CLIENTE, id); }
    public static Usuario vendedor(Long id) { return new Usuario(Papel.VENDEDOR, id); }
}