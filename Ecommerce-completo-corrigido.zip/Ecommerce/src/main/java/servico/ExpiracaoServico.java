package servico;

import ecommerce.Configuracao;
import modelo.MetodoPagamento;
import modelo.Pagamento;
import modelo.Pedido;
import modelo.StatusPedido;
import repositorio.PedidoRepositorio;
import util.Jpa;
import util.RegraNegocioException;
import util.Relogio;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Expiração de pedidos (§7).
 *
 * - Pedido finalizado sem pagamento expira 24h depois.
 * - Boleto pendente expira quando a data de hoje passa do vencimento (no dia ainda vale).
 * - Tentar pagar ou confirmar um pedido vencido cancela o pedido e avisa o cliente.
 * - Uma rotina geral cancela todos os vencidos de uma vez.
 *
 * Use pagar() e compensarBoleto() desta classe no lugar dos de PagamentoServico: aqueles
 * só recusam o pedido vencido, e recusar lança erro e desfaz a transação, então o
 * cancelamento não ficaria gravado.
 */
public class ExpiracaoServico {
    public static final String AVISO_CANCELADO = "Pedido vencido: o prazo para pagar acabou. "
            + "O pedido foi cancelado e o estoque, o cupom e os pontos foram devolvidos.";

    private final PagamentoServico pagamentos = new PagamentoServico();
    private final PedidoRepositorio pedidos = new PedidoRepositorio();

    /** Mesma regra de PagamentoServico.vencido(), com o "agora" recebido de fora para facilitar os testes. */
    public static boolean vencido(Pedido pedido, LocalDateTime agora) {
        if (pedido.getStatus() != StatusPedido.AGUARDANDO_PAGAMENTO) {
            return false;
        }
        Pagamento pagamento = pedido.getPagamento();
        if (pagamento != null && pagamento.getMetodo() == MetodoPagamento.BOLETO
                && pagamento.getVencimento() != null) {
            return agora.toLocalDate().isAfter(pagamento.getVencimento());
        }
        if (pedido.getDataFinalizacao() == null) {
            return false;
        }
        return agora.isAfter(pedido.getDataFinalizacao().plusHours(Configuracao.HORAS_PARA_EXPIRAR_PEDIDO));
    }

    /** Paga o pedido; se ele já venceu, cancela e avisa o cliente com um erro. */
    public Pedido pagar(Usuario ator, Long pedidoId, MetodoPagamento metodo, int parcelas) {
        cancelarSeVencidoAoTentar(ator, pedidoId, false);
        return pagamentos.pagar(ator, pedidoId, metodo, parcelas);
    }

    /** Compensa o boleto (só a loja); se o pedido já venceu, cancela e avisa com um erro. */
    public Pedido compensarBoleto(Usuario ator, Long pedidoId) {
        Permissao.exigirLoja(ator);
        cancelarSeVencidoAoTentar(ator, pedidoId, true);
        return pagamentos.compensarBoleto(ator, pedidoId);
    }

    /** Cancela o pedido se ele estiver vencido. Devolve true se cancelou. */
    public boolean cancelarSeVencido(Long pedidoId) {
        return Jpa.transacao(em -> {
            Pedido pedido = PedidoLock.travar(em, pedidoId);
            return cancelarNaTransacao(em, pedido);
        });
    }

    /**
     * Rotina geral: cancela todos os pedidos vencidos de uma vez (só a loja).
     * Cada pedido tem a sua própria transação, então um problema num pedido não trava os outros.
     * Devolve os ids dos pedidos cancelados.
     */
    public List<Long> cancelarVencidos(Usuario ator) {
        Permissao.exigirLoja(ator);
        List<Long> cancelados = new ArrayList<>();
        for (Long id : pedidos.idsPorStatus(StatusPedido.AGUARDANDO_PAGAMENTO)) {
            if (cancelarSeVencido(id)) {
                cancelados.add(id);
            }
        }
        return cancelados;
    }

    private void cancelarSeVencidoAoTentar(Usuario ator, Long pedidoId, boolean confirmacaoDaLoja) {
        boolean cancelou = Jpa.transacao(em -> {
            Pedido pedido = PedidoLock.travar(em, pedidoId);
            if (!confirmacaoDaLoja) {
                Permissao.exigirProprioOuLoja(ator, pedido.getCliente().getId());
            }
            return cancelarNaTransacao(em, pedido);
        });
        if (cancelou) {
            // a transação acima já foi gravada; o erro só serve para avisar quem tentou
            throw new RegraNegocioException(AVISO_CANCELADO);
        }
    }

    private boolean cancelarNaTransacao(jakarta.persistence.EntityManager em, Pedido pedido) {
        if (!vencido(pedido, Relogio.agora())) {
            return false;
        }
        CancelamentoServico.aplicar(em, pedido);
        return true;
    }
}
