package servico;

import modelo.Pedido;
import modelo.StatusPedido;
import repositorio.PedidoRepositorio;
import util.Jpa;
import util.RegraNegocioException;
import util.Validacao;
import java.util.List;

/**
 * Consulta de pedidos conforme o papel: o cliente vê os seus (inclusive o carrinho), o vendedor vê
 * os pedidos que têm item dele e a loja vê todos. Vendedor e loja não veem carrinhos (ainda não são pedidos).
 */
public class PedidoConsulta {
    private final PedidoRepositorio repo = new PedidoRepositorio();

    public List<Pedido> listar(Usuario u) {
        if (u == null) {
            throw new RegraNegocioException("Usuário não identificado.");
        }
        return switch (u.papel()) {
            case CLIENTE -> repo.listarPorCliente(u.id());
            case VENDEDOR -> repo.listarPorVendedor(u.id());
            case LOJA -> repo.listarTodosSemCarrinho();
        };
    }

    public Pedido buscar(Usuario u, Long pedidoId) {
        return Jpa.consultar(em -> {
            Pedido pedido = em.find(Pedido.class, pedidoId);
            Validacao.exigir(pedido != null, "Pedido não encontrado.");
            Permissao.exigirVerPedido(u, pedido);
            if (pedido.getStatus() == StatusPedido.CARRINHO && u.papel() != modelo.Papel.CLIENTE) {
                throw new RegraNegocioException("Sem permissão para esta operação.");
            }
            return pedido;
        });
    }
}
