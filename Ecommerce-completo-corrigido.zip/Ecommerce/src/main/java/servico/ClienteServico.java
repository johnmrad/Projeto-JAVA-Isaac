package servico;

import modelo.Cliente;
import repositorio.ClienteRepositorio;
import util.RegraNegocioException;
import util.ValidadorCpf;
import util.Validacao;
import java.util.Set;

public class ClienteServico {
    private static final Set<String> UFS = Set.of(
        "AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG","PA",
        "PB","PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO");

    private final ClienteRepositorio repo = new ClienteRepositorio();

    public Cliente cadastrar(String nome, String email, String cpf, String cidade, String uf, String endereco) {
        validar(nome, email, cpf, cidade, uf, endereco);
        String cpfLimpo = ValidadorCpf.limpar(cpf);
        Validacao.exigir(repo.buscarPorCpf(cpfLimpo).isEmpty(), "CPF já cadastrado.");
        Validacao.exigir(repo.buscarPorEmail(email.trim()).isEmpty(), "E-mail já cadastrado.");
        return repo.salvar(new Cliente(nome.trim(), email.trim(), cpfLimpo,
                cidade.trim(), uf.trim().toUpperCase(), endereco.trim()));
    }

    public Cliente atualizar(Usuario ator, Long id, String nome, String email, String cpf,
                             String cidade, String uf, String endereco) {
        Permissao.exigirProprioOuLoja(ator, id);
        Cliente c = obter(id);
        validar(nome, email, cpf, cidade, uf, endereco);
        String cpfLimpo = ValidadorCpf.limpar(cpf);
        repo.buscarPorCpf(cpfLimpo).ifPresent(o -> Validacao.exigir(o.getId().equals(id), "CPF já cadastrado."));
        repo.buscarPorEmail(email.trim()).ifPresent(o -> Validacao.exigir(o.getId().equals(id), "E-mail já cadastrado."));
        c.setNome(nome.trim());
        c.setEmail(email.trim());
        c.setCpf(cpfLimpo);
        c.setCidade(cidade.trim());
        c.setUf(uf.trim().toUpperCase());
        c.setEndereco(endereco.trim());
        return repo.salvar(c);
    }

    public void desativar(Usuario ator, Long id) {
        Permissao.exigirProprioOuLoja(ator, id);
        Cliente c = obter(id);
        Validacao.exigir(!repo.temPedidoEmAndamento(id),
                "Cliente com pedido em andamento não pode ser desativado.");
        c.setAtivo(false);
        repo.salvar(c);
    }

    public Cliente buscar(Usuario ator, Long id) {
        Permissao.exigirProprioOuLoja(ator, id);
        return obter(id);
    }

    public Usuario entrar(String email) {
        Cliente c = repo.buscarPorEmail(email == null ? "" : email.trim())
                .orElseThrow(() -> new RegraNegocioException("Cliente não encontrado."));
        Validacao.exigir(c.isAtivo(), "Cliente desativado não entra no sistema.");
        return Usuario.cliente(c.getId());
    }

    private Cliente obter(Long id) {
        return repo.buscarPorId(id).orElseThrow(() -> new RegraNegocioException("Cliente não encontrado."));
    }

    private void validar(String nome, String email, String cpf, String cidade, String uf, String endereco) {
        Validacao.exigir(!Validacao.vazio(nome), "Nome é obrigatório.");
        Validacao.exigir(!Validacao.vazio(email) && email.contains("@"), "E-mail inválido.");
        Validacao.exigir(ValidadorCpf.valido(cpf), "CPF inválido.");
        Validacao.exigir(!Validacao.vazio(cidade), "Cidade é obrigatória.");
        Validacao.exigir(uf != null && UFS.contains(uf.trim().toUpperCase()), "UF inválida.");
        Validacao.exigir(!Validacao.vazio(endereco), "Endereço é obrigatório.");
    }
}