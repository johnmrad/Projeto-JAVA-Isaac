package servico;

import modelo.Vendedor;
import repositorio.VendedorRepositorio;
import util.RegraNegocioException;
import util.Validacao;
import java.math.BigDecimal;

public class VendedorServico {
    private final VendedorRepositorio repo = new VendedorRepositorio();

    public Vendedor cadastrar(Usuario ator, String nome, String email, BigDecimal comissao) {
        Permissao.exigirLoja(ator);
        Validacao.exigir(!Validacao.vazio(nome), "Nome é obrigatório.");
        Validacao.exigir(!Validacao.vazio(email) && email.contains("@"), "E-mail inválido.");
        Validacao.exigir(comissao != null && comissao.signum() >= 0
                && comissao.compareTo(new BigDecimal("30")) <= 0,
                "Comissão deve ficar entre 0 e 30%.");
        Validacao.exigir(repo.buscarPorEmail(email.trim()).isEmpty(), "E-mail já cadastrado.");
        return repo.salvar(new Vendedor(nome.trim(), email.trim(), comissao));
    }

    public Usuario entrar(String email) {
        Vendedor v = repo.buscarPorEmail(email == null ? "" : email.trim())
                .orElseThrow(() -> new RegraNegocioException("Vendedor não encontrado."));
        return Usuario.vendedor(v.getId());
    }
}