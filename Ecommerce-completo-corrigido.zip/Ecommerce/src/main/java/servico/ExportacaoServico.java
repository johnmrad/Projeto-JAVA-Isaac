package servico;

import modelo.Pagamento;
import modelo.Pedido;
import modelo.StatusPagamento;
import repositorio.ItemVendidoRepositorio;
import util.Jpa;
import util.Validacao;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Exportações (§13): CSV de vendas do mês (área do vendedor) e XML da nota fiscal simulada.
 */
public class ExportacaoServico {
    private final ItemVendidoRepositorio itens = new ItemVendidoRepositorio();

    /**
     * CSV das vendas do mês. O vendedor recebe só os itens dele; a loja recebe tudo ou filtra um
     * vendedor. A soma da coluna "Valor líquido" é o total do mês de RelatorioServico.
     */
    public byte[] csvVendasDoMes(Usuario u, int ano, int mes, Long vendedorId) {
        Long escopo = EscopoRelatorio.de(u, vendedorId);
        EscopoRelatorio.validarMes(mes);
        return CsvVendas.gerar(itens.itensDoMes(ano, mes, escopo));
    }

    public Path salvarCsvVendasDoMes(Usuario u, int ano, int mes, Long vendedorId, Path pasta) {
        byte[] csv = csvVendasDoMes(u, ano, mes, vendedorId);
        Long escopo = EscopoRelatorio.de(u, vendedorId);
        String nome = String.format("vendas-%04d-%02d%s.csv", ano, mes, escopo == null ? "" : "-vendedor-" + escopo);
        return gravar(pasta.resolve(nome), csv);
    }

    /** XML da nota, só para pedido com pagamento confirmado. Quem pode ver o pedido pode pedir a nota. */
    public String xmlNotaFiscal(Usuario u, Long pedidoId) {
        return Jpa.consultar(em -> {
            Pedido pedido = em.find(Pedido.class, pedidoId);
            Validacao.exigir(pedido != null, "Pedido não encontrado.");
            Permissao.exigirVerPedido(u, pedido);
            Pagamento pagamento = pedido.getPagamento();
            Validacao.exigir(pedido.getStatus().contaComoVenda() && pagamento != null
                            && pagamento.getStatus() == StatusPagamento.APROVADO,
                    "A nota fiscal só é emitida para pedido com pagamento confirmado.");
            return NotaFiscalXml.gerar(pedido);
        });
    }

    public Path salvarXmlNotaFiscal(Usuario u, Long pedidoId, Path pasta) {
        String xml = xmlNotaFiscal(u, pedidoId);
        return gravar(pasta.resolve("nota-fiscal-" + pedidoId + ".xml"), xml.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    private Path gravar(Path arquivo, byte[] conteudo) {
        try {
            Files.createDirectories(arquivo.getParent());
            return Files.write(arquivo, conteudo);
        } catch (IOException e) {
            throw new UncheckedIOException("Não foi possível gravar " + arquivo, e);
        }
    }
}
