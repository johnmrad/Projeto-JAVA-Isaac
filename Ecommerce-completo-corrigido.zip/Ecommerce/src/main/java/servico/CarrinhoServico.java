package servico;

import ecommerce.Configuracao;
import jakarta.persistence.EntityManager;
import jakarta.persistence.LockModeType;
import modelo.Cliente;
import modelo.Cupom;
import modelo.ItemPedido;
import modelo.Papel;
import modelo.Pedido;
import modelo.Produto;
import modelo.StatusPedido;
import util.Jpa;
import util.RegraNegocioException;
import util.Relogio;
import util.Validacao;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class CarrinhoServico {

    public Pedido abrir(Usuario cliente) {
        return Jpa.transacao(em -> carrinhoDo(em, cliente));
    }

    public Pedido definirQuantidade(Usuario cliente, Long produtoId, int quantidade) {
        Validacao.exigir(quantidade >= 0, "A quantidade não pode ser negativa.");
        return Jpa.transacao(em -> {
            Pedido carrinho = carrinhoDo(em, cliente);
            Optional<ItemPedido> item = itemDoProduto(carrinho, produtoId);
            if (quantidade == 0) {
                item.ifPresent(carrinho.getItens()::remove);
            } else if (item.isPresent()) {
                exigirDisponivel(item.get().getProduto(), quantidade);
                item.get().setQuantidade(quantidade);
            } else {
                Produto produto = Optional.ofNullable(em.find(Produto.class, produtoId))
                        .orElseThrow(() -> new RegraNegocioException("Produto não encontrado."));
                exigirDisponivel(produto, quantidade);
                carrinho.adicionarItem(new ItemPedido(produto, quantidade, produto.getPreco()));
            }
            CalculadoraDoPedido.recalcular(carrinho);
            return carrinho;
        });
    }

    public Pedido aplicarCupom(Usuario cliente, String codigo) {
        Validacao.exigir(!Validacao.vazio(codigo), "Informe o código do cupom.");
        return Jpa.transacao(em -> {
            Pedido carrinho = carrinhoDo(em, cliente);
            Validacao.exigir(!carrinho.getItens().isEmpty(), "Coloque produtos no carrinho antes de usar o cupom.");
            Cupom cupom = em.createQuery("from Cupom where upper(codigo) = upper(:codigo)", Cupom.class)
                    .setParameter("codigo", codigo.trim())
                    .getResultStream().findFirst()
                    .orElseThrow(() -> new RegraNegocioException("Cupom não encontrado."));
            CalculadoraDoPedido.validarCupom(cupom, carrinho);
            carrinho.setCupom(cupom);
            CalculadoraDoPedido.recalcular(carrinho);
            Validacao.exigir(carrinho.getCupom() != null, "Seu desconto de fidelidade já é maior que o do cupom.");
            return carrinho;
        });
    }

    public Pedido usarPontos(Usuario cliente, int pontos) {
        Validacao.exigir(pontos >= 0, "A quantidade de pontos não pode ser negativa.");
        return Jpa.transacao(em -> {
            Pedido carrinho = carrinhoDo(em, cliente);
            carrinho.setPontosUsados(pontos);
            CalculadoraDoPedido.recalcular(carrinho);
            return carrinho;
        });
    }

    public Pedido finalizar(Usuario cliente) {
        return Jpa.transacao(em -> {
            Pedido pedido = carrinhoDo(em, cliente);
            Validacao.exigir(!pedido.getItens().isEmpty(), "O carrinho está vazio.");

            List<ItemPedido> itensPorProduto = pedido.getItens().stream()
                    .sorted(Comparator.comparing(item -> item.getProduto().getId()))
                    .toList();
            for (ItemPedido item : itensPorProduto) {
                Produto produto = item.getProduto();
                em.refresh(produto, LockModeType.PESSIMISTIC_WRITE);
                exigirDisponivel(produto, item.getQuantidade());
                item.setPrecoUnitario(produto.getPreco());
            }
            if (pedido.getCupom() != null) {
                em.refresh(pedido.getCupom(), LockModeType.PESSIMISTIC_WRITE);
            }
            CalculadoraDoPedido.recalcular(pedido);

            for (ItemPedido item : pedido.getItens()) {
                Produto produto = item.getProduto();
                produto.setEstoque(produto.getEstoque() - item.getQuantidade());
            }
            if (pedido.getCupom() != null) {
                Cupom cupom = pedido.getCupom();
                cupom.setUsosRealizados(cupom.getUsosRealizados() + 1);
            }
            Cliente dono = pedido.getCliente();
            dono.setPontos(dono.getPontos() - pedido.getPontosUsados());

            FluxoPedido.mudar(pedido, StatusPedido.AGUARDANDO_PAGAMENTO);
            pedido.setDataFinalizacao(Relogio.agora());
            return pedido;
        });
    }

    private Pedido carrinhoDo(EntityManager em, Usuario cliente) {
        Validacao.exigir(cliente != null && cliente.papel() == Papel.CLIENTE, "Só clientes podem comprar.");
        Cliente dono = Optional.ofNullable(em.find(Cliente.class, cliente.id(), LockModeType.PESSIMISTIC_WRITE))
                .orElseThrow(() -> new RegraNegocioException("Cliente não encontrado."));
        Validacao.exigir(dono.isAtivo(), "Cliente desativado não pode comprar.");

        List<Pedido> abertos = em.createQuery(
                "from Pedido where cliente.id = :id and status = :status", Pedido.class)
                .setParameter("id", dono.getId())
                .setParameter("status", StatusPedido.CARRINHO)
                .getResultList();
        if (!abertos.isEmpty()) {
            return abertos.get(0);
        }
        Pedido novo = new Pedido(dono, Relogio.agora());
        em.persist(novo);
        return novo;
    }

    private Optional<ItemPedido> itemDoProduto(Pedido carrinho, Long produtoId) {
        return carrinho.getItens().stream()
                .filter(item -> item.getProduto().getId().equals(produtoId))
                .findFirst();
    }

    private void exigirDisponivel(Produto produto, int quantidade) {
        Validacao.exigir(produto.isAtivo(), produto.getNome() + " está inativo.");
        Validacao.exigir(produto.getEstoque() > 0, produto.getNome() + " está sem estoque.");
        Validacao.exigir(quantidade <= Configuracao.MAXIMO_UNIDADES_POR_PRODUTO,
                "Máximo de " + Configuracao.MAXIMO_UNIDADES_POR_PRODUTO + " unidades por produto.");
        Validacao.exigir(quantidade <= produto.getEstoque(),
                "Estoque insuficiente de " + produto.getNome() + ": só há " + produto.getEstoque() + ".");
    }
}
