package servico;

import modelo.Venda;
import modelo.VendaProduto;
import repositorio.VendaRepositorio;
import util.Validacao;
import java.util.List;

public class VendaConsulta {
    private final VendaRepositorio repo = new VendaRepositorio();

    public List<Venda> vendas(int ano, int mes, Long vendedorId) {
        validarMes(mes);
        return repo.vendasDoMes(ano, mes, vendedorId);
    }

    public List<VendaProduto> produtosVendidos(int ano, int mes, Long vendedorId) {
        validarMes(mes);
        return repo.rankingProdutos(ano, mes, vendedorId);
    }

    private void validarMes(int mes) {
        Validacao.exigir(mes >= 1 && mes <= 12, "Mês inválido.");
    }
}