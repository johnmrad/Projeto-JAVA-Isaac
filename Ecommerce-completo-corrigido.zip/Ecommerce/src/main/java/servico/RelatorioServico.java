package servico;

import modelo.RankingCliente;
import modelo.Venda;
import modelo.VendaProduto;
import util.RegraNegocioException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class RelatorioServico {
    private static final BigDecimal ZERO = BigDecimal.ZERO.setScale(2);
    private final VendaConsulta consulta = new VendaConsulta();

    private Long escopo(Usuario u, Long vendedorId) {
        if (u == null) {
            throw new RegraNegocioException("Usuário não identificado.");
        }
        return switch (u.papel()) {
            case LOJA -> vendedorId;
            case VENDEDOR -> u.id();
            default -> throw new RegraNegocioException("Sem permissão para ver relatórios.");
        };
    }

    private List<Venda> vendas(Usuario u, int ano, int mes, Long vendedorId) {
        return consulta.vendas(ano, mes, escopo(u, vendedorId));
    }

    private static BigDecimal somar(List<Venda> vendas) {
        return vendas.stream().map(Venda::valor)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_UP);
    }

    public BigDecimal totalDoMes(Usuario u, int ano, int mes, Long vendedorId) {
        return somar(vendas(u, ano, mes, vendedorId));
    }

    public BigDecimal ticketMedio(Usuario u, int ano, int mes, Long vendedorId) {
        List<Venda> v = vendas(u, ano, mes, vendedorId);
        if (v.isEmpty()) {
            return ZERO;
        }
        return somar(v).divide(BigDecimal.valueOf(v.size()), 2, RoundingMode.HALF_UP);
    }

    public BigDecimal maiorPedido(Usuario u, int ano, int mes, Long vendedorId) {
        return vendas(u, ano, mes, vendedorId).stream()
                .map(Venda::valor).max(Comparator.naturalOrder())
                .orElse(ZERO).setScale(2, RoundingMode.HALF_UP);
    }

    public BigDecimal menorPedido(Usuario u, int ano, int mes, Long vendedorId) {
        return vendas(u, ano, mes, vendedorId).stream()
                .map(Venda::valor).min(Comparator.naturalOrder())
                .orElse(ZERO).setScale(2, RoundingMode.HALF_UP);
    }

    public List<VendaProduto> rankingProdutos(Usuario u, int ano, int mes, Long vendedorId) {
        return consulta.produtosVendidos(ano, mes, escopo(u, vendedorId));
    }

    public List<RankingCliente> rankingClientes(Usuario u, int ano, int mes, Long vendedorId) {
        Map<Long, List<Venda>> porCliente = vendas(u, ano, mes, vendedorId).stream()
                .collect(Collectors.groupingBy(Venda::clienteId));
        return porCliente.values().stream()
                .map(l -> new RankingCliente(l.get(0).clienteId(), l.get(0).clienteNome(), somar(l)))
                .sorted(Comparator.comparing(RankingCliente::total).reversed())
                .toList();
    }
}