package servico;

import modelo.Categoria;
import modelo.Papel;
import modelo.Produto;
import modelo.Vendedor;
import repositorio.CategoriaRepositorio;
import repositorio.ProdutoRepositorio;
import repositorio.VendedorRepositorio;
import util.RegraNegocioException;
import util.Validacao;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public class ProdutoServico {
    public static final int LIMITE_ESTOQUE_BAIXO = 5;

    private final ProdutoRepositorio repo = new ProdutoRepositorio();
    private final CategoriaRepositorio categorias = new CategoriaRepositorio();
    private final VendedorRepositorio vendedores = new VendedorRepositorio();

    public Produto cadastrar(Usuario ator, String nome, String descricao, BigDecimal preco,
                             int estoque, Long categoriaId, Long vendedorId) {
        Permissao.exigirLojaOuVendedor(ator);
        Long donoId = ator.papel() == Papel.VENDEDOR ? ator.id() : vendedorId;
        validar(nome, preco, estoque);
        Validacao.exigir(categoriaId != null, "Informe a categoria.");
        Validacao.exigir(donoId != null, "Informe o vendedor.");
        Categoria cat = categorias.buscarPorId(categoriaId)
                .orElseThrow(() -> new RegraNegocioException("Categoria não encontrada."));
        Vendedor ven = vendedores.buscarPorId(donoId)
                .orElseThrow(() -> new RegraNegocioException("Vendedor não encontrado."));
        return repo.salvar(new Produto(nome.trim(), descricao,
                preco.setScale(2, RoundingMode.HALF_UP), estoque, cat, ven));
    }

    public Produto alterar(Usuario ator, Long id, String nome, String descricao,
                           BigDecimal preco, Long categoriaId) {
        Produto p = obter(id);
        Permissao.exigirProdutoProprio(ator, p);
        validar(nome, preco, p.getEstoque());
        Validacao.exigir(categoriaId != null, "Informe a categoria.");
        Categoria cat = categorias.buscarPorId(categoriaId)
                .orElseThrow(() -> new RegraNegocioException("Categoria não encontrada."));
        p.setNome(nome.trim());
        p.setDescricao(descricao);
        p.setPreco(preco.setScale(2, RoundingMode.HALF_UP));
        p.setCategoria(cat);
        return repo.salvar(p);
    }

    public Produto reporEstoque(Usuario ator, Long id, int quantidade) {
        Validacao.exigir(quantidade > 0, "Quantidade de reposição deve ser maior que zero.");
        Produto p = obter(id);
        Permissao.exigirProdutoProprio(ator, p);
        p.setEstoque(p.getEstoque() + quantidade);
        return repo.salvar(p);
    }

    public void ativar(Usuario ator, Long id) {
        definirAtivo(ator, id, true);
    }

    public void desativar(Usuario ator, Long id) {
        definirAtivo(ator, id, false);
    }

    public void excluir(Usuario ator, Long id) {
        Produto p = obter(id);
        Permissao.exigirProdutoProprio(ator, p);
        Validacao.exigir(!repo.existeEmPedido(id), "Produto já vendido: só pode ser desativado.");
        repo.excluir(id);
    }

    public List<Produto> catalogo() {
        return repo.listarAtivosComEstoque();
    }

    public List<Produto> estoqueBaixo(Usuario ator) {
        Permissao.exigirLojaOuVendedor(ator);
        List<Produto> lista = repo.listarEstoqueBaixo(LIMITE_ESTOQUE_BAIXO);
        if (ator.papel() == Papel.VENDEDOR) {
            return lista.stream().filter(p -> p.getVendedor().getId().equals(ator.id())).toList();
        }
        return lista;
    }

    private void definirAtivo(Usuario ator, Long id, boolean ativo) {
        Produto p = obter(id);
        Permissao.exigirProdutoProprio(ator, p);
        p.setAtivo(ativo);
        repo.salvar(p);
    }

    private Produto obter(Long id) {
        return repo.buscarPorId(id).orElseThrow(() -> new RegraNegocioException("Produto não encontrado."));
    }

    private void validar(String nome, BigDecimal preco, int estoque) {
        Validacao.exigir(!Validacao.vazio(nome), "Nome do produto é obrigatório.");
        Validacao.exigir(preco != null && preco.signum() > 0, "Preço deve ser maior que zero.");
        Validacao.exigir(estoque >= 0, "Estoque não pode ser negativo.");
    }
}