package servico;

import modelo.Categoria;
import repositorio.CategoriaRepositorio;
import util.Validacao;

public class CategoriaServico {
    private final CategoriaRepositorio repo = new CategoriaRepositorio();

    public Categoria cadastrar(Usuario ator, String nome) {
        Permissao.exigirLoja(ator);
        Validacao.exigir(!Validacao.vazio(nome), "Nome da categoria é obrigatório.");
        Validacao.exigir(repo.buscarPorNome(nome.trim()).isEmpty(), "Categoria já cadastrada.");
        return repo.salvar(new Categoria(nome.trim()));
    }
}