package servico;

import modelo.Cliente;
import modelo.ItemPedido;
import modelo.Pagamento;
import modelo.Pedido;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.format.DateTimeFormatter;

/**
 * XML da nota fiscal (§13). É um documento SIMULADO, sem validade fiscal, e o aviso vai no
 * próprio arquivo. Só monta o XML a partir dos valores já gravados no pedido: ExportacaoServico
 * confere se o pagamento foi confirmado.
 */
public class NotaFiscalXml {
    public static final String AVISO = "DOCUMENTO SIMULADO - SEM VALIDADE FISCAL";

    public static String gerar(Pedido pedido) {
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            Element raiz = doc.createElement("notaFiscal");
            raiz.setAttribute("simulada", "true");
            doc.appendChild(raiz);
            filho(doc, raiz, "aviso", AVISO);

            Element identificacao = filho(doc, raiz, "identificacao", null);
            filho(doc, identificacao, "numero", String.valueOf(pedido.getId()));
            filho(doc, identificacao, "dataEmissao",
                    pedido.getDataPagamento().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

            filho(doc, filho(doc, raiz, "emitente", null), "nome", "E-commerce");

            Cliente c = pedido.getCliente();
            Element destinatario = filho(doc, raiz, "destinatario", null);
            filho(doc, destinatario, "nome", c.getNome());
            filho(doc, destinatario, "cpf", c.getCpf());
            filho(doc, destinatario, "email", c.getEmail());
            filho(doc, destinatario, "endereco", c.getEndereco());
            filho(doc, destinatario, "cidade", c.getCidade());
            filho(doc, destinatario, "uf", c.getUf());

            Element itens = filho(doc, raiz, "itens", null);
            int numero = 1;
            for (ItemPedido i : pedido.getItens()) {
                Element item = filho(doc, itens, "item", null);
                item.setAttribute("numero", String.valueOf(numero++));
                filho(doc, item, "produto", i.getProduto().getNome());
                filho(doc, item, "categoria", i.getProduto().getCategoria().getNome());
                filho(doc, item, "vendedor", i.getProduto().getVendedor().getNome());
                filho(doc, item, "quantidade", String.valueOf(i.getQuantidade()));
                filho(doc, item, "valorUnitario", valor(i.getPrecoUnitario()));
                filho(doc, item, "descontoVolume", valor(i.getDescontoVolume()));
                filho(doc, item, "valorLiquido", valor(i.getValorLiquido()));
            }

            Element totais = filho(doc, raiz, "totais", null);
            filho(doc, totais, "subtotalBruto", valor(pedido.getSubtotalBruto()));
            filho(doc, totais, "descontoVolume", valor(pedido.getDescontoVolume()));
            filho(doc, totais, "base", valor(pedido.getBase()));
            filho(doc, totais, "descontoComercial", valor(pedido.getDescontoComercial()));
            filho(doc, totais, "pontosResgatados", valor(pedido.getValorPontos()));
            filho(doc, totais, "valorProdutos", valor(pedido.getValorProdutos()));
            filho(doc, totais, "frete", valor(pedido.getFrete()));
            filho(doc, totais, "total", valor(pedido.getTotal()));
            filho(doc, totais, "valorCobrado", valor(pedido.getValorCobrado()));

            Pagamento p = pedido.getPagamento();
            Element pagamento = filho(doc, raiz, "pagamento", null);
            filho(doc, pagamento, "forma", p.getMetodo().name());
            filho(doc, pagamento, "parcelas", String.valueOf(p.getParcelas()));
            filho(doc, pagamento, "ajuste", valor(p.getAjuste()));
            filho(doc, pagamento, "status", p.getStatus().name());

            if (pedido.getCodigoRastreio() != null) {
                filho(doc, raiz, "codigoRastreio", pedido.getCodigoRastreio());
            }
            return paraTexto(doc);
        } catch (Exception e) {
            throw new IllegalStateException("Não foi possível gerar o XML da nota.", e);
        }
    }

    private static Element filho(Document doc, Element pai, String nome, String texto) {
        Element e = doc.createElement(nome);
        if (texto != null) {
            e.setTextContent(texto);
        }
        pai.appendChild(e);
        return e;
    }

    /** Valor com ponto decimal e 2 casas, como é padrão em XML. */
    private static String valor(BigDecimal v) {
        return (v == null ? BigDecimal.ZERO : v).setScale(2, RoundingMode.HALF_UP).toPlainString();
    }

    private static String paraTexto(Document doc) throws Exception {
        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        t.setOutputProperty(OutputKeys.INDENT, "yes");
        t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        StringWriter saida = new StringWriter();
        t.transform(new DOMSource(doc), new StreamResult(saida));
        return saida.toString();
    }
}
