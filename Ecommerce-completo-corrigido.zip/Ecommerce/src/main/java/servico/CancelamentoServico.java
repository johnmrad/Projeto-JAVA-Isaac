package servico;

import jakarta.persistence.EntityManager;
import jakarta.persistence.LockModeType;
import modelo.Cliente;
import modelo.Cupom;
import modelo.ItemPedido;
import modelo.Pagamento;
import modelo.Pedido;
import modelo.Produto;
import modelo.StatusPagamento;
import modelo.StatusPedido;
import ecommerce.Fidelidade;
import util.Jpa;
import util.Validacao;
import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;

/**
 * Cancelamento de pedido (§2, §8).
 *
 * Permitido no carrinho, aguardando pagamento, pago e separado. Depois de enviado, recusa.
 * Cliente cancela só os próprios pedidos; a loja cancela qualquer um.
 */
public class CancelamentoServico {

    public Pedido cancelar(Usuario ator, Long pedidoId) {
        return Jpa.transacao(em -> {
            Pedido pedido = PedidoLock.travar(em, pedidoId);
            Permissao.exigirProprioOuLoja(ator, pedido.getCliente().getId());
            aplicar(em, pedido);
            return pedido;
        });
    }

    /**
     * Cancela o pedido dentro da transação de quem chamou (também usado pela expiração).
     * Não confere permissão: quem chama é responsável por isso.
     */
    static void aplicar(EntityManager em, Pedido pedido) {
        StatusPedido atual = pedido.getStatus();
        Validacao.exigir(atual != StatusPedido.ENVIADO && atual != StatusPedido.ENTREGUE,
                "Pedido já enviado não pode ser cancelado.");
        Validacao.exigir(atual != StatusPedido.CANCELADO, "Este pedido já está cancelado.");

        if (atual != StatusPedido.CARRINHO) {
            // no carrinho nada foi baixado; daqui em diante o estoque, o cupom e os pontos já saíram
            devolverEstoque(em, pedido);
            devolverUsoDoCupom(em, pedido);
            Cliente cliente = pedido.getCliente();
            cliente.setPontos(cliente.getPontos() + pedido.getPontosUsados());
            if (atual == StatusPedido.PAGO || atual == StatusPedido.SEPARADO) {
                estornar(pedido);
            }
        }
        FluxoPedido.mudar(pedido, StatusPedido.CANCELADO);
    }

    private static void devolverEstoque(EntityManager em, Pedido pedido) {
        // mesma ordem de CarrinhoServico.finalizar (por id do produto) para não gerar deadlock
        List<ItemPedido> itens = pedido.getItens().stream()
                .sorted(Comparator.comparing(item -> item.getProduto().getId()))
                .toList();
        for (ItemPedido item : itens) {
            Produto produto = item.getProduto();
            em.refresh(produto, LockModeType.PESSIMISTIC_WRITE);
            produto.setEstoque(produto.getEstoque() + item.getQuantidade());
        }
    }

    private static void devolverUsoDoCupom(EntityManager em, Pedido pedido) {
        Cupom cupom = pedido.getCupom();
        if (cupom != null) {
            em.refresh(cupom, LockModeType.PESSIMISTIC_WRITE);
            cupom.setUsosRealizados(Math.max(0, cupom.getUsosRealizados() - 1));
        }
    }

    /** Pedido já pago: desfaz o que PagamentoServico.confirmar() fez. O nível se recalcula sozinho. */
    private static void estornar(Pedido pedido) {
        Pagamento pagamento = pedido.getPagamento();
        if (pagamento != null) {
            pagamento.setStatus(StatusPagamento.ESTORNADO);
        }
        Cliente cliente = pedido.getCliente();
        BigDecimal gasto = cliente.getTotalGasto().subtract(pedido.getValorCobrado());
        cliente.setTotalGasto(gasto.signum() < 0 ? BigDecimal.ZERO : gasto);
        cliente.setComprasPagas(Math.max(0, cliente.getComprasPagas() - 1));
        int pontosGanhos = CalculadoraDoPedido.pontosGanhos(pedido.getValorCobrado());
        cliente.setPontos(Fidelidade.retirarPontos(cliente.getPontos(), pontosGanhos));
    }
}
