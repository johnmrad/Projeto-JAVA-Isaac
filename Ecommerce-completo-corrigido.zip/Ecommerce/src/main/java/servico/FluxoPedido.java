package servico;

import modelo.Pedido;
import modelo.StatusPedido;
import util.Validacao;
import java.util.Map;
import java.util.Set;

public class FluxoPedido {
    private static final Map<StatusPedido, Set<StatusPedido>> PROXIMOS = Map.of(
        StatusPedido.CARRINHO, Set.of(StatusPedido.AGUARDANDO_PAGAMENTO, StatusPedido.CANCELADO),
        StatusPedido.AGUARDANDO_PAGAMENTO, Set.of(StatusPedido.PAGO, StatusPedido.CANCELADO),
        StatusPedido.PAGO, Set.of(StatusPedido.SEPARADO, StatusPedido.CANCELADO),
        StatusPedido.SEPARADO, Set.of(StatusPedido.ENVIADO, StatusPedido.CANCELADO),
        StatusPedido.ENVIADO, Set.of(StatusPedido.ENTREGUE),
        StatusPedido.ENTREGUE, Set.of(),
        StatusPedido.CANCELADO, Set.of());

    public static boolean podeMudar(StatusPedido atual, StatusPedido novo) {
        return PROXIMOS.get(atual).contains(novo);
    }

    public static void mudar(Pedido pedido, StatusPedido novo) {
        Validacao.exigir(podeMudar(pedido.getStatus(), novo),
                "O pedido não pode passar de " + pedido.getStatus() + " para " + novo + ".");
        pedido.setStatus(novo);
    }
}
