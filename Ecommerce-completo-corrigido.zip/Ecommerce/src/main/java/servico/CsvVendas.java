package servico;

import modelo.ItemVendido;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * CSV de vendas do mês (§13): uma linha por item vendido, 13 colunas, separador ";",
 * decimal com vírgula, UTF-8 com BOM (para o Excel abrir os acentos certos) e prefixo '
 * em texto que começa com = + - @ (para o Excel não executar como fórmula).
 *
 * Só formata: quem busca os itens é ExportacaoServico.
 */
public class CsvVendas {
    public static final String SEPARADOR = ";";
    private static final String FIM_DE_LINHA = "\r\n";
    private static final byte[] BOM = {(byte) 0xEF, (byte) 0xBB, (byte) 0xBF};
    private static final DateTimeFormatter DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    public static final List<String> CABECALHO = List.of(
            "Pedido", "Data do pagamento", "Cliente", "Vendedor", "Produto", "Categoria",
            "Quantidade", "Preço unitário", "Desconto por volume", "Valor líquido", "Comissão",
            "Forma de pagamento", "Status do pedido");

    public static byte[] gerar(List<ItemVendido> itens) {
        StringBuilder csv = new StringBuilder();
        csv.append(String.join(SEPARADOR, CABECALHO.stream().map(CsvVendas::texto).toList())).append(FIM_DE_LINHA);
        for (ItemVendido i : itens) {
            csv.append(String.join(SEPARADOR, List.of(
                    String.valueOf(i.pedidoId()),
                    i.dataPagamento() == null ? "" : i.dataPagamento().format(DATA),
                    texto(i.clienteNome()),
                    texto(i.vendedorNome()),
                    texto(i.produtoNome()),
                    texto(i.categoriaNome()),
                    String.valueOf(i.quantidade()),
                    decimal(i.precoUnitario()),
                    decimal(i.descontoVolume()),
                    decimal(i.valorLiquido()),
                    decimal(i.comissao()),
                    i.metodo() == null ? "" : i.metodo().name(),
                    i.status().name()))).append(FIM_DE_LINHA);
        }
        ByteArrayOutputStream saida = new ByteArrayOutputStream();
        saida.writeBytes(BOM);
        saida.writeBytes(csv.toString().getBytes(StandardCharsets.UTF_8));
        return saida.toByteArray();
    }

    /**
     * Texto seguro para uma célula: neutraliza fórmula (prefixo ') e protege ; " e quebra de linha
     * com aspas. Só vale para texto: números não passam por aqui, então -15,50 continua número.
     */
    public static String texto(String valor) {
        if (valor == null) {
            return "";
        }
        String seguro = valor;
        if (!seguro.isEmpty() && "=+-@\t\r".indexOf(seguro.charAt(0)) >= 0) {
            seguro = "'" + seguro;
        }
        if (seguro.contains(SEPARADOR) || seguro.contains("\"") || seguro.contains("\n") || seguro.contains("\r")) {
            seguro = "\"" + seguro.replace("\"", "\"\"") + "\"";
        }
        return seguro;
    }

    /** 1234.5 vira "1234,50" (2 casas, meio centavo para cima, vírgula, sem separador de milhar). */
    public static String decimal(BigDecimal valor) {
        if (valor == null) {
            return "0,00";
        }
        return valor.setScale(2, RoundingMode.HALF_UP).toPlainString().replace('.', ',');
    }
}
