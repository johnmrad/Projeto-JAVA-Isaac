package servico;

import modelo.ComissaoVendedor;
import modelo.ItemVendido;
import modelo.MetodoPagamento;
import modelo.Venda;
import modelo.VendaCategoria;
import modelo.VendaFormaPagamento;
import repositorio.ItemVendidoRepositorio;
import repositorio.PedidoRepositorio;
import repositorio.VendedorRepositorio;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Indicadores da Pessoa D (§12): comissão a pagar por vendedor, taxa de cancelamento,
 * vendas por categoria e pedidos por forma de pagamento.
 *
 * Os valores são os já gravados no pedido (nada é recalculado) e "venda" é a mesma definição
 * da Pessoa A. A loja vê tudo (ou filtra um vendedor); o vendedor vê só o que é dele.
 */
public class IndicadorServico {
    private static final BigDecimal ZERO = BigDecimal.ZERO.setScale(2);

    private final ItemVendidoRepositorio itens = new ItemVendidoRepositorio();
    private final PedidoRepositorio pedidos = new PedidoRepositorio();
    private final VendedorRepositorio vendedores = new VendedorRepositorio();
    private final VendaConsulta consulta = new VendaConsulta();   // a consulta de vendas da Pessoa A

    /** Soma das comissões gravadas nos itens vendidos no mês. Vendedor sem venda aparece com 0,00. */
    public List<ComissaoVendedor> comissaoAPagar(Usuario u, int ano, int mes, Long vendedorId) {
        Long escopo = EscopoRelatorio.de(u, vendedorId);
        EscopoRelatorio.validarMes(mes);
        Map<Long, BigDecimal> soma = new LinkedHashMap<>();
        for (ItemVendido item : itens.itensDoMes(ano, mes, escopo)) {
            soma.merge(item.vendedorId(), item.comissao(), BigDecimal::add);
        }
        return vendedores.listarTodos().stream()
                .filter(v -> escopo == null || v.getId().equals(escopo))
                .map(v -> new ComissaoVendedor(v.getId(), v.getNome(),
                        soma.getOrDefault(v.getId(), ZERO).setScale(2, RoundingMode.HALF_UP)))
                .sorted(Comparator.comparing(ComissaoVendedor::comissao).reversed()
                        .thenComparing(ComissaoVendedor::vendedorNome))
                .toList();
    }

    /**
     * Pedidos cancelados ÷ pedidos finalizados criados no mês, em %.
     * Carrinho cancelado nunca foi finalizado, então não entra em nenhum dos dois lados.
     * Mês sem pedidos finalizados devolve 0,00.
     */
    public BigDecimal taxaCancelamento(Usuario u, int ano, int mes, Long vendedorId) {
        Long escopo = EscopoRelatorio.de(u, vendedorId);
        EscopoRelatorio.validarMes(mes);
        long finalizados = pedidos.contarFinalizadosCriadosNoMes(ano, mes, escopo, false);
        if (finalizados == 0) {
            return ZERO;
        }
        long cancelados = pedidos.contarFinalizadosCriadosNoMes(ano, mes, escopo, true);
        return BigDecimal.valueOf(cancelados * 100)
                .divide(BigDecimal.valueOf(finalizados), 2, RoundingMode.HALF_UP);
    }

    /** Quantidade e valor líquido por categoria, da que mais vendeu em valor para a que menos vendeu. */
    public List<VendaCategoria> vendasPorCategoria(Usuario u, int ano, int mes, Long vendedorId) {
        Long escopo = EscopoRelatorio.de(u, vendedorId);
        EscopoRelatorio.validarMes(mes);
        Map<Long, VendaCategoria> porCategoria = new LinkedHashMap<>();
        for (ItemVendido item : itens.itensDoMes(ano, mes, escopo)) {
            porCategoria.merge(item.categoriaId(),
                    new VendaCategoria(item.categoriaId(), item.categoriaNome(), item.quantidade(), item.valorLiquido()),
                    (a, b) -> new VendaCategoria(a.categoriaId(), a.categoriaNome(),
                            a.quantidade() + b.quantidade(), a.valor().add(b.valor())));
        }
        return porCategoria.values().stream()
                .map(c -> new VendaCategoria(c.categoriaId(), c.categoriaNome(), c.quantidade(),
                        c.valor().setScale(2, RoundingMode.HALF_UP)))
                .sorted(Comparator.comparing(VendaCategoria::valor).reversed()
                        .thenComparing(VendaCategoria::categoriaNome))
                .toList();
    }

    /**
     * Número de pedidos e valor vendido por forma de pagamento (PIX, cartão e boleto, sempre as
     * três, com zeros quando não houve). O valor é o mesmo do relatório do mês, então a soma bate.
     */
    public List<VendaFormaPagamento> pedidosPorFormaPagamento(Usuario u, int ano, int mes, Long vendedorId) {
        Long escopo = EscopoRelatorio.de(u, vendedorId);
        List<Venda> vendas = consulta.vendas(ano, mes, escopo);
        Map<Long, MetodoPagamento> metodos = pedidos.metodosDosPedidos(
                vendas.stream().map(Venda::pedidoId).toList());

        Map<MetodoPagamento, Long> quantidade = new EnumMap<>(MetodoPagamento.class);
        Map<MetodoPagamento, BigDecimal> valor = new EnumMap<>(MetodoPagamento.class);
        for (Venda venda : vendas) {
            MetodoPagamento metodo = metodos.get(venda.pedidoId());
            if (metodo != null) {
                quantidade.merge(metodo, 1L, Long::sum);
                valor.merge(metodo, venda.valor(), BigDecimal::add);
            }
        }
        return java.util.Arrays.stream(MetodoPagamento.values())
                .map(m -> new VendaFormaPagamento(m, quantidade.getOrDefault(m, 0L),
                        valor.getOrDefault(m, ZERO).setScale(2, RoundingMode.HALF_UP)))
                .toList();
    }
}
