package servico;

import modelo.Papel;
import modelo.Pedido;
import modelo.Produto;
import util.RegraNegocioException;

public class Permissao {

    private static RegraNegocioException negado() {
        return new RegraNegocioException("Sem permissão para esta operação.");
    }

    public static void exigirLoja(Usuario u) {
        if (u == null || u.papel() != Papel.LOJA) {
            throw negado();
        }
    }

    public static void exigirLojaOuVendedor(Usuario u) {
        if (u == null || u.papel() == Papel.CLIENTE) {
            throw negado();
        }
    }

    public static void exigirProprioOuLoja(Usuario u, Long clienteId) {
        boolean ok = u != null && (u.papel() == Papel.LOJA
                || (u.papel() == Papel.CLIENTE && clienteId.equals(u.id())));
        if (!ok) {
            throw negado();
        }
    }

    public static void exigirProdutoProprio(Usuario u, Produto p) {
        boolean ok = u != null && (u.papel() == Papel.LOJA
                || (u.papel() == Papel.VENDEDOR && p.getVendedor().getId().equals(u.id())));
        if (!ok) {
            throw negado();
        }
    }

    public static void exigirVerPedido(Usuario u, Pedido pedido) {
        if (u == null) {
            throw negado();
        }
        switch (u.papel()) {
            case LOJA:
                return;
            case CLIENTE:
                if (pedido.getCliente().getId().equals(u.id())) {
                    return;
                }
                break;
            case VENDEDOR:
                if (pedido.getItens().stream()
                        .anyMatch(i -> i.getProduto().getVendedor().getId().equals(u.id()))) {
                    return;
                }
                break;
        }
        throw negado();
    }
}