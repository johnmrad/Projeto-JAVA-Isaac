package servico;

import modelo.Pedido;
import modelo.StatusPedido;
import util.Jpa;

/**
 * Separar, enviar e entregar (§2).
 * Só o vendedor dono de pelo menos um item do pedido (ou a loja, que pode tudo).
 * Qualquer passo fora da ordem é recusado pela tabela de transições de FluxoPedido.
 */
public class EnvioServico {

    public Pedido separar(Usuario ator, Long pedidoId) {
        return avancar(ator, pedidoId, StatusPedido.SEPARADO);
    }

    /** Ao enviar, gera o código de rastreio. */
    public Pedido enviar(Usuario ator, Long pedidoId) {
        return avancar(ator, pedidoId, StatusPedido.ENVIADO);
    }

    public Pedido entregar(Usuario ator, Long pedidoId) {
        return avancar(ator, pedidoId, StatusPedido.ENTREGUE);
    }

    /** Código no estilo dos Correios (2 letras, 9 dígitos, BR). Único, porque leva o id do pedido. */
    public static String gerarCodigoRastreio(Long pedidoId) {
        return String.format("EC%09dBR", pedidoId);
    }

    private Pedido avancar(Usuario ator, Long pedidoId, StatusPedido novo) {
        return Jpa.transacao(em -> {
            Pedido pedido = PedidoLock.travar(em, pedidoId);
            Permissao.exigirLojaOuVendedor(ator);
            Permissao.exigirVerPedido(ator, pedido);   // vendedor precisa ter item no pedido
            FluxoPedido.mudar(pedido, novo);
            if (novo == StatusPedido.ENVIADO) {
                pedido.setCodigoRastreio(gerarCodigoRastreio(pedido.getId()));
            }
            return pedido;
        });
    }
}
