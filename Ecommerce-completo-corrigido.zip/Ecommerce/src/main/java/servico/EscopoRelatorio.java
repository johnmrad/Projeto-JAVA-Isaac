package servico;

import util.RegraNegocioException;
import util.Validacao;

/** Quem pode ver indicadores e exportações: loja vê tudo (ou um vendedor), vendedor só o próprio. */
final class EscopoRelatorio {
    private EscopoRelatorio() {}

    /** Devolve o id do vendedor para filtrar, ou null para a loja inteira. */
    static Long de(Usuario u, Long vendedorId) {
        if (u == null) {
            throw new RegraNegocioException("Usuário não identificado.");
        }
        return switch (u.papel()) {
            case LOJA -> vendedorId;
            case VENDEDOR -> u.id();
            default -> throw new RegraNegocioException("Sem permissão para ver relatórios.");
        };
    }

    static void validarMes(int mes) {
        Validacao.exigir(mes >= 1 && mes <= 12, "Mês inválido.");
    }
}
