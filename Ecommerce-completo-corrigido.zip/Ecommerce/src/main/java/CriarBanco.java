import util.Jpa;

public class CriarBanco {
    public static void main(String[] args) {
        Jpa.consultar(em -> 1);
        System.out.println("Tabelas criadas.");
    }
}