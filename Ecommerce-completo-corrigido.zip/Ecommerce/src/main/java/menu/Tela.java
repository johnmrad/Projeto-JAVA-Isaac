package menu;

import ecommerce.Dinheiro;
import modelo.ItemPedido;
import modelo.Pagamento;
import modelo.Pedido;
import modelo.Produto;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Como cada coisa aparece na tela. */
final class Tela {
    private static final DateTimeFormatter DATA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private Tela() {}

    static String dinheiro(BigDecimal valor) {
        return Dinheiro.formatar(valor == null ? 0 : valor.doubleValue());
    }

    static String percentual(BigDecimal valor) {
        return valor.setScale(2, RoundingMode.HALF_UP).toPlainString().replace('.', ',') + "%";
    }

    static String dataHora(LocalDateTime d) {
        return d == null ? "-" : d.format(DATA_HORA);
    }

    static String produto(Produto p) {
        return String.format("#%-3d %-24s %12s  estoque %-4d %-14s %s%s", p.getId(), p.getNome(),
                dinheiro(p.getPreco()), p.getEstoque(), p.getCategoria().getNome(),
                p.getVendedor().getNome(), p.isAtivo() ? "" : "  [INATIVO]");
    }

    static String linhaPedido(Pedido p) {
        return String.format("#%-4d %-22s %-18s %12s  %s", p.getId(), p.getStatus(),
                p.getCliente().getNome(), dinheiro(p.getValorCobrado()), dataHora(p.getDataCriacao()));
    }

    static void pedido(Console c, Pedido p) {
        c.linha("  Pedido #" + p.getId() + " - " + p.getStatus() + " (cliente: " + p.getCliente().getNome() + ")");
        if (p.getItens().isEmpty()) {
            c.linha("  (sem itens)");
        }
        for (ItemPedido i : p.getItens()) {
            BigDecimal bruto = i.getPrecoUnitario().multiply(BigDecimal.valueOf(i.getQuantidade()));
            String volume = i.getDescontoVolume().signum() > 0
                    ? "  (desconto por volume -" + dinheiro(i.getDescontoVolume()) + ")" : "";
            c.linha(String.format("   %dx %-22s %10s = %10s%s", i.getQuantidade(), i.getProduto().getNome(),
                    dinheiro(i.getPrecoUnitario()), dinheiro(bruto), volume));
        }
        c.linha("  Subtotal bruto ......... " + dinheiro(p.getSubtotalBruto()));
        if (p.getDescontoVolume().signum() > 0) {
            c.linha("  Desconto por volume .... -" + dinheiro(p.getDescontoVolume()));
        }
        if (p.getDescontoComercial().signum() > 0) {
            String origem = p.getCupom() != null ? "cupom " + p.getCupom().getCodigo() : "fidelidade";
            c.linha("  Desconto comercial ..... -" + dinheiro(p.getDescontoComercial()) + " (" + origem + ")");
        }
        if (p.getPontosUsados() > 0) {
            c.linha("  Pontos resgatados ...... -" + dinheiro(p.getValorPontos()) + " (" + p.getPontosUsados() + " pontos)");
        }
        c.linha("  Valor dos produtos ..... " + dinheiro(p.getValorProdutos()));
        c.linha("  Frete .................. " + (p.getFrete().signum() == 0 ? "grátis" : dinheiro(p.getFrete())));
        c.linha("  TOTAL .................. " + dinheiro(p.getTotal()));
        Pagamento pg = p.getPagamento();
        if (pg != null) {
            String forma = pg.getMetodo() + (pg.getParcelas() > 1 ? " em " + pg.getParcelas() + "x" : "");
            c.linha("  Pagamento .............. " + forma + " - " + pg.getStatus());
            c.linha("  VALOR COBRADO .......... " + dinheiro(p.getValorCobrado()));
            if (pg.getVencimento() != null) {
                c.linha("  Vencimento do boleto ... " + pg.getVencimento().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            }
        }
        if (p.getCodigoRastreio() != null) {
            c.linha("  Código de rastreio ..... " + p.getCodigoRastreio());
        }
        if (p.getDataFinalizacao() != null) {
            c.linha("  Finalizado em .......... " + dataHora(p.getDataFinalizacao()));
        }
        if (p.getDataPagamento() != null) {
            c.linha("  Pago em ................ " + dataHora(p.getDataPagamento()));
        }
    }
}
