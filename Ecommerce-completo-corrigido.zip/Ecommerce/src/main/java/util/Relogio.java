package util;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Relogio {
    private static LocalDateTime fixo = null;

    public static LocalDateTime agora() {
        return fixo != null ? fixo : LocalDateTime.now();
    }

    public static LocalDate hoje() {
        return agora().toLocalDate();
    }

    public static void fixar(LocalDateTime momento) { fixo = momento; }
    public static void liberar() { fixo = null; }
}