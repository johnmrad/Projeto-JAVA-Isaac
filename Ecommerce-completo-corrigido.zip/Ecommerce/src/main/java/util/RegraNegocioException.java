package util;

public class RegraNegocioException extends RuntimeException {
    public RegraNegocioException(String motivo) {
        super(motivo);
    }
}