package util;

public class Validacao {
    public static void exigir(boolean ok, String motivo) {
        if (!ok) {
            throw new RegraNegocioException(motivo);
        }
    }

    public static boolean vazio(String s) {
        return s == null || s.isBlank();
    }
}