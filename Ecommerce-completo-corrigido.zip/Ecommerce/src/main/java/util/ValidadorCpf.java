package util;

public class ValidadorCpf {

    public static String limpar(String cpf) {
        if (cpf == null) {
            return "";
        }
        return cpf.replaceAll("[^0-9]", "");
    }

    public static boolean valido(String cpf) {
        String numeros = limpar(cpf);

        if (numeros.length() != 11) {
            return false;
        }
        if (todosIguais(numeros)) {
            return false;
        }

        int d1 = calcularDigito(numeros, 9);
        int d2 = calcularDigito(numeros, 10);

        return d1 == numeros.charAt(9) - '0'
            && d2 == numeros.charAt(10) - '0';
    }

    private static boolean todosIguais(String numeros) {
        for (int i = 1; i < numeros.length(); i++) {
            if (numeros.charAt(i) != numeros.charAt(0)) {
                return false;
            }
        }
        return true;
    }

    private static int calcularDigito(String numeros, int quantidade) {
        int soma = 0;
        int peso = quantidade + 1;
        for (int i = 0; i < quantidade; i++) {
            soma += (numeros.charAt(i) - '0') * peso;
            peso--;
        }
        int resto = (soma * 10) % 11;
        return resto == 10 ? 0 : resto;
    }
}